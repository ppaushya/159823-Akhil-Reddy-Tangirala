package com.capgemini;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/api")
public class MyRestServices {

	
	@GET
	@Path("/hello")
	public String sayHello() {
		return "hello world!";
	}
	
	
	@GET
	@Path("/greet/{userName}")
	@Produces(MediaType.TEXT_HTML)
	public String greetUser(@PathParam("userName")String user) {
		
		return "Hello!" +user;
		
	}
	
	
	
	
}
