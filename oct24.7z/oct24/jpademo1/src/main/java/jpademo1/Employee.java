package jpademo1;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="employee_info")
public class Employee {

	
	public Employee(int employee_id, String firstname, String lastname, double salary, String emailId,
			Date dateOfJoining, String empPassword) {
		super();
		this.employee_id = employee_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.empPassword = empPassword;
	}
	public Employee(int employee_id, String firstname, String lastname, double salary) {
		super();
		this.employee_id = employee_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", salary=" + salary + "]";
	}
	
	@Id
	private int employee_id;
	private String firstname;
	@Column(name="lname")
	private String lastname;
	private double salary;
	private String emailId;
	@Temporal(value=TemporalType.DATE)
	private Date dateOfJoining;
	@Transient
	private String empPassword;
	
	
	
	
	
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
