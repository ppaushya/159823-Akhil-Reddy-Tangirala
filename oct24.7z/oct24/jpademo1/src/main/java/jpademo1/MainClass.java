package jpademo1;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Employee employee =new Employee(214,"trom","jerry",23000);
		
		employee.setDateOfJoining(new Date());
		employee.setEmailId("akhil@gmail.com");
		employee.setEmpPassword("123");
		
		
		Employee employee1 =new Employee(2161,"tsomt","jerrdy",230002);
		
		employee1.setDateOfJoining(new Date());
		employee1.setEmailId("akhil@gmail.com");
		employee1.setEmpPassword("123");

		entityManager.persist(employee);
		entityManager.persist(employee1);
		
		transaction.commit();
	}

}
