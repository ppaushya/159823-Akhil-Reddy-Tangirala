package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.Calculator")
public class calculatorimpl implements Calculator{

	@Override
	public int addnumber(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1+num2;
	}

	
}
