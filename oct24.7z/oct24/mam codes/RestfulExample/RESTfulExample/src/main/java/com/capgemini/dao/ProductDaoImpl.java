package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Product;

public class ProductDaoImpl implements IProductDao{

	
	public List<Product> getAllProducts() {
	
		return DummyDB.getDbList();
	}

	public List<Product> addProduct(Product product) {
		DummyDB.getDbList().add(product);
		
		return DummyDB.getDbList();
	}

}
