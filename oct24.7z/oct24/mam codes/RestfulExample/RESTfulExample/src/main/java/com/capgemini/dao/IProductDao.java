package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Product;

public interface IProductDao {
public List<Product> getAllProducts();

public List<Product> addProduct(Product product);
}
