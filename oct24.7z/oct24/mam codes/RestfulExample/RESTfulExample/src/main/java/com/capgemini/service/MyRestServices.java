package com.capgemini.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

//@Path("/api")
public class MyRestServices {

	@GET
	@Path( "/hello")
	public String sayHello() {
		return "hello world!";
	}
	
	

	@GET
	@Path( "/greet/{userName}")
	@Produces(MediaType.TEXT_HTML)
	public String greetUser(@PathParam("userName")String user) {
		return "<html> <body><h1>Hello! " + user +"</h1></body></html>";
	}
	
	
	@POST
	@Path( "/loadData")
	@Produces(MediaType.TEXT_XML)
	public String greetUser() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<employee>"
				+ "<firstname>tom</firstname>"
				+ "<lastname>jerry</lastname>"
				+ "</employee> ";
	}
	
	
}
