package org.cap;

import java.net.MalformedURLException;
import java.net.URL;

import javax.jws.WebService;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class SoapClientTest {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub

		
		URL url=new URL("http://localhost:7709/ws/Calculator?wsdl");
		QName qname=new QName("http://capgemini.com/","CalculatorImplService");
		
		Service service=Service.create(url,qname);
		Calculator calculator=service.getPort(Calculator.class);
		
		System.out.println("add number method"+calculator.addNumber(12, 12));
	}

}
