package org.sbi.services;

import java.util.List;

import org.sbi.model.Account;
import org.sbi.model.Customer;

public interface ICustomerService {

	public void createCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public void createaccounts(Customer customer,Account account);
	public void depositmoney(Customer cust);
	public void withdrawmoney(Customer cust);
	public void dotransaction(Customer cust, Customer cust1);
}

