package org.sbi.dao;

import java.sql.Connection;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.sbi.model.Account;
import org.sbi.model.Address;
import org.sbi.model.Customer;

public class CustomerDoaDbImpl implements ICustomerDao {

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		
	List<Customer> customers=new ArrayList<>();
		
		String sql1="select * from customer";
		
		try(Connection conn1=getDbConnection()) {
		try {
			PreparedStatement statement=conn1.prepareStatement(sql1);
			ResultSet res=statement.executeQuery();
			
			Customer c=new Customer();
			
			
			
			while(res.next())
			{
				c.setCustomerId(res.getInt(1));
				c.setFirstName(res.getString(2));
				c.setLastName(res.getString(3));
				c.setEmailId(res.getString(4));
				c.setMobile(res.getString(5));
				customers.add(c);
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		String sql="insert into customer(custid,firstname,lastname,emailid,mobileno) values(?,?,?,?,?)";
		String sql2="insert into address values(?,?,?,?,?)";
		

		
		
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement statement=conn.prepareStatement(sql);
				
				statement.setInt(1, customer.getCustomerId());
				statement.setString(2, customer.getFirstName());
				statement.setString(3, customer.getLastName());
				statement.setString(4, customer.getEmailId());
				statement.setString(5, customer.getMobile());
				
				
				PreparedStatement statement2=conn.prepareStatement(sql2);
				
			statement2.setString(1,  customer.getAddress().getAddressLine1()); 
			System.out.println();
			statement2.setString(2,  customer.getAddress().getAddressLine2()); 
			statement2.setString(3,  customer.getAddress().getCity()); 
			statement2.setString(4,  customer.getAddress().getState()); 
			statement2.setString(5,  customer.getAddress().getPincode()); 

			
				int count1=statement2.executeUpdate();
				
				int count=statement.executeUpdate();
				
				if(count>0)
					System.out.println("Insertion done!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	@Override
	public void createaccounts(Customer customer, Account account) {
		// TODO Auto-generated method stub
		
		
		String sql3="insert into account values(?,?,?,?,?,?)";
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement statement=conn.prepareStatement(sql3);
				statement.setInt(1, customer.getCustomerId());
				statement.setLong(2, account.getAccountNumber());
				statement.setString(3, account.getAccountType());
				statement.setDate(4, Date.valueOf(account.getOpeningDate()));
				statement.setDouble(5, account.getOpeningBalance());
				statement.setString(6, account.getDescription());

				
		
		
		
	}

}
