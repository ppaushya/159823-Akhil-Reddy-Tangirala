package org.uas.service;

import java.util.List;

import org.uas.model.Application;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;

public interface I_UAS_Service {

	public List<ProgramsOffered> getAllProgramsOffered();
	public List<Application> getAllApplicants(int programId);
	public Application apply(Application application);
	public String getStatus(int appId);
	public boolean isVAlidLogin(int username, String pwd);
	public void updateApplicationStatus(Application application);
	
}
