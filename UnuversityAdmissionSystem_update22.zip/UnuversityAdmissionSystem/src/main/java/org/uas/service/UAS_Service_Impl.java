package org.uas.service;

import java.util.List;

import org.uas.dao.I_UAS_Dao;
import org.uas.dao.UAS_Dao_Impl;
import org.uas.model.Application;
import org.uas.model.ProgramsOffered;
import org.uas.model.Users;

public class UAS_Service_Impl implements I_UAS_Service{
	
	I_UAS_Dao uasDao=new UAS_Dao_Impl();

	@Override
	public List<ProgramsOffered> getAllProgramsOffered() {
		// TODO Auto-generated method stub
		return uasDao.getAllProgramsOffered();
	}

	@Override
	public String getStatus(int appId) {
		
		return uasDao.getStatus(appId);
	}

	@Override
	public Application apply(Application application) {
		return(uasDao.apply(application));
		
	}

	@Override
	public boolean isVAlidLogin(int username, String pwd) {
		
		List<Users> users= uasDao.getUserDetails();
		System.out.println(users);
		for(Users user1:users)
		{
			if(user1.getLoginId()==username && user1.getPassword().equals(pwd))
			{
				System.out.println("Valid MAC");
				return true;
			}
			
			
		}
		System.out.println("invalid");
		return false;
		
	}

	@Override
	public List<Application> getAllApplicants(int programId) {
		return uasDao.getAllApplicants(programId);
		
	}

	@Override
	public void updateApplicationStatus(Application application) {
		 uasDao.updateApplicationStatus(application);
		
	}

}
