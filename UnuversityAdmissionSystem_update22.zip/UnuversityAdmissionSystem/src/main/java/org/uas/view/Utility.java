package org.uas.view;

import java.util.List;

import org.uas.model.ProgramsOffered;

public class Utility {

	public static void printAllPrograms(List<ProgramsOffered> programs) {
		

		System.out.println("S.No. \tProgram Title \t Duration(years) \t Eligibility \t\t Degree Certificate \t\t Description");
		int count=1;
		for(ProgramsOffered program:programs)
		{
			System.out.print(count+".\t");
			System.out.print(program.getProgramName()+"\t\t\t");
			System.out.print(program.getDuration()+"\t\t");
			System.out.print(program.getApplicantEligibility()+"\t\t\t");
			System.out.print(program.getDegreeCertificateOffered()+"\t\t\t");
			System.out.print(program.getDescription()+"\t\t");
			
			count++;
			System.out.println();
		}
		
	}

}
