package org.uas.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.uas.dao.UAS_Dao_Impl;
import org.uas.model.Application;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;
import org.uas.model.Status;
import org.uas.service.I_UAS_Service;
import org.uas.service.UAS_Service_Impl;

public class UserInteraction {
	
	I_UAS_Service service=new UAS_Service_Impl();
	Scanner scanner=new Scanner(System.in); 

	//This method deal with the User as Applicant
	public void applicantDetails() {

		System.out.println("Choose the action you want to do");
		
		System.out.println("1.View All Programs");
		System.out.println("2.Check your application status");

		int choice;
		
		choice=scanner.nextInt();
		
		
		switch (choice) {
		case 1:
			
		//	List<ProgramsSchedule> programs=new ArrayList<>();
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			ProgramsOffered program=new ProgramsOffered();
			Utility.printAllPrograms(programs);
			
			
				System.out.println("Choose one program");
				
				//Iterate and print all programs
				//scan program no.
				//based on program no. get application
				
				
				int option=scanner.nextInt();
				
				Application application=new Application();
				System.out.println("Enter  Full Name:");
				scanner.nextLine();
				String name=scanner.nextLine();
				if(isValidName(name))
				application.setFullName(name);
				else
				{
					boolean flag=true;
					String Name;
					do
					{
					System.out.println("please enter valid name");
					

					 Name=scanner.nextLine();
					
					if(!Name.matches("[a-zA-Z]+"))
					{
						flag=false;
					}
					else
					{
						flag=true;
					}
					
					
					}while(!flag);
					
					application.setFullName(Name);
				}
				
				
				System.out.println("Enter date of birth [dd-mm-yyyy]");
			
				String dob=scanner.next();
				String[] dob2;
				if(isValidDob(dob)) {
					String[] dob1=dob.split("-");
				application.setDateOfBirth(LocalDate.of(Integer.parseInt(dob1[2]), Integer.parseInt(dob1[1]), Integer.parseInt(dob1[0])));
				}else
				{
					boolean flag=true;
				
					do
					{
					System.out.println("please enter valid date");
					
					 dob=scanner.next();
							dob2=dob.split("-");
					 
					
					if(!isValidDob(dob))
					{
						flag=false;
					}
					else
					{
						flag=true;
					}
					
					
					}while(!flag);
					
					application.setDateOfBirth(LocalDate.of(Integer.parseInt(dob2[2]), Integer.parseInt(dob2[1]), Integer.parseInt(dob2[0])));

				}
				
				
				
				System.out.println("Enter Highest Qualification [10th/12th/Graduate/PG");
				String qualify=scanner.next();
				if(verifyQualify(qualify))
				{application.setHighestQualification(qualify);}
				else
				{
					boolean flag=true;
					String Name;
					do
					{
					System.out.println("please enter valid qualification");
					

					 qualify=scanner.nextLine();
					
					if(!verifyQualify(qualify))
					{
						flag=false;
					}
					else
					{
						flag=true;
					}
					
					
					}while(!flag);
					
					application.setHighestQualification(qualify);
					
				}
				
				
				System.out.println("Enter marks obtained");
				application.setMarksObtained(scanner.nextInt());
				
				
				System.out.println("Enter your goals");
				scanner.next();
				application.setGoals(scanner.nextLine());
				
				
				System.out.println("Enter your EmailID");
				String email=scanner.next();
				if(isValidEmail(email))
				application.setEmailId(email);
				else
				{
					boolean flag=true;
					String email1;
					do
					{
					System.out.println("please enter valid email");
					

					 email1=scanner.next();
					
					if(!isValidEmail(email1))
					{
						flag=false;
					}
					else
					{
						flag=true;
					}
					
					
					}while(!flag);
					
					
					application.setEmailId(email1);
				}
				application.setStatus(Status.APPLIED);
				
				switch(option)
				{
				case 1: application.setScheduledProgramId(1001);
						break;
				case 2: application.setScheduledProgramId(1002);
						break;
				case 3: application.setScheduledProgramId(1003);
						break;
				}
				//apply for the corresponding program return type int(applicant ID)
				Application application1=service.apply(application);
				
				System.out.println("Application submitted successfully with Applicant ID:"+application1.getApplicationId()+" Status:"+application1.getStatus());
				
			
			
			
			break;
		case 2:
			System.out.println("Enter the Applicant Id:");
			int appId=scanner.nextInt();
			
			String status=service.getStatus(appId);
			System.out.println("Your Application is "+status);
		default:
			break;
		}
		
		
	}

	private boolean isValidEmail(String email) {
		
		String regex = "^[A-Za-z0-9+_.-]+@(.+)$"; 
		 Pattern pattern = Pattern.compile(regex); 
		 Matcher matcher = pattern.matcher((CharSequence)email); 
		 return matcher.matches();
		
		
		
		
	}

	private boolean verifyQualify(String qualify) {
		if(qualify.compareTo("12th")==0 || qualify.compareTo("10th")==0 || (qualify.toUpperCase()).compareTo("GRADUATE")==0 || (qualify.toUpperCase()).compareTo("PG")==0)
		return true;
		
		return false;
	}

	private boolean isValidDob(String dob) {

		String regex = "^[0-3]?[0-9]-[0-3]?[0-9]-(?:[0-9]{2})?[0-9]{2}$"; 
 Pattern pattern = Pattern.compile(regex); 
 Matcher matcher = pattern.matcher((CharSequence)dob); 
 return matcher.matches();
	}

	private boolean isValidName(String name) {

		boolean flag=true;
		
		
		if(!name.matches("[a-zA-Z]+"))
		{
			flag=false;
		}
		
		
		return flag;
	}

	//This method deal with the User as the Member of Admission Committee(MAC)
	public void MACLogin() {
		
		System.out.println("Enter the Username: ");
		int username=scanner.nextInt();
		
		System.out.println("Enter the password:");
		String pwd=scanner.next();
		
		if(service.isVAlidLogin(username,pwd))
		{
			List<ProgramsOffered> programs=new ArrayList<>();
			programs=service.getAllProgramsOffered();
			
			ProgramsOffered program=new ProgramsOffered();
			
			System.out.println("Enter Program Id: ");
			
				int programId=scanner.nextInt();
				List<Application> applications=service.getAllApplicants(programId);
				System.out.println("Applicant ID\t Full Name \t DOB\tHighest Qualification\tMarks Obtained\tGoals\tEmail ID\tStatus");
				for(Application application:applications)
				{
					if(application.getStatus()!=Status.REJECTED)
					{
					System.out.println(application.getApplicationId()+"\t"+application.getFullName()+"\t"+application.getDateOfBirth()+"\t"+application.getHighestQualification()+"\t"
							+application.getMarksObtained()+"\t"+application.getGoals()+"\t"+application.getEmailId()+"\t"+application.getStatus());
						if(application.getStatus()==Status.APPLIED)
						{
								System.out.println("1. Accept \n2. Reject");
								int choice=scanner.nextInt();
								switch(choice)
								{
								case 1: System.out.println("Give the date of Interview [dd-mm-yyyy]");	
											String[] date= scanner.next().split("-");
											LocalDate interviewDate=LocalDate.of(Integer.parseInt(date[2]), Integer.parseInt(date[1]), Integer.parseInt(date[0]));
											application.setStatus(Status.ACCEPTED);
											application.setDateOfInterview(interviewDate);
											service.updateApplicationStatus(application);
											break;
								case 2:
										application.setStatus(Status.REJECTED);
										service.updateApplicationStatus(application);
										break;
								default: System.out.println("Invalid choice");
								
								}
						}
						else if(application.getStatus()==Status.ACCEPTED)
						{
							System.out.println("1. Confirm \n2. Reject");
							int choice=scanner.nextInt();
							switch(choice)
							{
							case 1:		application.setStatus(Status.CONFIRMED);
										
										service.updateApplicationStatus(application);
										break;
							case 2:
									application.setStatus(Status.REJECTED);
									service.updateApplicationStatus(application);
									break;
									
							default: System.out.println("Invalid choice");
							
							}
						}
					}
				}
				
				
					
		
			
			
		
	

	
	
		}
	
	}
	
	
	
	
	
	
	
	
	
}
