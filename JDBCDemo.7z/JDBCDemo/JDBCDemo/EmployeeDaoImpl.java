package org.cap.demoSender;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeDaoImpl implements IEmployeeDao{

	private Connection getDbConnection() {
		Connection conn=null;
		try{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
	
			Class.forName("com.mysql.jdbc.Driver");
			return conn;
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return null;
		
		
	}

	@Override
	public void createEmployee(EmployeeDB emp) {
		Connection conn=getDbConnection();
		String sql="Insert into employees values(?,?,?,?,?)";
		try {
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1,emp.getEmpId());
			statement.setString(2,emp.getfName());
			statement.setString(3, emp.getlName());
			statement.setInt(4, emp.getSalary());
			statement.setDate(5,java.sql.Date.valueOf(emp.getDate()));
			
			int count=statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
