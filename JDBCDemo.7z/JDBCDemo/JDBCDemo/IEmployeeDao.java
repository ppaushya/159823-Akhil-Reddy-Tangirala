package JDBCDemo;

public interface IEmployeeDao {

	
	
	public void createEmployee(EmployeeDB emp);
}
