package JDBCDemo;

import java.time.LocalDate;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IEmployeeDao employeeDao=new EmployeeDaoImpl();
		
		EmployeeDB emp=new EmployeeDB(1232,"toam","jeerry",23000,LocalDate.now());
		
		employeeDao.createEmployee(emp);
	}

}
