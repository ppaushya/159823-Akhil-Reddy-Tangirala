package JDBCDemo;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class TestJdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn=null;
		
		try {
		Class.forName("com.mysql.jdbc.Driver");//load driver class
		
		//connection establishment
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		
		
		//SQL query
		String sql="create table employee1(empid int primary key,firstName varchar(25) not null,"
				+"lastName varchar(25),salary numeric(8,2),empdoj date)";
		Statement statement=conn.createStatement();
		boolean flag=statement.execute(sql);
		
		if(!flag)
		{
			System.out.println("Table"
					+ ""
					+ " created successfully!");
		}
		} catch(ClassNotFoundException | SQLException e)//checked exception
		{
			e.printStackTrace();
		}
		finally {
			
			try {
				conn.close();
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
		}

	}

}
