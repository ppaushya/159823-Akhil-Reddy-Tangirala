import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Customer} from './customer';
import { Observable } from 'rxjs';
import { Address } from './address';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class CustService {

  private custUrl = 'http://localhost:8085/banking/p1';  // URL to web api


  
  constructor(private http: HttpClient) { }

 
  getCustomers (customer:any): Observable<Customer> {
    //console.log(customer);
    console.log('Customers here! service');
    return this.http.post<Customer>(this.custUrl+"/validlogin",customer,{})
     
  }

  createCustomers (customer:any,register : any) :Observable<Customer>
  {
    console.log("customer is "+customer.firstName+" address is "+register.addressline1);
    return this.http.post<Customer>(this.custUrl+"/createcustomers",customer,{})
  }

}
