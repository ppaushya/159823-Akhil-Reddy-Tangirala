import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
import { MerchantComponent } from './merchant/merchant.component';
import { ProductsComponent } from './products/products.component';
import { CustomersComponent } from './customers/customers.component';
import { PromosComponent } from './promos/promos.component';
import { GenerateCouponsComponent } from './generate-coupons/generate-coupons.component';
import { BusinessAnalysisComponent } from './business-analysis/business-analysis.component';
import { HttpClientModule } from '@angular/common/http';
import { BusinessAnalysisService } from './business-analysis/business-analysis.service';
import { CouponImageComponent } from './coupon-image/coupon-image.component';
import { CouponService } from './generate-coupons/generate-coupons.service';
import { CustomerService } from './customers/customers.service';

@NgModule({
  declarations: [
    AppComponent,
    AdminMainPageComponent,
    CouponImageComponent,
    MerchantComponent,
    ProductsComponent,
    CustomersComponent,
    PromosComponent,
    GenerateCouponsComponent,
    BusinessAnalysisComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BusinessAnalysisService, CouponService,CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
