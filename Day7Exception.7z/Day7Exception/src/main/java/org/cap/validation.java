package org.cap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class validation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner=new Scanner(System.in);
	String empid;
	
	System.out.println("enter emp id");
	empid=scanner.next()
;
	
	Pattern pattern=Pattern.compile("\\d(5)_(FS|TS|IN)");
	Matcher matcher=pattern.matcher(empid);
	System.out.println(matcher.find());
		
	}

}
