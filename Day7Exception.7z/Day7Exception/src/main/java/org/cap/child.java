
package org.cap;

public class child extends parent{

	public void print() throws NumberFormatException{
		// TODO Auto-generated method stub
		System.out.println("dfs");
		
	}

	
	
}
