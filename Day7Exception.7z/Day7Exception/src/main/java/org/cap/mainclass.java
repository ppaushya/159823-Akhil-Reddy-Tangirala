package org.cap;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child c=new child();
		c.print();
	}

}
