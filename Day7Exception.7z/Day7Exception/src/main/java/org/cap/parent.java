package org.cap;

import java.io.FileNotFoundException;

public class parent {

	public void print() throws NullPointerException{
		System.out.println("fsd");
	}
	
	
}