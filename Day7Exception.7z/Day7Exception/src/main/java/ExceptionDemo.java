
public class ExceptionDemo {

	public static void main(String[] args)
	{
		int num=100;
//		int num2=0;
		int result=0;
		String num2="10";
		
		try
		{
		 result=Integer.parseInt(num2);
		}
		
		catch(ArithmeticException|NumberFormatException e)
		{
			e.printStackTrace();
		}
		
		
		
		finally {
			System.out.println("dsd");
		}
		
//		catch(NumberFormatException e)
//		{
//			System.out.println(e.getMessage());
//		}
		
		System.out.println("result " + result);
	}
	
}
