
public class exp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer num1=100;
		
		Integer num2=12;
		Integer ans=null;
		try
		{
			ans=num1/num2;
			System.out.println(ans);
			try{String num="80s";
			int result=Integer.parseInt(num)/7;
			System.out.println("result:"+result);
			}
			catch(NumberFormatException e)
			{
				e.printStackTrace();
			}
		}
		
		catch(ArithmeticException e){
			
			e.printStackTrace();
		}
		
		
	}

}
