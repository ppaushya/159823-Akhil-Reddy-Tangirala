
public class InvalidAgeException extends Exception {

	public InvalidAgeException(String msg)
	{
		super(msg);
		
	}
	
	public String getMessage()
	{
		return "wrong";
	}
	
	
}
