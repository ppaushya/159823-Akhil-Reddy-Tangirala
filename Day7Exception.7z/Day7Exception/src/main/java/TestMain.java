
public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int age=12;
		try {
		if(age<19)
		{
			throw new InvalidAgeException("hey you..dont put age less than 19");
		}
	}
		
		catch(InvalidAgeException e)
		{
			System.out.println(e.getMessage());
		}

}
	
}
