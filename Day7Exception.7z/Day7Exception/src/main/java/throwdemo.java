import java.io.FileNotFoundException;

public class throwdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String num=null;
		if(num!=null)
		{
			int ans=Integer.parseInt(num+=90);
			System.out.println(ans);
			
		}
		else
		{
			try{throw new NullPointerException();
		}
			catch(NullPointerException e){
				System.out.println(e.getMessage());
			}
		}
		
		System.out.println("Execution completed");
		
	}

}
