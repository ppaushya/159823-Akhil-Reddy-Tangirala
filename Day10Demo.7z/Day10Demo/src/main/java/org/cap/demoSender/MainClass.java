package org.cap.demoSender;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Sender<String>  str=new Sender<>();

str.setMessage("hi");

System.out.println(str.getMessage());
		  

Sender<Integer> myData=new Sender<>();

myData.setMessage(21);

System.out.println(myData.getMessage());

Sender send=new Sender<>();

send.setMessage(12.32);

System.out.println(send.getMessage());

	}

}
