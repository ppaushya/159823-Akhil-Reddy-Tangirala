package org.cap.demoSender;

public class MyClass<T> {

	
	
}
