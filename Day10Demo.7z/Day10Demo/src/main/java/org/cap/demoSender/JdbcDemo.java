package org.cap.demoSender;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class JdbcDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection=null;
		//load driver class
		try {
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/akhildb", "root", "India123");
		
		String sql="create table employee(empid int primary key,firstname varchar(25) not null,"
		+"lastname varchar(25),salary numeric(8,2),empdoj date)";
		
		Statement statement=connection.createStatement();
		boolean flag=statement.execute(sql);
		
		if(!flag)
			System.out.println("table created successfully");
		
		
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		

	}

}
