package org.cap.demoSender;

public class CalMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calculate<Integer, Integer> cal=new Calculate<>();
		
		cal.setNum(12);
		
		cal.setNumber(33);
		
		
		System.out.println(cal.getNum()+cal.getNumber());
	}

}
