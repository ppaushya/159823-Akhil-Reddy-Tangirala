package org.cap.demoSender;

public class Calculate<T,R> {

	private T number;
	private R num;
	public T getNumber() {
		return number;
	}
	public void setNumber(T number) {
		this.number = number;
	}
	public R getNum() {
		return num;
	}
	public void setNum(R num) {
		this.num = num;
	}
	
	
	
}
