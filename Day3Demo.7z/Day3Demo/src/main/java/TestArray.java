
public class TestArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int[] num=new int[10];
		
		int num[]= {1,3,4,2,3};
		
		System.out.println("Size " +num.length);
		
		double pi=3.14;
		
//		short mynum=9;
//		num[0]=1;
//		num[1]=mynum;
//		num[2]=45;
//		num[7]=70;
//		num[9]=(int)pi;
//		
		System.out.println(num);
		
		for(int i=0;i<5;i++)
		{
			System.out.println(num[i]);

		}
	}

}
