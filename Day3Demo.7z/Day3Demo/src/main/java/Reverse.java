import java.util.Scanner;
public class Reverse {
	
int[] myArr;
	
	public void getArrayElements(int size)
	{
		
		Scanner scr=new Scanner(System.in);
		
		myArr=new int[size];
		System.out.println("Enter " +size+"array elements");
		for(int i=0;i<size;i++)
		{
			myArr[i]=scr.nextInt();
		}
		
		
	}
	
	public void reversearray(int[] a)
	{
		int temp;
		int b=a.length-1,k=0;
		
		while(k<=b)
		{
			temp=a[k];
			a[k]=a[b];
			a[b]=temp;
			k++;
			b--;
			
		}
		
//		int temp;
//		for(int i=0;i<a.length;i++)
//		{
//			for(int j=a.length-1;j>=(a.length)/2;j--)
//			{
//				temp=a[i];
//				a[i]=a[j];
//				a[j]=temp;
//			}
//		}
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Reverse obj=new Reverse();
		obj.getArrayElements(5);

		obj.reversearray(obj.myArr);
		
	}

}
