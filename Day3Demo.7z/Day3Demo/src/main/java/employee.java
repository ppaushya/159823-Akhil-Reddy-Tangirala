import java.util.Scanner;
public class employee {

	employee[] employees;
	
	String firstname;
	String lastname;
	int age;
	int id;
	
	public void acceptemployee(int size)
	{
		employees=new employee[size];
		
		for(int i=0;i<size;i++)
		{
			employees[i]=new employee();
			employees[i].getEmployee();

		}
		
		for(int i=0;i<size;i++)
		{
			
			employees[i].printData();

		}
		
		
	}
	public void getEmployee()
	{
		Scanner scr=new Scanner(System.in);
		System.out.println("First name:" );

		firstname=scr.next();
		System.out.println("last name:" );

		lastname=scr.next();
		System.out.println("age:" );

		age=scr.nextInt();
		System.out.println("id" );

		id=scr.nextInt();

		System.out.println("1 object entered");
	}
	
	public void printData()
	{
		System.out.println("---------------------------" );

		System.out.println("First name:" +firstname);

		System.out.println("last name:" +lastname);

		System.out.println("age:" +age);

		System.out.println("id" +id);

	}
	
	public void sortbyempid(employee[] employees,int num)
	{
		employee temp;
		 for (int i = 0; i < num-1; i++)
	            for (int j = 0; j < num-i-1; j++)
	                if (employees[j].id>employees[j+1].id)
	                {
	                   temp = employees[j];
	                  employees[j]=employees[j+1];
	                  employees[j+1]=temp;
	                }
	        System.out.println();
	        
	    	System.out.println("sorted order is: ");

	        for(int i=0;i<num;i++)
	        {
	        	System.out.println(employees[i].id);

	        }
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int num=0;
		System.out.println("enter no of employee" );
		num=sc.nextInt();
		employee emp=new employee();
		emp.acceptemployee(num);
		emp.sortbyempid(emp.employees,num);
		
		
	}

}
