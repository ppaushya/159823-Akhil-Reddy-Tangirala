import java.util.Scanner;

public class task2 {
	
int[] myArr;
	
	public void getArrayElements(int size)
	{
		
		Scanner scr=new Scanner(System.in);
		
		myArr=new int[size];
		System.out.println("Enter " +size+ "array elements");
		for(int i=0;i<size;i++)
		{
			myArr[i]=scr.nextInt();
		}
		
		
	}
	
	public int findSmallest(int[] a)
	{
		
		int i;
		for(i=0;i<a.length-1;i++)
		{
			
			if((a[i+1]-a[i])==1)
					{
				continue;
					}
			else
			{
				return a[i]+1;
						
			}
			
			
			
	
			
			
		}
		
//		if(i==a.length)
//		{
//			return a[i]+1;
//		}
		
	return a[i]+1;
		
	}
	
	public void sorting(int[] a)
	{
		
	        int n = a.length;
	        for (int i = 0; i < n-1; i++)
	            for (int j = 0; j < n-i-1; j++)
	                if (a[j] > a[j+1])
	                {
	                    int temp = a[j];
	                    a[j] = a[j+1];
	                    a[j+1] = temp;
	                }
	        
			System.out.println(findSmallest(a));

	        
	}

	public static void main(String[] args) {

		task2 t=new task2();
	

		
		t.getArrayElements(5);
		t.sorting(t.myArr);
		
	}

}
