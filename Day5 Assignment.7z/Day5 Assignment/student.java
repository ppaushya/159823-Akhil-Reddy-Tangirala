
public interface student {

	public void Display_Grade();
	public void attendance();
	
	
	
}
