
public class child1class implements parentinterface{

	public void divisions() {
		System.out.println("Divisions method overridden");
	}
	public void modules()
	{
		System.out.println("modules method overridden");
	
	}
	
	
	
}
