class circle_day5assign implements day4ques2assign
{
public float compute(float x,float y)
{return(pi*x*x);}
}