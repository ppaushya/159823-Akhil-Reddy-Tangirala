
public interface parentinterface {

	public void divisions();
	public void modules();
	
	
	
	
}
