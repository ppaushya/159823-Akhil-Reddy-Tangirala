
public class pgstudents implements student {

	public void Display_Grade()
	{
		System.out.println("pgstudents display grade");
	}
	public void attendance() 
	{
		System.out.println("pgstudents attendance");

	}
	
}
