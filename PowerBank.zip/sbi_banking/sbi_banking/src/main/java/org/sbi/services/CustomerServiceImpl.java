package org.sbi.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.sbi.dao.CustomerDaoImpl;
import org.sbi.dao.ICustomerDao;
import org.sbi.model.Account;
import org.sbi.model.Customer;
import org.sbi.model.Transaction;
import org.sbi.util.Utility;

public class CustomerServiceImpl implements ICustomerService{
	
	private ICustomerDao customerDao=new CustomerDaoImpl();
	
	List<Transaction> transactions = new ArrayList<>();
	

	@Override
	public void createaccounts(Customer customer,Account account) {
		// TODO Auto-generated method stub
		customerDao.createaccounts(customer,account);
		
	}

	@Override
	public void createCustomer(Customer customer) {
		if(isValidCustomer(customer)) {
					customerDao.createCustomer(customer);
		}
		
		
	}
	
	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDateOfBirth().isBefore(LocalDate.now())) {
			if(customer.getMobile().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.getAllCustomers();
	}

	Scanner scanner = new Scanner(System.in);
	@Override
	public void depositmoney(Customer cust) {
		// TODO Auto-generated method stub
		System.out.println("enter the account which "+cust.getFirstName()+" wants to deposit");
		String type=scanner.next();
		Set<Account> accs=cust.getAccounts();
		
		for(Account accountss:accs )
		{
			if(accountss.getAccountType().compareTo(type)==0)
			{
				System.out.println("enter the amount u want to deposit");
				int amount=scanner.nextInt();
				accountss.setOpeningBalance(accountss.getOpeningBalance()+amount);
				System.out.println("current balance is "+accountss.getOpeningBalance());
			}
		}
		
	}

	@Override
	public void withdrawmoney(Customer cust) {
		// TODO Auto-generated method stub
		System.out.println("enter the account which "+cust.getFirstName()+" wants to deposit");
		String type=scanner.next();
		Set<Account> accs=cust.getAccounts();
		
		for(Account accountss:accs )
		{
			if(accountss.getAccountType().compareTo(type)==0)
			{
				System.out.println("enter the amount u want to withdraw");
				int amount=scanner.nextInt();
				if(accountss.getOpeningBalance()>amount)
				{
				accountss.setOpeningBalance(accountss.getOpeningBalance()-amount);
				System.out.println("current balance is "+accountss.getOpeningBalance());
				}
				else
				{
					System.out.println("insufficient funds");
				}
			}
		}
	}

	@Override
	public void dotransaction(Customer cust, Customer cust1) {
		// TODO Auto-generated method stub
		String acct1 = null,acct2=null;
		Transaction trans=new Transaction();
		int amount;
		System.out.println("enter the amount u want to do transaction");
		 amount=scanner.nextInt();
		System.out.println("enter the account which "+cust.getFirstName()+" wants to debit from");
		String type=scanner.next();
		Set<Account> accs=cust.getAccounts();
		
		for(Account accountss:accs )
		{
			if(accountss.getAccountType().compareTo(type)==0)
			{
			acct1=accountss.getAccountType();
			if(accountss.getOpeningBalance()>amount)
			{
			accountss.setOpeningBalance(accountss.getOpeningBalance()-amount);
			System.out.println("current balance is "+accountss.getOpeningBalance());
			}
			else
			{
				System.out.println("insufficient funds");
				
			}
			
			}
		}
		
		
		Set<Account> accs1=cust1.getAccounts();
		System.out.println("enter the account which "+cust1.getFirstName()+" is credited");
		String type1=scanner.next();
		
		for(Account accountss:accs )
		{
			if(accountss.getAccountType().compareTo(type1)==0)
			{
				acct2=accountss.getAccountType();

			
			accountss.setOpeningBalance(accountss.getOpeningBalance()+amount);
			System.out.println("current balance is "+accountss.getOpeningBalance());
			}
			
			
			}
		
		
		trans.setAmount(amount);
		trans.setTransactionDate(LocalDate.now());
		trans.setTransactionId(Utility.generateNumber());
		trans.setDescription("Fund transfer");
		trans.setTransactionType("debit/credit");
		trans.setFromAccount(acct1);
		trans.setFromAccount(acct2);
		
		System.out.println(trans);

		}
		
	

}
