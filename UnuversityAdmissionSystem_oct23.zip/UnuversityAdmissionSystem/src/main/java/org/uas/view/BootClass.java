package org.uas.view;

import java.util.Scanner;

public class BootClass {
	
	static Scanner scr=new Scanner(System.in);
	public static void main(String[] args)
	{
		String choice;
		do {
		System.out.println("Applicant or MAC");
		
		UserInteraction ui=new UserInteraction();
		int ch;
		System.out.println("1.Applicant");
		System.out.println("2.Member of Admission Committee(MAC)");
		//System.out.println("3.Administration");
		
		ch=scr.nextInt();
	
	
		switch (ch) {
		case 1:
				
			ui.applicantDetails();	
			break;
			

		case 2:
			ui.MACLogin();
			break;
			
			
			
		default:
			System.out.println("Invalid option!!");
			break;
		}

System.out.println("Do you want to continue? [y/n]");
choice=scr.next();

if(choice.charAt(0)=='n' || choice.charAt(0)=='N')
	System.out.println("Logging Off.....");


	}while(choice.charAt(0)=='y' || choice.charAt(0)=='Y');
  
	}
  

}
