package org.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.uas.model.ProgramsOffered;

public class ProgramsOfferedDao {
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();
	
	public List<ProgramsOffered> getAllProgramsOffered() {
		List<ProgramsOffered> programs= new ArrayList<>();
		
		String sql="select * from programs_offered";
		
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ProgramsOffered program=new ProgramsOffered();
				program.setProgramName(rs.getString(1));
				program.setDescription(rs.getString(2));
				program.setApplicantEligibility(rs.getString(3));
				program.setDuration(rs.getInt(4));
				program.setDegreeCertificateOffered(rs.getString(5));
				programs.add(program);
				
			}
			return programs;
			
		} catch (SQLException e) {
			uasDao.logger.error("Error occured"+e);
		}
		return null;
	}


}
