package org.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.uas.model.Application;
import org.uas.model.Status;

public class ApplicationDao {
	
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();
	
	public Application apply(Application application) {
		Application application1=new Application();
		String sql="insert into application(full_name, date_of_birth, highest_qualification, marks_obtained, goals, email_id, scheduled_program_id, status) "
				+ "values(?,?,?,?,?,?,?,?)";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
				pst.setString(1, application.getFullName());
				pst.setDate(2,Date.valueOf(application.getDateOfBirth()));
				pst.setString(3, application.getHighestQualification());
				pst.setInt(4, application.getMarksObtained());
				pst.setString(5, application.getGoals());
				pst.setString(6, application.getEmailId());
				pst.setInt(7, application.getScheduledProgramId());
				pst.setString(8,application.getStatus().toString());
				
			
			int flag=pst.executeUpdate();
			if(flag>0)
			{
				
				uasDao.logger.info("Application Record inserted successfully");
				String sql1="select application_id, scheduled_program_id, status from application";
				PreparedStatement pst1=connection.prepareStatement(sql1);
				
				ResultSet rs=pst1.executeQuery();
				
				while(rs.next())
				{
					application1.setApplicationId(rs.getInt(1));
					application1.setScheduledProgramId(rs.getInt(2));
					application1.setStatus(Status.valueOf(rs.getString(3)));
					
				}
				return application1;
			}
			
		} catch (SQLException e) {
			uasDao.logger.error("Error occured while inserting application record"+e);
		}
		
		return null;
	}

	public List<Application> getAllApplicants(int programId) {
		List<Application> applications=new ArrayList<>();
		
		String sql="select * from application where scheduled_program_id=? and "
				+ "(date_of_interview is null "
				+ "or date_of_interview <=now())";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setInt(1,programId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Application application=new Application();
				application.setApplicationId(rs.getInt(1));
				application.setFullName(rs.getString(2));
				application.setDateOfBirth(rs.getDate(3).toLocalDate());
				application.setHighestQualification(rs.getString(4));
				application.setMarksObtained(rs.getInt(5));
				application.setGoals(rs.getString(6));
				application.setEmailId(rs.getString(7));
				application.setScheduledProgramId(rs.getInt(8));
				application.setStatus(Status.valueOf(rs.getString(9)));
				//application.setDateOfInterview(rs.getDate(10).toLocalDate());
				applications.add(application);
			}
			return applications;
		}catch(SQLException e)
		{
			uasDao.logger.error("Error occured while fetching application record"+e);
		}
		return null;
	}
	
	public String getStatus(int appId) {
		Application application=new Application();
		String sql="select status from application where application_id=?";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
				pst.setInt(1, appId);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					return rs.getString(1);
				}
				
		} catch (SQLException e) {
			uasDao.logger.error("Error occure while fetching status of application"+e);
		}
		
		return null;
	}
	
	public void updateApplicationStatus(Application application) {
		
		String sql="update application set status=?, date_of_interview=? where application_id=?";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setString(1,application.getStatus().toString());
			if(application.getStatus()==Status.REJECTED || application.getStatus()==Status.CONFIRMED )
			{
				pst.setDate(2, null);
			}
			else
			{
			pst.setDate(2, Date.valueOf(application.getDateOfInterview()));
			}
			pst.setInt(3, application.getApplicationId());
			
			int count=pst.executeUpdate();
			if(count>0)
			{
				uasDao.logger.info("Application record updated");
			}
			else
			{
				uasDao.logger.info("Application Update failed");
			}
		
		} catch (SQLException e) {
			uasDao.logger.error("Error occured while updating application record"+e);
		}
	}
	
	

}


