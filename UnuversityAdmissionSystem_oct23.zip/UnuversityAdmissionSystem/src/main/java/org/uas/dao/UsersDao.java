package org.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.uas.model.Role;
import org.uas.model.Users;

public class UsersDao {
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();

	public List<Users> getUserDetails() {
		List<Users> users=new ArrayList<>();
		
		String sql="select * from users";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
				
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Users user=new Users();
					user.setLoginId(rs.getInt(1));
					user.setPassword(rs.getString(2));
					user.setRole(Role.valueOf(rs.getString(3)));
					
					users.add(user);
				}
				return users;
		}catch(SQLException e)
		{
			uasDao.logger.error("Error occured "+e);
		}
		return null;
	}

}
