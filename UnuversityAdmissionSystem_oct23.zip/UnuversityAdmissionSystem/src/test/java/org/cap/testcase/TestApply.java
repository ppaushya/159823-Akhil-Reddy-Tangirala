package org.cap.testcase;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.uas.dao.ApplicationDao;
import org.uas.dao.I_UAS_Dao;
import org.uas.model.Application;
import org.uas.model.Status;
import org.uas.service.UAS_Service_Impl;




public class TestApply {

	
	@Mock
	private I_UAS_Dao applicationdao;
	
	private UAS_Service_Impl service;
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		service = new UAS_Service_Impl(applicationdao);
	}
	
	
	
	@Test
	public void test_acc()
	{
		Application application1=new Application();
	
   
		application1.setApplicationId(1);
		application1.setFullName("akhil");
		application1.setDateOfBirth(LocalDate.of(2000, 10, 10));
		application1.setHighestQualification("12th");
		application1.setMarksObtained(100);
		application1.setGoals("towin");
		application1.setEmailId("akhil@gmail");
		application1.setScheduledProgramId(1001);
		application1.setStatus(Status.APPLIED);
		application1.setDateOfInterview(LocalDate.of(2018, 10, 10));
	    
	    Mockito.when(applicationdao.apply(application1)).thenReturn(application1);
	    
	    
	    service.apply(application1);
	    
	    Mockito.verify(applicationdao).apply(application1);
	    
	    
	}
}
