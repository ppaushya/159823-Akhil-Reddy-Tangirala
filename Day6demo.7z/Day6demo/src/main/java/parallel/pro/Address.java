package parallel.pro;

public class Address {

	private String stName;
	private String city;
	private String state;
	
        Address()
        {
            
        }
        public void setStName(String stName)
        {
            this.stName=stName;
        }
        public void setCity(String city)
        {
            this.city=city;
        }
        public void setState(String state)
        {
            this.state=state;
        }
        public String getStName()
        {
            return stName;
        }
        public String getCity()
        {
            return city;
        }
        public String getState()
        {
            return state;
        }
}
