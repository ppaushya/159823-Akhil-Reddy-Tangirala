package parallel.pro;
import java.time.*;
public class Account {
	private long accountNo;
	private String accountType;//salary saving RD FD
	private Instant openingDate;
	private double openingBalance;
	private double currentBalance;
        Account()
        {
            
        }
        public void setAccountNo(long accountNo)
        {
            this.accountNo=accountNo;
        }
        public void setAccountType(String accountType)
        {
            this.accountType=accountType;
        }
        public void setOpeningDate()
        {
            this.openingDate=Instant.now();
        }
        public void setOpeningBalance(double openingBalance)
        {
            this.openingBalance=openingBalance;
        }
        public void setCurrentBalance()
        {
            this.currentBalance=openingBalance;
        }
        public void setCurrentBalance(double amount)
        {
            this.currentBalance=amount;
        }
        public long get1AccountNo()
        {
            return this.accountNo;
        }
        public String get1AccountType()
        {
            return this.accountType;
        }
        public Instant get1OpeningDate()
        {
            return this.openingDate;
        }
        public double get1OpeningBalance()
        {
            return this.openingBalance;
        }
        public double get1CurrentBalance()
        {
            return this.currentBalance;
        }
}
