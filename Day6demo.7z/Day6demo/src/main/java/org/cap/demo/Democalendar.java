package org.cap.demo;

import java.util.*;

import java.time.format.*;



public class Democalendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Calendar cal=Calendar.getInstance();
			
		System.out.println(cal.getTime());
		
		cal.add(Calendar.YEAR,5);
		
		System.out.println(cal.getTime());
		
		Date date=new Date();
		
		System.out.println(cal.getMaximum(Calendar.YEAR));
		System.out.println(cal.getMinimum(Calendar.YEAR));
		System.out.println(cal.getMaximum(Calendar.MONTH));
		System.out.println(cal.getMinimum(Calendar.MONTH));


	}

}
