package org.cap.demo;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		regularclassdemo.Innerclass obj=new regularclassdemo().new Innerclass();
		
		
		regularclassdemo outer= new regularclassdemo();
		
		regularclassdemo.Innerclass inner= outer.new Innerclass();
		
		
//		obj.show();
		
		inner.show();
		
	}

}
