package org.cap.demo;

public class wrapdemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Integer num=100;

Integer myNum=new Integer(100);


Integer value=100;

Integer myNum1=new Integer(100);

	System.out.println(num.equals(myNum));	
		
	System.out.println(num==myNum);
	
	System.out.println(num==value);
	System.out.println(myNum==myNum1);


	}

}
