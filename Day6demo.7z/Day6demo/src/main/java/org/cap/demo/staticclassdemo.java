package org.cap.demo;

public class staticclassdemo {

	
	int count=100;
	
	static int pi=1;
	
	static class innerclass
	{
		int num=100;
		
		public void print()
		{System.out.println("num"+num);
			System.out.println("pi"+pi);
		}
	}
	
	public static void show()
	{
		System.out.println("pi");

	}
	
}










