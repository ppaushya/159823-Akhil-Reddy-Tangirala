package org.cap.demo;


import java.util.*;

public class calendarexp {

	
	
	public static void main(String[] args)
	{
		
	
	Date today=new Date();
	System.out.println(today);
	
	Date d=new Date(1991-1900,01,23);
	
	System.out.println(d);

	System.out.println(d.getTime());
	System.out.println(d.getDate());

	Date da=new Date(1538369712179L);
	System.out.println(da);

	Calendar cal=Calendar.getInstance();
	
	System.out.println(cal.get(Calendar.YEAR));
	
	
//	
//	da.getHours();
//	
//	da.getDate();
//	
//	
//	da.getMinutes();
//	
//	da.getMonth();
//	
//	da.getSeconds();
//	
//	da.getYear();
	
	
	}
	
}
