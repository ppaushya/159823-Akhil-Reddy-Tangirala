package org.cap.demo;

public class outerclass {

	String name="akhil";
	
	public void details()
	{
		int count=100;
		class temp
		{
			int num=45;
			String name="jack";
			
			public void print()
			{
				System.out.println("Num"+num);
				System.out.println("Name"+name);
				
				outerclass obj=new outerclass();
				
				
				System.out.println("Num"+obj.name);

				
				
			}
		}
		
		temp t=new temp();
			
		t.print();
		
	}
	
	
	
	
	
}
