package org.cap.demo;

public class stringbufdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer buffer= new StringBuffer("tom");
buffer.ensureCapacity(200);
System.out.println(buffer.capacity());

StringBuffer buffer1= new StringBuffer(30);
buffer1.append("jerry");
System.out.println(buffer1.capacity());

System.out.println(buffer);
System.out.println(buffer.length());
System.out.println(buffer.capacity());
		                               

buffer.append("jerry");




System.out.println(buffer.capacity());


System.out.println(buffer);

buffer.append("akhil reddy tangirala");
		
System.out.println(buffer);

System.out.println(buffer.length());

System.out.println(buffer.capacity());

buffer.replace(0,3,"   ");

System.out.println(buffer);


	}

}
