package org.cap.demo;

public class mainclass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		outerclass out=new outerclass();
		
		out.details();
		
	}

}
