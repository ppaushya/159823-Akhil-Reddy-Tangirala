package org.cap.demo;

public class wrapperdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer integer=new Integer(23);
		
		int num=100;
		
		integer=num;
		
		System.out.println(integer);
		
		String str="123";
		int num1=Integer.parseInt(str);

		System.out.println(num1);

//		Double value=num1.doublevalue();
		
		
//		System.out.println(Integer.MIN_VALUE);
//
//		System.out.println(Integer.MAX_VALUE);
//
//		System.out.println(Short.MIN_VALUE);
//
//		System.out.println(Short.MAX_VALUE);
//
//		System.out.println(Double.MIN_VALUE);
//
//		System.out.println(Double.MAX_VALUE);

		
	}

}
