package org.cap.demo;

import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;

public class InstanceDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Instant in=Instant.now();
		System.out.println(in.MAX);
		System.out.println(Instant.now());
		
		System.out.println(in.MIN);
		
		LocalDate date=LocalDate.now();
		System.out.println(date);

		LocalDate today = LocalDate.now();	
//		
//		Date date1=Date.from(today);
//		LocalDate localdate=date1.toLocalDate();

		
		
	}

}
