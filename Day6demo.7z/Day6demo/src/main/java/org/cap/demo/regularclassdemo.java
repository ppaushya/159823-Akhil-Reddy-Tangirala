package org.cap.demo;

public class regularclassdemo {

	int number;
	String name;
	
	
	public class Innerclass
	{
		
		
		
		String address;
		public void show()
		{
			
			System.out.println(number);
			System.out.println(name);

			
		}
		
	}
	
	
	
	
	
	
	

}
