package org.xyz.model;

public class Address {

	private String addressLine1;
	
	private String addressline2;
	
	private String city;
	
	private String state;
	
	private long pincode;

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [addressLine1=" + addressLine1 + ", addressline2=" + addressline2 + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + "]";
	}

	public Address(String addressLine1, String addressline2, String city, String state, long pincode) {
		super();
		this.addressLine1 = addressLine1;
		this.addressline2 = addressline2;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public Address() {
		super();
	}
	
	
	
}
