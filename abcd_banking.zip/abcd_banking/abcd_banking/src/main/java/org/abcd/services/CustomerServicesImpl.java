package org.abcd.services;

import java.util.List;

import org.abcd.dao.CustomerDaoImpl;
import org.abcd.dao.ICustomerDao;
import org.xyz.model.Customer;

public class CustomerServicesImpl implements CustomerServices{

	
	private ICustomerDao customerdao= new CustomerDaoImpl();
	
	
	
	
	@Override
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
	
		if(isValidCustomer(customer)) 
		{
		customerdao.createCustomer(customer);
	}
	}


	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		
			if(customer.getMobileNo().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		
		return flag;
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerdao.getAllCustomers();
	}

	
	
	
}
