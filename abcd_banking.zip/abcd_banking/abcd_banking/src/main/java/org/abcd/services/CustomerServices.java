package org.abcd.services;

import java.util.List;

import org.xyz.model.Customer;

public interface CustomerServices {

public void createCustomer(Customer customer);
	
	public List<Customer> getAllCustomers();
	
	
}
