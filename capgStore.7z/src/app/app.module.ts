import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { SliderModule } from './slider/slider.module';
import { HomePageComponent } from './homepage/homepage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import {  FormsModule } from '@angular/forms'
import { RouterModule } from '@angular/router';
import { RegistrationpageComponent } from './registrationpage/registrationpage.component';




@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    LoginpageComponent,
    RegistrationpageComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SliderModule,
    FormsModule,
    AppRoutingModule, 
    RouterModule.forRoot([
      {path:'', redirectTo: 'homepage',pathMatch: 'full'},
      {path:'homepage', component:HomePageComponent},
      {path:'login', component:LoginpageComponent},
      {path:'registration', component:RegistrationpageComponent},

 
    ])

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
