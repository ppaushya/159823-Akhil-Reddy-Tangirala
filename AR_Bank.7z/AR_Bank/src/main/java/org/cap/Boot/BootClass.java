package org.cap.Boot;

import java.util.Scanner;

import org.cap.Model.Customer;
import org.cap.View.UserInteraction;

public class BootClass {

	
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {

		UserInteraction ui=new UserInteraction();
		
		Customer c=ui.getCustomerdetails();
		
		System.out.println(c);
		
		
	}

}
