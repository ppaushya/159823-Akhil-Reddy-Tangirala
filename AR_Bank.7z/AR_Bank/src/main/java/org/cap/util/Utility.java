package org.cap.util;

public class Utility {

	
	public static int generateNumber() {
	return (int)(Math.random()*10000)/100;
	}
}
