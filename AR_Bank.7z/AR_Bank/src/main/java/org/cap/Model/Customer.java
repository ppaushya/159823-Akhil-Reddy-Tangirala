package org.cap.Model;


import java.time.LocalDate;
import java.util.Set;

public class Customer {
	
	private int customerId;
	private String firstName;
	private String lastName;
	private String emailid;
	private	String mobileno;
private LocalDate localdate;
	private Address address;
	private Set<Account> accounts;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public LocalDate getLocalDate() {
		return localdate;
	}
	public void setLocalDate(LocalDate localDate) {
		localdate = localDate;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Set<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(Set<Account> accounts) {
		this.accounts = accounts;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailid=" + emailid + ", mobileno=" + mobileno + ", LocalDate=" + localdate + ", address="
				+ address + ", accounts=" + accounts + "]";
	}
	public Customer(int customerId, String firstName, String lastName, String emailid, String mobileno, LocalDate localDate,
			Address address, Set<Account> accounts) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailid = emailid;
		this.mobileno = mobileno;
		localdate = localDate;
		this.address = address;
		this.accounts = accounts;
	}
	public Customer() {
		super();
	}
	
	
}
