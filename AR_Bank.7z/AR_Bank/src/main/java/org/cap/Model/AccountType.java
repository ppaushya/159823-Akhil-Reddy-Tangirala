package org.cap.Model;

public enum AccountType {
	
	SAVINGS,CURRENT,RD,FD;

}