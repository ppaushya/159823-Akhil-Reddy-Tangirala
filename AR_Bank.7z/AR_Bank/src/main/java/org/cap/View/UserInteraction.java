package org.cap.View;
import java.time.LocalDate;
import java.util.Scanner;

import org.cap.Model.Customer;
import org.cap.util.Utility;

import java.time.LocalDate;
import java.util.Scanner;

import org.cap.Model.Customer;
import org.cap.util.Utility;

public class UserInteraction {

	public Customer getCustomerdetails()
	{
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastName(promptLastName());
		customer.setEmailid(promptEmailid());
		customer.setMobileno(promptMobileNo());
		customer.setLocalDate(promptLocaldate());

		
		
		return customer;
	}
	
	public String promptFirstName()
	{
		boolean flag=false;
		Scanner scr=new Scanner(System.in);
		String fname;
		do {
			System.out.println("Enter First name");
		fname=scr.next();
		flag=fname.matches("[a-zA-Z]{3,}");
		if(!flag)
			System.out.println("Please enter valid first name");
		}
		while(!flag);
			
		return fname;
		
	}
	
	
	public String promptLastName()
	{
		boolean flag=false;
		Scanner scr=new Scanner(System.in);
		String lname;
		do {
			System.out.println("Enter last name");
		lname=scr.next();
		flag=lname.matches("[a-zA-Z]{3,}");
		if(!flag)
			System.out.println("Please enter valid last name");
		}
		while(!flag);
			
		return lname;	
	}
	
	public String promptEmailid()
	{
		boolean flag=false;
		Scanner scr=new Scanner(System.in);
		String emailid;
		do {
			System.out.println("Enter emailid");
		emailid=scr.next();
		flag=emailid.matches("[a-zA-z0-9]+[@]{1}(gmail){1}[.]{1}(com){1}");
		if(!flag)
			System.out.println("Please enter valid emailid");
		}
		while(!flag);
			
		return emailid;	
	}
	
	public String promptMobileNo()
	{
		boolean flag=false;
		Scanner scr=new Scanner(System.in);
		String mobileNo;
		do {
			System.out.println("Enter mobile number");
		mobileNo=scr.next();
		flag=mobileNo.matches("[7-9]{1}[0-9]{9}");
		if(!flag)
			System.out.println("Please enter valid emailid");
		}
		while(!flag);
			
		return mobileNo;	
	}
	
	public LocalDate promptLocaldate()
	{
		boolean flag=false;
		Scanner scr=new Scanner(System.in);
		String date;
		do {
			System.out.println("Enter date");
		date=scr.next();
		flag=date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}");
		if(!flag)
			System.out.println("Please enter valid date");
		}
		while(!flag);
			
		String[] date1=date.split("-");
		
		LocalDate date2=LocalDate.of(Integer.parseInt(date1[0]),Integer.parseInt(date1[1]),Integer.parseInt(date1[2]));
		
		return date2 ;	
	}
	
	
	
	
	
	
	
}
