import { Directive, ElementRef, Input, NgModule, Injectable, IterableDiffers, Renderer2, forwardRef, Host, HostListener, TemplateRef, ViewContainerRef, Optional, Inject, PLATFORM_ID, NgZone, HostBinding, ChangeDetectionStrategy, Component, EventEmitter, Output, ChangeDetectorRef, InjectionToken, ContentChild, ComponentFactoryResolver, Injector, SkipSelf, SimpleChange, KeyValueDiffers, defineInjectable, inject, INJECTOR } from '@angular/core';
import { CommonModule, isPlatformBrowser, isPlatformServer, DOCUMENT } from '@angular/common';
import { NG_VALUE_ACCESSOR, NgControl, ControlContainer, FormGroup } from '@angular/forms';
import { Subject, BehaviorSubject, from, Observable } from 'rxjs';
import { takeUntil, take, filter, map, tap, mapTo, switchMap } from 'rxjs/operators';
import { EventManager, HammerGestureConfig } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { animate, style, transition, trigger } from '@angular/animations';
import { BehaviorSubject as BehaviorSubject$1 } from 'rxjs/internal/BehaviorSubject';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Anchor for passing link to element to the overlay or similar.
 */
class KitAnchorDirective {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
    /**
     * Get reference to anchored element.
     * @return {?}
     */
    get elementRef() {
        return this._elementRef;
    }
    /**
     * Get anchored html-element.
     * @return {?}
     */
    get nativeEl() {
        return this._elementRef.nativeElement;
    }
}
KitAnchorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitAnchor]',
                exportAs: 'anchor',
            },] },
];
/** @nocollapse */
KitAnchorDirective.ctorParameters = () => [
    { type: ElementRef, },
];
KitAnchorDirective.propDecorators = {
    "kitAnchor": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitAnchorModule {
}
KitAnchorModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitAnchorDirective,
                ],
                exports: [
                    KitAnchorDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} x
 * @return {?}
 */
function isString(x) {
    return typeof x === 'string';
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Apply classes to an element.
 *
 * Must be provided on a component or directive.
 *
 * ```typescript
 * constructor(private kitClass: KitClassService) {}
 * ...
 * this.kitClass.apply({color: 'red', active: true, primary: false});
 * ```
 *
 * Adds to element: `class="color-red active"`
 */
class KitClassService {
    /**
     * @param {?} renderer
     * @param {?} el
     * @param {?} differs
     */
    constructor(renderer, el, differs) {
        this.renderer = renderer;
        this.el = el;
        this.differs = differs;
        this._state = {};
    }
    /**
     * Override class declaration state.
     * @param {?} setterRaw
     * @return {?}
     */
    set state(setterRaw) {
        const /** @type {?} */ newState = Object.assign({}, setterRaw);
        this.process(newState);
    }
    /**
     * Merge to class declaration state.
     * @param {?} setter
     * @return {?}
     */
    apply(setter) {
        const /** @type {?} */ newState = Object.assign({}, this._state, setter);
        this.process(newState);
    }
    /**
     * @param {?} newState
     * @return {?}
     */
    process(newState) {
        const /** @type {?} */ classList = this.processObj(newState);
        if (!this._differ) {
            this._differ = this.differs.find(classList).create();
        }
        const /** @type {?} */ changes = this._differ.diff(classList);
        if (changes) {
            this.applyChanges(changes);
            this._state = newState;
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    applyChanges(changes) {
        changes.forEachRemovedItem((record) => this.renderer.removeClass(this.el.nativeElement, record.item));
        changes.forEachAddedItem((record) => this.renderer.addClass(this.el.nativeElement, record.item));
    }
    /**
     * @param {?} obj
     * @return {?}
     */
    processObj(obj) {
        return Object.keys(obj)
            .map((key) => {
            const /** @type {?} */ value = obj[key];
            return isString(value)
                ? `${key}-${value}`
                : !!value
                    ? key
                    : null;
        })
            .filter(isString);
    }
}
KitClassService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitClassService.ctorParameters = () => [
    { type: Renderer2, },
    { type: ElementRef, },
    { type: IterableDiffers, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} val
 * @return {?}
 */
function isDefined(val) {
    return val !== null && val !== undefined;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const KIT_CHECK_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => KitCheckDirective),
    multi: true,
};
/**
 * Adds to any element ValueAccessor and checkbox/radio behavior.
 *
 * When is checked - adds class "checked" to the element.
 *
 * For a value changing the directive listen click event.
 */
class KitCheckDirective {
    /**
     * @param {?} kitClass
     */
    constructor(kitClass) {
        this.kitClass = kitClass;
        /**
         * Class applied when active.
         */
        this.checkedClass = 'checked';
        this.changes = new Subject();
        this.touches = new Subject();
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
    }
    /**
     * Listen to mouse clicks on element.
     * @return {?}
     */
    clickListener() {
        if (isDefined(this.value)) {
            // radio-mode
            this.checked = true;
            this.changes.next(this.value);
        }
        else {
            // checkbox-mode
            this.checked = !this.checked;
            this.changes.next(this.checked);
        }
        this.touches.next();
        this.applyClass();
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.changes.subscribe(fn);
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this.touches.subscribe(fn);
    }
    /**
     * @param {?} isDisabled
     * @return {?}
     */
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        if (isDefined(this.value)) {
            // radio-mode
            this.checked = this.value === value;
        }
        else {
            // checkbox-mode
            this.checked = value;
        }
        this.applyClass();
    }
    /**
     * @return {?}
     */
    applyClass() {
        this.kitClass.apply({
            checked: this.checked,
        });
    }
}
KitCheckDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitCheck]',
                providers: [
                    KIT_CHECK_VALUE_ACCESSOR,
                    KitClassService,
                ],
            },] },
];
/** @nocollapse */
KitCheckDirective.ctorParameters = () => [
    { type: KitClassService, decorators: [{ type: Host },] },
];
KitCheckDirective.propDecorators = {
    "checkedClass": [{ type: Input },],
    "kitCheck": [{ type: Input },],
    "value": [{ type: Input },],
    "clickListener": [{ type: HostListener, args: ['click',] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitCheckModule {
}
KitCheckModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitCheckDirective,
                ],
                declarations: [
                    KitCheckDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Provides `KitClassService` and pass input value to `KitClassService.apply` method.
 *
 * ```html
 * <div [kitClass]="{color: 'red', active: true, primary: false}">
 * <!--<div class="color-red active">-->
 * ```
 */
class KitClassDirective {
    /**
     * @param {?} service
     */
    constructor(service) {
        this.service = service;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['kitClass']) {
            this.service.apply(this.kitClass);
        }
    }
}
KitClassDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitClass]',
                providers: [KitClassService],
            },] },
];
/** @nocollapse */
KitClassDirective.ctorParameters = () => [
    { type: KitClassService, },
];
KitClassDirective.propDecorators = {
    "kitClass": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitClassModule {
}
KitClassModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    KitClassDirective,
                ],
                exports: [
                    KitClassDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitCollapseHostService {
    constructor() {
        this.multiple = false;
        this._active = new BehaviorSubject(new Set());
        this.ids = new Set();
    }
    /**
     * Get `Observable` with activated items.
     * @return {?}
     */
    get activeChanges() {
        return this._active.asObservable();
    }
    /**
     * Get Set with activated items.
     * @return {?}
     */
    get active() {
        return new Set(this._active.value);
    }
    /**
     * Activate item with id.
     * @param {?} id
     * @return {?}
     */
    activate(id) {
        const /** @type {?} */ current = this._active.value;
        if (!current.has(id)) {
            if (this.multiple) {
                this._active.next(new Set(current).add(id));
            }
            else {
                this._active.next(new Set().add(id));
            }
        }
    }
    /**
     * Activate first registered item.
     * @return {?}
     */
    activateFirst() {
        this.activate(this.ids.values().next().value);
    }
    /**
     * Add item.
     * @param {?} id
     * @return {?}
     */
    addId(id) {
        this.ids.add(id);
    }
    /**
     * Deactivate item.
     * @param {?} id
     * @return {?}
     */
    deactivate(id) {
        const /** @type {?} */ current = this._active.value;
        if (current.has(id)) {
            this._active.next(new Set(Array.from(current).filter(i => i !== id)));
        }
    }
    /**
     * Delete item.
     * @param {?} id
     * @return {?}
     */
    deleteId(id) {
        this.ids.delete(id);
    }
    /**
     * Is item activated.
     * @param {?} id
     * @return {?}
     */
    isActive(id) {
        const /** @type {?} */ current = this._active.value;
        return current.has(id);
    }
    /**
     * Change item activation state.
     * @param {?} id
     * @return {?}
     */
    toggle(id) {
        const /** @type {?} */ current = this._active.value;
        if (current.has(id)) {
            this.deactivate(id);
        }
        else {
            this.activate(id);
        }
    }
}
KitCollapseHostService.decorators = [
    { type: Injectable },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @return {?}
 */
function uuid() {
    /**
     * @return {?}
     */
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitCollapseItemService {
    /**
     * @param {?} host
     */
    constructor(host) {
        this.host = host;
        this.id = uuid();
    }
    /**
     * Is item activated.
     * @return {?}
     */
    get active() {
        return this.host.isActive(this._id);
    }
    /**
     * Set activation state.
     * @param {?} active
     * @return {?}
     */
    set active(active) {
        if (active) {
            this.host.activate(this._id);
        }
        else {
            this.host.deactivate(this._id);
        }
    }
    /**
     * Get item id.
     * @return {?}
     */
    get id() {
        return this._id;
    }
    /**
     * Set item id.
     * @param {?} id
     * @return {?}
     */
    set id(id) {
        if (id) {
            this.host.deleteId(this._id);
            this.host.addId(id);
            this._id = id;
        }
        else {
            throw new Error('id is empty');
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.host.deleteId(this._id);
    }
    /**
     * Toggle activation state.
     * @return {?}
     */
    toggle() {
        this.host.toggle(this._id);
    }
}
KitCollapseItemService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitCollapseItemService.ctorParameters = () => [
    { type: KitCollapseHostService, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Structure directive that collapsing.
 *
 * State based on `KitCollapseItemService` provided on a parent.
 */
class KitCollapseDirective {
    /**
     * @param {?} vcr
     * @param {?} template
     * @param {?} host
     * @param {?} item
     */
    constructor(vcr, template, host, item) {
        this.vcr = vcr;
        this.template = template;
        this.host = host;
        this.item = item;
        this.destroy = new Subject();
        this.displayed = false;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.destroy.next();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.host.activeChanges
            .pipe(takeUntil(this.destroy))
            .subscribe(ids => {
            if (ids.has(this.item.id)) {
                if (!this.displayed) {
                    this.vcr.createEmbeddedView(this.template);
                    this.displayed = true;
                }
            }
            else {
                if (this.displayed) {
                    this.vcr.clear();
                    this.displayed = false;
                }
            }
        });
    }
}
KitCollapseDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitCollapse]',
            },] },
];
/** @nocollapse */
KitCollapseDirective.ctorParameters = () => [
    { type: ViewContainerRef, },
    { type: TemplateRef, },
    { type: KitCollapseHostService, },
    { type: KitCollapseItemService, },
];
KitCollapseDirective.propDecorators = {
    "kitCollapse": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitCollapseModule {
}
KitCollapseModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitCollapseDirective,
                ],
                declarations: [
                    KitCollapseDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Service encapsulates complex date-picker grid logic.
 */
class KitDatePickerService {
    /**
     * @param {?} renderer
     */
    constructor(renderer) {
        this.renderer = renderer;
        this.moveHandlerUnsubs = [];
        this._grid = new BehaviorSubject([]);
        this._monthCursor = new BehaviorSubject(null);
        this._pick = new Subject();
    }
    /**
     * Set active date.
     * @param {?} date
     * @return {?}
     */
    set active(date) {
        this._active = new Date(date);
        this._focus = new Date(date);
        this.updateGrid();
    }
    /**
     * Observable with grid state.
     * @return {?}
     */
    get gridChanges() {
        return this._grid.asObservable();
    }
    /**
     * Observable with month cursor state.
     * @return {?}
     */
    get monthCursorChanges() {
        return this._monthCursor.asObservable();
    }
    /**
     * Observable with pick date events.
     * @return {?}
     */
    get pick() {
        return this._pick.asObservable();
    }
    /**
     * Weekdays array.
     * @return {?}
     */
    get weekdays() {
        const /** @type {?} */ weekdays = [];
        const /** @type {?} */ cursor = this.startOfWeek(new Date());
        for (let /** @type {?} */ i = 0; i < 7; i++) {
            weekdays.push(new Date(cursor));
            cursor.setDate(cursor.getDate() + 1);
        }
        return weekdays;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.moveHandlerUnsubs.forEach(u => u());
    }
    /**
     * Focus date (open correspondent month).
     * @param {?} date
     * @return {?}
     */
    focus(date) {
        this._focus = new Date(date);
        this.updateGrid();
    }
    /**
     * Modify opened month.
     * @param {?} modifier
     * @return {?}
     */
    modMonth(modifier) {
        this._focus.setMonth(this._focus.getMonth() + modifier);
        this.updateGrid();
    }
    /**
     * Modify opened year.
     * @param {?} modifier
     * @return {?}
     */
    modYear(modifier) {
        this._focus.setFullYear(this._focus.getFullYear() + modifier);
        this.updateGrid();
    }
    /**
     * Handle keyboard movement.
     * @param {?} target
     * @return {?}
     */
    handleMove(target) {
        if (this.renderer) {
            this.moveHandlerUnsubs = [
                this.renderer.listen(target, 'keydown.ArrowRight', e => {
                    e.preventDefault();
                    this._focus.setDate(this._focus.getDate() + 1);
                    this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.ArrowLeft', e => {
                    e.preventDefault();
                    this._focus.setDate(this._focus.getDate() - 1);
                    this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.ArrowUp', e => {
                    e.preventDefault();
                    this._focus.setDate(this._focus.getDate() - 7);
                    this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.ArrowDown', e => {
                    e.preventDefault();
                    this._focus.setDate(this._focus.getDate() + 7);
                    this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.Home', e => {
                    e.preventDefault();
                    this._focus.setDate(1);
                    this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.End', e => {
                    e.preventDefault();
                    this._focus.setMonth(this._focus.getMonth() + 1, 0);
                    this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.PageUp', e => {
                    e.preventDefault();
                    this.modMonth(-1);
                }),
                this.renderer.listen(target, 'keydown.PageDown', e => {
                    e.preventDefault();
                    this.modMonth(1);
                }),
                this.renderer.listen(target, 'keydown.Alt.PageUp', e => {
                    e.preventDefault();
                    this.modYear(-1);
                }),
                this.renderer.listen(target, 'keydown.Alt.PageDown', e => {
                    e.preventDefault();
                    this.modYear(1);
                }),
                this.renderer.listen(target, 'keydown.Enter', e => {
                    e.preventDefault();
                    this._pick.next(new Date(this._focus));
                }),
                this.renderer.listen(target, 'keydown.Space', e => {
                    e.preventDefault();
                    this._pick.next(new Date(this._focus));
                }),
            ];
        }
    }
    /**
     * Compare two dates.
     * @param {?} x
     * @param {?} y
     * @return {?}
     */
    isDatesEqual(x, y) {
        if (x && y) {
            // @todo improve performance: cache xp, yp
            const /** @type {?} */ xp = new Date(x);
            xp.setHours(0, 0, 0, 0);
            const /** @type {?} */ yp = new Date(y);
            yp.setHours(0, 0, 0, 0);
            return +xp === +yp;
        }
        else {
            throw new Error('isDatesEqual params error');
        }
    }
    /**
     * Start of month of passed date.
     * @param {?} curr
     * @return {?}
     */
    startOfMonth(curr) {
        return new Date(curr.getFullYear(), curr.getMonth(), 1);
    }
    /**
     * Start of week of passed date.
     * @param {?} curr
     * @return {?}
     */
    startOfWeek(curr) {
        const /** @type {?} */ date = new Date(curr);
        const /** @type {?} */ day = date.getDay() || 7;
        if (day !== 1) {
            date.setHours(-24 * (day - 1));
        }
        return date;
    }
    /**
     * Redraw grid based on monthCursor and current date.
     * @return {?}
     */
    updateGrid() {
        if (this._monthCursor.value &&
            this.isDatesEqual(this.startOfMonth(this._focus), this.startOfMonth(this._monthCursor.value))) {
            // update current grid
            const /** @type {?} */ grid = this._grid.value;
            grid.forEach(r => r.forEach(c => {
                c.active = this.isDatesEqual(c.date, this._active);
                c.focus = this.isDatesEqual(c.date, this._focus);
            }));
            this._grid.next(grid);
        }
        else {
            // recompile grid
            const /** @type {?} */ month = this.startOfMonth(this._focus);
            const /** @type {?} */ grid = [];
            const /** @type {?} */ cursor = this.startOfWeek(month);
            for (let /** @type {?} */ row = 0; row < this.weeksInMonth(month); row++) {
                const /** @type {?} */ line = [];
                for (let /** @type {?} */ col = 0; col < 7; col++) {
                    const /** @type {?} */ date = new Date(cursor);
                    line.push({
                        active: this.isDatesEqual(date, this._active),
                        date,
                        focus: this.isDatesEqual(date, this._focus),
                        outside: date.getMonth() !== month.getMonth(),
                    });
                    cursor.setDate(cursor.getDate() + 1);
                }
                grid.push(line);
            }
            this._monthCursor.next(month);
            this._grid.next(grid);
        }
    }
    /**
     * Calc number of weeks in month.
     * @param {?} curr
     * @return {?}
     */
    weeksInMonth(curr) {
        const /** @type {?} */ firstOfMonth = new Date(curr.getFullYear(), curr.getMonth(), 1);
        let /** @type {?} */ day = firstOfMonth.getDay() || 6;
        day = day === 1 ? 0 : day;
        if (day) {
            day--;
        }
        let /** @type {?} */ diff = 7 - day;
        const /** @type {?} */ lastOfMonth = new Date(curr.getFullYear(), curr.getMonth() + 1, 0);
        const /** @type {?} */ lastDate = lastOfMonth.getDate();
        if (lastOfMonth.getDay() === 1) {
            diff--;
        }
        return Math.ceil((lastDate - diff) / 7) + 1;
    }
}
KitDatePickerService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitDatePickerService.ctorParameters = () => [
    { type: Renderer2, decorators: [{ type: Optional },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitDatePickerModule {
}
KitDatePickerModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitPlatformService {
    /**
     * @param {?} platformId
     */
    constructor(platformId) {
        this.platformId = platformId;
    }
    /**
     * @return {?}
     */
    isBrowser() {
        return isPlatformBrowser(this.platformId);
    }
    /**
     * @return {?}
     */
    isServer() {
        return isPlatformServer(this.platformId);
    }
    /**
     * Calc native scroll width.
     * @return {?}
     */
    getScrollbarWidth() {
        if (this.isBrowser()) {
            if (typeof document === 'undefined') {
                return 0;
            }
            const /** @type {?} */ body = document.body;
            const /** @type {?} */ box = document.createElement('div');
            const /** @type {?} */ boxStyle = box.style;
            let /** @type {?} */ width;
            // Init test div
            boxStyle.position = 'absolute';
            boxStyle.position = boxStyle.position = '-9999px';
            boxStyle.height = boxStyle.width = '100px';
            boxStyle.overflow = 'scroll';
            body.appendChild(box);
            // Calc
            width = box.offsetWidth - box.clientWidth;
            // Cleanup
            body.removeChild(box);
            return width;
        }
        else {
            return 0;
        }
    }
}
KitPlatformService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitPlatformService.ctorParameters = () => [
    { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] },] },
];
/** @nocollapse */ KitPlatformService.ngInjectableDef = defineInjectable({ factory: function KitPlatformService_Factory() { return new KitPlatformService(inject(PLATFORM_ID)); }, token: KitPlatformService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitEventManagerService {
    /**
     * @param {?} platform
     */
    constructor(platform) {
        this.platform = platform;
    }
    /**
     * Listen event on the global root object.
     *
     * Reason: native Angular EventManager does not provide event listener with useCapture param.
     * @param {?} eventName
     * @param {?} handler
     * @param {?=} useCapture
     * @return {?}
     */
    listenGlobal(eventName, handler, useCapture) {
        if (this.platform.isBrowser()) {
            window.addEventListener(eventName, /** @type {?} */ (handler), useCapture);
            return () => window.removeEventListener(eventName, /** @type {?} */ (handler), useCapture);
        }
        else {
            return () => {
            };
        }
    }
    /**
     * Get array of objects visited by event.
     * @param {?} event
     * @return {?}
     */
    getEventPath(event) {
        if (this.platform.isBrowser()) {
            const /** @type {?} */ path = [];
            let /** @type {?} */ node = event.target;
            while (node && node !== document.body) {
                path.push(node);
                node = node['parentNode'];
            }
            return path;
        }
        else {
            return [];
        }
    }
}
KitEventManagerService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitEventManagerService.ctorParameters = () => [
    { type: KitPlatformService, },
];
/** @nocollapse */ KitEventManagerService.ngInjectableDef = defineInjectable({ factory: function KitEventManagerService_Factory() { return new KitEventManagerService(inject(KitPlatformService)); }, token: KitEventManagerService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const keyArrowUp = 38;
const keyArrowDown = 40;
const keyArrowRight = 39;
const keyArrowLeft = 37;
const keyPageUp = 33;
const keyPageDown = 34;
const keyHome = 36;
const keyEnd = 35;
const keyEnter = 13;
const keySpace = 32;
const keyTab = 9;
const keyEscape = 27;
const keyBackspace = 8;
const keyDelete = 46;
const keyShift = 16;
const keyCtrl = 17;
const keyAlt = 18;

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Handles leaving focus from a group of elements.
 */
class KitFocusListenerService {
    /**
     * @param {?} em
     */
    constructor(em) {
        this.em = em;
        this._focused = false;
        this._focus = new Subject();
        this._blur = new Subject();
        this.elements = [];
    }
    /**
     * Emits, if user focuses one of registered element.
     * @return {?}
     */
    get focus() {
        return this._focus.asObservable();
    }
    /**
     * Emits, if focus leave one of registered element and target node is not one of registered element (or it's child).
     * @return {?}
     */
    get blur() {
        return this._blur.asObservable();
    }
    /**
     * Is one of registered element focused now.
     * @return {?}
     */
    get focused() {
        return this._focused;
    }
    /**
     * @param {?} el
     * @return {?}
     */
    add(el) {
        this.elements.push({
            el: el,
            focus: this.em.addEventListener(el, 'focus', (event) => {
                if (!this._focused) {
                    this._focused = true;
                    this._focus.next(event);
                }
            }),
            blur: this.em.addEventListener(el, 'blur', (event) => {
                this.checkLeave(event);
            }),
        });
    }
    /**
     * @param {?} el
     * @return {?}
     */
    remove(el) {
        const /** @type {?} */ index = this.elements.findIndex(e => e.el === el);
        if (index) {
            const /** @type {?} */ element = this.elements[index];
            // void handlers
            element.focus();
            element.blur();
            // remove from stack
            this.elements.splice(index, 1);
        }
        else {
            throw new Error('Element has not been registered in KitFocusListenerService');
        }
    }
    /**
     * @param {?=} event
     * @return {?}
     */
    checkLeave(event) {
        let /** @type {?} */ leave = true;
        this.elements.forEach(el => {
            if (el.el.contains(event.relatedTarget)) {
                leave = false;
            }
        });
        if (leave) {
            this._focused = false;
            this._blur.next(event);
        }
    }
}
KitFocusListenerService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitFocusListenerService.ctorParameters = () => [
    { type: EventManager, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFocusManagerRegistryService {
    constructor() {
        this.stack = [];
    }
    /**
     * @param {?} manager
     * @return {?}
     */
    capture(manager) {
        const /** @type {?} */ top = this.getTop();
        if (top) {
            top.onHold = true;
        }
        this.stack.push(manager);
    }
    /**
     * @param {?} manager
     * @return {?}
     */
    release(manager) {
        const /** @type {?} */ index = this.stack.indexOf(manager);
        if (index !== -1) {
            const /** @type {?} */ isTop = this.stack.indexOf(manager) === this.stack.length - 1;
            this.stack.splice(index, 1);
            if (isTop) {
                const /** @type {?} */ newTop = this.getTop();
                if (newTop) {
                    newTop.onHold = false;
                }
            }
        }
    }
    /**
     * @return {?}
     */
    getTop() {
        return this.stack[this.stack.length - 1];
    }
}
KitFocusManagerRegistryService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */ KitFocusManagerRegistryService.ngInjectableDef = defineInjectable({ factory: function KitFocusManagerRegistryService_Factory() { return new KitFocusManagerRegistryService(); }, token: KitFocusManagerRegistryService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFocusManagerService {
    /**
     * @param {?} el
     * @param {?} zone
     * @param {?} renderer
     * @param {?} em
     * @param {?} registry
     */
    constructor(el, zone, renderer, em, registry) {
        this.el = el;
        this.zone = zone;
        this.renderer = renderer;
        this.em = em;
        this.registry = registry;
        /**
         * Automatically capture focus after creating.
         */
        this.autoCapture = false;
        this.onHold = false;
        this.focusTrap = false;
        this.items = new Set();
        this.unsubs = [];
    }
    /**
     * @return {?}
     */
    get documentActiveElement() {
        return /** @type {?} */ (this.el.nativeElement.ownerDocument.activeElement);
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.unsubs.forEach(u => u());
        if (this.outsideSource) {
            this.release();
        }
    }
    /**
     * Activate focus-trap.
     * @return {?}
     */
    capture() {
        this.registry.capture(this);
        this.focusTrap = true;
        this.outsideSource = this.documentActiveElement;
        this.focusFirst();
    }
    /**
     * Focus first focusable element.
     * @return {?}
     */
    focusFirst() {
        const /** @type {?} */ nodes = this.getTabbable();
        if (nodes.length > 0) {
            nodes[0].focus();
        }
    }
    /**
     * Focus item dy id.
     * @param {?} id
     * @return {?}
     */
    focusItem(id) {
        this.zone.onStable
            .pipe(take(1))
            .subscribe(() => {
            this.items.forEach(i => {
                if (i.kitFocus === id) {
                    i.focus();
                }
            });
        });
    }
    /**
     * Focus last focusable element.
     * @return {?}
     */
    focusLast() {
        const /** @type {?} */ nodes = this.getTabbable();
        if (nodes.length > 0) {
            nodes[nodes.length - 1].focus();
        }
    }
    /**
     * Focus next focusable element (from current focused).
     * @return {?}
     */
    focusNext() {
        const /** @type {?} */ current = this.documentActiveElement;
        const /** @type {?} */ nodes = this.getTabbable();
        const /** @type {?} */ currentIndex = nodes.findIndex(n => n === current);
        if (currentIndex !== -1 && currentIndex < nodes.length - 1) {
            nodes[currentIndex + 1].focus();
        }
        else {
            this.focusFirst();
        }
    }
    /**
     * Focus prev focusable element (from currect focused).
     * @return {?}
     */
    focusPrev() {
        const /** @type {?} */ current = this.documentActiveElement;
        const /** @type {?} */ nodes = this.getTabbable();
        const /** @type {?} */ currentIndex = nodes.findIndex(n => n === current);
        if (currentIndex !== -1 && currentIndex > 0) {
            nodes[currentIndex - 1].focus();
        }
        else {
            this.focusLast();
        }
    }
    /**
     * Required method for start service.
     * @return {?}
     */
    init() {
        this.zone.runOutsideAngular(() => {
            // Unsubs
            this.unsubs = [
                this.renderer.listen(this.el.nativeElement, 'focusin', this.focusinHandler.bind(this)),
                this.renderer.listen(this.el.nativeElement, 'focusout', this.focusoutHandler.bind(this)),
                this.em.listenGlobal('keydown', this.keydownHandler.bind(this), true),
            ];
        });
        if (this.autoCapture) {
            this.zone.onStable
                .pipe(take(1))
                .subscribe(() => {
                this.capture();
            });
        }
    }
    /**
     * Register item for manual focus.
     * @param {?} item
     * @return {?}
     */
    add(item) {
        this.items.add(item);
    }
    /**
     * Disable focus-trap.
     * @return {?}
     */
    release() {
        this.registry.release(this);
        this.focusTrap = false;
        this.outsideSource.focus();
    }
    /**
     * Remove item.
     * @param {?} item
     * @return {?}
     */
    remove(item) {
        this.items.delete(item);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    focusinHandler(event) {
        if (!this.onHold && this.isDescendant(this.el.nativeElement, /** @type {?} */ (event.target))) {
            this.current = /** @type {?} */ (event.target);
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    focusoutHandler(event) {
        if (!this.onHold
            && event.relatedTarget
            && !this.isDescendant(this.el.nativeElement, /** @type {?} */ (event.relatedTarget))) {
            if (this.focusTrap) {
                if (this.current) {
                    this.current.focus();
                }
                else {
                    this.focusFirst();
                }
            }
        }
    }
    /**
     * @return {?}
     */
    getTabbable() {
        const /** @type {?} */ selectors = [
            'input',
            'select',
            'a[href]',
            'textarea',
            'button',
            '[tabindex]',
        ];
        const /** @type {?} */ candidates = this.el.nativeElement.querySelectorAll(selectors);
        const /** @type {?} */ basicTabbables = [];
        const /** @type {?} */ orderedTabbables = [];
        for (let /** @type {?} */ i = 0, /** @type {?} */ l = candidates.length; i < l; i++) {
            const /** @type {?} */ candidate = candidates[i];
            const /** @type {?} */ candidateIndex = parseInt(candidate.getAttribute('tabindex'), 10) || candidate.tabIndex;
            if (candidateIndex < 0
                || (candidate.tagName === 'INPUT' && candidate.type === 'hidden')
                || candidate.disabled) {
                continue;
            }
            if (candidateIndex === 0) {
                basicTabbables.push(candidate);
            }
            else {
                orderedTabbables.push({
                    index: i,
                    tabIndex: candidateIndex,
                    node: candidate,
                });
            }
        }
        const /** @type {?} */ tabbableNodes = orderedTabbables
            .sort(function (a, b) {
            return a.tabIndex === b.tabIndex ? a.index - b.index : a.tabIndex - b.tabIndex;
        })
            .map(function (a) {
            return a.node;
        });
        Array.prototype.push.apply(tabbableNodes, basicTabbables);
        return tabbableNodes;
    }
    /**
     * @param {?} parent
     * @param {?} child
     * @return {?}
     */
    isDescendant(parent, child) {
        if (child) {
            let /** @type {?} */ node = child.parentNode;
            while (node !== null) {
                if (node === parent) {
                    return true;
                }
                node = node.parentNode;
            }
            return false;
        }
        else {
            return false;
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    keydownHandler(event) {
        if (!this.onHold && event.keyCode === keyTab) {
            event.preventDefault();
            if (event.shiftKey) {
                this.focusPrev();
            }
            else {
                this.focusNext();
            }
        }
    }
}
KitFocusManagerService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitFocusManagerService.ctorParameters = () => [
    { type: ElementRef, },
    { type: NgZone, },
    { type: Renderer2, },
    { type: KitEventManagerService, },
    { type: KitFocusManagerRegistryService, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFocusTrapDirective {
    /**
     * @param {?} service
     */
    constructor(service) {
        this.service = service;
        this.service.autoCapture = true;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.service.init();
    }
}
KitFocusTrapDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFocusTrap]',
                providers: [
                    KitFocusManagerService,
                ],
            },] },
];
/** @nocollapse */
KitFocusTrapDirective.ctorParameters = () => [
    { type: KitFocusManagerService, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Directive that registered in `KitFocusManagerService` and can be focused from outside.
 */
class KitFocusDirective {
    /**
     * @param {?} service
     * @param {?} el
     */
    constructor(service, el) {
        this.service = service;
        this.el = el;
        if (this.service) {
            this.service.add(this);
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.service) {
            this.service.remove(this);
        }
    }
    /**
     * @return {?}
     */
    focus() {
        this.el.nativeElement.focus();
    }
}
KitFocusDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFocus]',
            },] },
];
/** @nocollapse */
KitFocusDirective.ctorParameters = () => [
    { type: KitFocusManagerService, decorators: [{ type: Optional },] },
    { type: ElementRef, },
];
KitFocusDirective.propDecorators = {
    "kitFocus": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFocusManagerModule {
}
KitFocusManagerModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitFocusDirective,
                    KitFocusTrapDirective,
                ],
                exports: [
                    KitFocusDirective,
                    KitFocusTrapDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Structure directive for capturing form-error template.
 */
class KitFormErrorDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    /**
     * @return {?}
     */
    get name() {
        return this.kitFormError;
    }
}
KitFormErrorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFormError]',
            },] },
];
/** @nocollapse */
KitFormErrorDirective.ctorParameters = () => [
    { type: TemplateRef, },
];
KitFormErrorDirective.propDecorators = {
    "kitFormError": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} x
 * @return {?}
 */
function isUndefined(x) {
    return x === undefined || x === null;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFormFieldService {
    constructor() {
        this._controls = [];
    }
    /**
     * @return {?}
     */
    get control() {
        return this._controls[0];
    }
    /**
     * @return {?}
     */
    get controls() {
        return this._controls;
    }
    /**
     * Register KitNgControlDirective in the service.
     * @param {?} control
     * @return {?}
     */
    add(control) {
        this._controls.push(control);
    }
    /**
     * @param {?} control
     * @return {?}
     */
    remove(control) {
        const /** @type {?} */ index = this._controls.indexOf(control);
        if (index !== -1) {
            this._controls.splice(index, 1);
        }
    }
    /**
     * Check if error exists.
     * @param {?} name
     * @return {?}
     */
    hasError(name) {
        return !!this._controls.find(c => c.ngControl.hasError(name));
    }
    /**
     * Has any error and control touched or dirty.
     * @return {?}
     */
    getErrorsToDisplay() {
        let /** @type {?} */ errors = [];
        this._controls.forEach(control => {
            const /** @type {?} */ hasErrors = control.ngControl.invalid && control.ngControl.touched;
            if (hasErrors) {
                errors = [...errors, ...Object.keys(control.ngControl.errors || {})];
            }
        });
        return errors;
    }
    /**
     * Is main control required.
     * @return {?}
     */
    isRequired() {
        return this.control && !(isUndefined(this.control.required) || this.control.required === false);
    }
}
KitFormFieldService.decorators = [
    { type: Injectable },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Registers `control` in `KitFormFieldService`.
 *
 * Also generates unique _id (needed for correct working label in form-field).
 */
class KitNgControlDirective {
    /**
     * @param {?} ngControl
     * @param {?} formFieldService
     * @param {?} differs
     */
    constructor(ngControl, formFieldService, differs) {
        this.ngControl = ngControl;
        this.formFieldService = formFieldService;
        this.differs = differs;
        this._id = uuid();
        this._errorStateChanges = new Subject();
        if (this.ngControl && this.formFieldService) {
            this.formFieldService.add(this);
        }
    }
    /**
     * @return {?}
     */
    get idBinding() {
        return this._id;
    }
    /**
     * @return {?}
     */
    get id() {
        return this._id;
    }
    /**
     * @param {?} id
     * @return {?}
     */
    set id(id) {
        this._id = id;
    }
    /**
     * @return {?}
     */
    get errorStateChanges() {
        return this._errorStateChanges.asObservable();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.formFieldService) {
            this.formFieldService.remove(this);
        }
    }
    /**
     * @return {?}
     */
    ngDoCheck() {
        if (this.formFieldService) {
            const /** @type {?} */ errors = this.formFieldService.getErrorsToDisplay();
            if (errors && !this.errorsDiffer) {
                this.errorsDiffer = this.differs.find(errors).create();
                this._errorStateChanges.next(errors);
            }
            if (this.errorsDiffer) {
                const /** @type {?} */ diff = this.errorsDiffer.diff(errors);
                if (diff) {
                    this._errorStateChanges.next(errors);
                }
            }
        }
    }
}
KitNgControlDirective.decorators = [
    { type: Directive, args: [{
                // tslint:disable-next-line
                selector: '[ngModel],[formControl],[formControlName]',
            },] },
];
/** @nocollapse */
KitNgControlDirective.ctorParameters = () => [
    { type: NgControl, decorators: [{ type: Host }, { type: Optional },] },
    { type: KitFormFieldService, decorators: [{ type: Optional },] },
    { type: IterableDiffers, },
];
KitNgControlDirective.propDecorators = {
    "required": [{ type: Input },],
    "idBinding": [{ type: HostBinding, args: ['attr.id',] },],
    "id": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFormFieldModule {
}
KitFormFieldModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitFormErrorDirective,
                    KitNgControlDirective,
                ],
                exports: [
                    KitFormErrorDirective,
                    KitNgControlDirective,
                ],
                providers: [],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFormTouchDirective {
    /**
     * @param {?} container
     */
    constructor(container) {
        this.container = container;
    }
    /**
     * @return {?}
     */
    clickHandler() {
        if (this.container) {
            this.formTouchAll((/** @type {?} */ (this.container.formDirective)).form);
        }
        else {
            throw new Error('Use kitFormTouch inside NgForm or FormGroup');
        }
    }
    /**
     * Touches all FormGroup controls and controls in nested FormGroups at any level.
     * @param {?} form
     * @param {?=} revalidate
     * @return {?}
     */
    formTouchAll(form, revalidate) {
        form.markAsTouched();
        for (const /** @type {?} */ i in form.controls) {
            if (form.controls.hasOwnProperty(i)) {
                const /** @type {?} */ control = form.controls[i];
                if (control) {
                    control.markAsTouched();
                    if (control instanceof FormGroup) {
                        this.formTouchAll(control);
                    }
                    else if (revalidate) {
                        control.setValue(control.value);
                    }
                }
            }
        }
    }
}
KitFormTouchDirective.decorators = [
    { type: Directive, args: [{
                // tslint:disable-next-line
                selector: '[kitFormTouch]',
            },] },
];
/** @nocollapse */
KitFormTouchDirective.ctorParameters = () => [
    { type: ControlContainer, decorators: [{ type: Optional },] },
];
KitFormTouchDirective.propDecorators = {
    "clickHandler": [{ type: HostListener, args: ['click',] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitFormTouchModule {
}
KitFormTouchModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitFormTouchDirective,
                ],
                exports: [
                    KitFormTouchDirective,
                ],
                providers: [],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @template T
 */
class KitHammerProvider {
    /**
     * @param {?} platform
     */
    constructor(platform) {
        this.platform = platform;
        this._hammer = null;
        if (this.platform.isBrowser()) {
            if (window && 'Hammer' in window) {
                this._hammer = (/** @type {?} */ (window))['Hammer'];
            }
        }
    }
    /**
     * Get Hammer.JS.
     * Returns null if not available.
     * @return {?}
     */
    get hammer() {
        return this._hammer;
    }
    /**
     * Get event position relative to passed element, not the viewport.
     * @param {?} el
     * @param {?} center
     * @return {?}
     */
    calcRelatedPosition(el, center) {
        const /** @type {?} */ rect = el.getBoundingClientRect();
        return {
            x: center.x - rect.left,
            y: center.y - rect.top,
        };
    }
}
KitHammerProvider.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitHammerProvider.ctorParameters = () => [
    { type: KitPlatformService, },
];
/** @nocollapse */ KitHammerProvider.ngInjectableDef = defineInjectable({ factory: function KitHammerProvider_Factory() { return new KitHammerProvider(inject(KitPlatformService)); }, token: KitHammerProvider, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var KitHammerTypes;
(function (KitHammerTypes) {
    KitHammerTypes.INPUT_TYPE_TOUCH = 'touch';
    KitHammerTypes.INPUT_TYPE_PEN = 'pen';
    KitHammerTypes.INPUT_TYPE_MOUSE = 'mouse';
    KitHammerTypes.INPUT_TYPE_KINECT = 'kinect';
    KitHammerTypes.COMPUTE_INTERVAL = 25;
    KitHammerTypes.INPUT_START = 1;
    KitHammerTypes.INPUT_MOVE = 2;
    KitHammerTypes.INPUT_END = 4;
    KitHammerTypes.INPUT_CANCEL = 8;
    KitHammerTypes.DIRECTION_NONE = 1;
    KitHammerTypes.DIRECTION_LEFT = 2;
    KitHammerTypes.DIRECTION_RIGHT = 4;
    KitHammerTypes.DIRECTION_UP = 8;
    KitHammerTypes.DIRECTION_DOWN = 16;
    KitHammerTypes.DIRECTION_HORIZONTAL = KitHammerTypes.DIRECTION_LEFT | KitHammerTypes.DIRECTION_RIGHT;
    KitHammerTypes.DIRECTION_VERTICAL = KitHammerTypes.DIRECTION_UP | KitHammerTypes.DIRECTION_DOWN;
    KitHammerTypes.DIRECTION_ALL = KitHammerTypes.DIRECTION_HORIZONTAL | KitHammerTypes.DIRECTION_VERTICAL;
})(KitHammerTypes || (KitHammerTypes = {}));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Should be provided on a component or a directive.
 */
class KitIntersectionService {
    /**
     * @param {?} elementRef
     * @param {?} platform
     */
    constructor(elementRef, platform) {
        this.elementRef = elementRef;
        this.platform = platform;
        this.observer = new BehaviorSubject(false);
    }
    /**
     * @return {?}
     */
    get isIntersecting() {
        return this.observer.value;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.io) {
            this.io.disconnect();
        }
    }
    /**
     * @return {?}
     */
    observe() {
        if (this.platform.isBrowser() && 'IntersectionObserver' in window) {
            if (!this.io) {
                this.initObserver();
            }
            return this.observer.asObservable();
        }
        else {
            return from([null]);
        }
    }
    /**
     * @return {?}
     */
    initObserver() {
        this.io = new IntersectionObserver((data) => {
            this.observer.next(data && data[0] && data[0].isIntersecting);
        });
        this.io.observe(this.elementRef.nativeElement);
    }
}
KitIntersectionService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitIntersectionService.ctorParameters = () => [
    { type: ElementRef, },
    { type: KitPlatformService, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const isArray = Array.isArray || ((x) => x && typeof x.length === 'number');

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Icons registry.
 *
 * ```typescript
 * this.iconsRegistry.add({name: 'star', url: '/assets/icons/star.svg'});
 * // or
 * this.iconsRegistry.add([
 * {name: 'star', url: '/assets/icons/star.svg'},
 * {name: 'cloud', url: '/assets/icons/cloud.svg'},
 * ]);
 * ```
 *
 * Use in a template
 *
 * ```html
 * <kit-icon name="star"></kit-icon>
 * ```
 */
class KitIconsRegistryService {
    /**
     * @param {?} http
     */
    constructor(http) {
        this.http = http;
        this.cache = [];
        this.icons = [];
    }
    /**
     * Add icons to registry.
     * @param {?} icon
     * @return {?}
     */
    add(icon) {
        const /** @type {?} */ icons = isArray(icon) ? icon : [icon];
        // Validate
        icons.forEach(i => {
            if (!i.url && !i.xml) {
                throw new Error('KitIconsRegistryService: icon registration requires url or xml.');
            }
        });
        // Merge
        this.icons = [...this.icons, ...icons];
    }
    /**
     * Get icon by name.
     *
     * \@internal
     * @param {?} name
     * @return {?}
     */
    get(name) {
        const /** @type {?} */ icon = this.icons.find(i => i.name === name);
        if (icon) {
            // Init cache
            const /** @type {?} */ fromCache = this.cache.find(c => c.name === name);
            const /** @type {?} */ cached = fromCache
                ? fromCache
                : {
                    name,
                    svg: new BehaviorSubject(null),
                };
            if (!fromCache) {
                // Add cached to the pull
                this.cache.push(cached);
                if (icon.url) {
                    // Fetch
                    return this.http.get(icon.url, { responseType: 'text' })
                        .pipe(tap(svg => cached.svg.next(svg)), map(svg => ({ svg, size: icon.size })));
                }
                else if (icon.xml) {
                    // Register xml
                    cached.svg.next(icon.xml);
                }
            }
            // Return stream
            return cached.svg
                .asObservable()
                .pipe(filter(svg => svg !== null), take(1), map((svg) => ({ svg, size: icon.size })));
        }
        else {
            throw new Error(`Icon "${name}" not found!`);
        }
    }
}
KitIconsRegistryService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitIconsRegistryService.ctorParameters = () => [
    { type: HttpClient, },
];
/** @nocollapse */ KitIconsRegistryService.ngInjectableDef = defineInjectable({ factory: function KitIconsRegistryService_Factory() { return new KitIconsRegistryService(inject(HttpClient)); }, token: KitIconsRegistryService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitIconComponent {
    /**
     * @param {?} registry
     * @param {?} el
     * @param {?} renderer
     * @param {?} platform
     * @param {?} intersection
     */
    constructor(registry, el, renderer, platform, intersection) {
        this.registry = registry;
        this.el = el;
        this.renderer = renderer;
        this.platform = platform;
        this.intersection = intersection;
        /**
         * Svg fill color.
         */
        this.color = 'currentcolor';
        /**
         * Load and render icon only when visible.
         */
        this.intersectionLoad = false;
        this.nameChanges = new Subject();
        this.destroy = new Subject();
        this.nameChanges
            .pipe(takeUntil(this.destroy), switchMap(name => {
            // Debounce icon load until being visible (if needed).
            return this.intersectionLoad
                ? this.intersection.observe().pipe(filter(Boolean), take(1), mapTo(name))
                : from([name]);
        }), switchMap(name => this.registry.get(name)))
            .subscribe((source) => {
            this.source = source;
            this.svg = this.svgElementFromString(this.source.svg);
            this.clear();
            this.updateStyles();
            this.updateA11y();
            this.mount();
        });
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if ('name' in changes) {
            this.nameChanges.next(this.name);
        }
        if ('size' in changes || 'color' in changes) {
            this.updateStyles();
        }
        if ('title' in changes || 'desc' in changes) {
            this.updateA11y();
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.destroy.next();
    }
    /**
     * @return {?}
     */
    clear() {
        if (this.platform.isBrowser()) {
            const /** @type {?} */ el = this.el.nativeElement;
            while (el.hasChildNodes() && el.lastChild) {
                el.removeChild(el.lastChild);
            }
        }
        this.titleEl = null;
        this.descEl = null;
    }
    /**
     * @return {?}
     */
    updateStyles() {
        if (this.source && this.svg) {
            let /** @type {?} */ height;
            let /** @type {?} */ width;
            let /** @type {?} */ position;
            let /** @type {?} */ top;
            const /** @type {?} */ size = this.size || this.source.size;
            if (size) {
                if (isArray(size)) {
                    height = size[0];
                    width = size[1];
                }
                else {
                    height = size;
                    width = size;
                }
            }
            else {
                height = '1em';
                width = '1em';
            }
            // Fix position if height is 1em (default inline sizing)
            if (height === '1em') {
                position = 'relative';
                top = '.125em';
            }
            else {
                position = 'static';
                top = 'auto';
            }
            // Set props
            this.renderer.setStyle(this.svg, 'fill', this.color);
            this.renderer.setStyle(this.svg, 'height', height);
            this.renderer.setStyle(this.svg, 'position', position);
            this.renderer.setStyle(this.svg, 'top', top);
            this.renderer.setStyle(this.svg, 'width', width);
        }
    }
    /**
     * Creates a DOM element from the given SVG string.
     * @param {?} str
     * @return {?}
     */
    svgElementFromString(str) {
        const /** @type {?} */ div = this.renderer.createElement('div');
        div.innerHTML = str;
        const /** @type {?} */ svg = /** @type {?} */ (div.querySelector('svg'));
        if (svg) {
            return svg;
        }
        else {
            throw new Error(`SVG has not been rendered from "${str}"`);
        }
    }
    /**
     * @return {?}
     */
    updateA11y() {
        if (this.source && this.svg) {
            this.renderer.setAttribute(this.svg, 'role', 'img');
            if (this.title) {
                if (!this.titleEl) {
                    this.titleEl = this.renderer.createElement('title');
                    const /** @type {?} */ titleId = uuid();
                    this.renderer.setAttribute(this.titleEl, 'id', titleId);
                    this.renderer.insertBefore(this.svg, this.titleEl, this.svg.childNodes[0]);
                }
                this.titleEl.innerHTML = this.title;
            }
            if (this.desc) {
                if (!this.descEl) {
                    this.descEl = this.renderer.createElement('desc');
                    const /** @type {?} */ descId = uuid();
                    this.renderer.setAttribute(this.descEl, 'id', descId);
                    this.renderer.appendChild(this.svg, this.descEl);
                }
                this.descEl.innerHTML = this.desc;
            }
            this.renderer.setAttribute(this.svg, 'aria-labelledby', `${this.titleEl ? this.titleEl.id : ''} ${this.descEl ? this.descEl.id : ''}`);
        }
    }
    /**
     * @return {?}
     */
    mount() {
        this.renderer.appendChild(this.el.nativeElement, this.svg);
    }
}
KitIconComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-icon',
                template: `
    <ng-content></ng-content>
  `,
                styles: [`
    :host {
      display: inline-flex;
      align-self: center;
    }
  `],
                providers: [
                    KitIntersectionService,
                ],
                changeDetection: ChangeDetectionStrategy.OnPush,
            },] },
];
/** @nocollapse */
KitIconComponent.ctorParameters = () => [
    { type: KitIconsRegistryService, },
    { type: ElementRef, },
    { type: Renderer2, },
    { type: KitPlatformService, },
    { type: KitIntersectionService, },
];
KitIconComponent.propDecorators = {
    "color": [{ type: Input },],
    "name": [{ type: Input },],
    "size": [{ type: Input },],
    "title": [{ type: Input },],
    "desc": [{ type: Input },],
    "intersectionLoad": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * \@todo register icons in forRoot().
 */
class KitIconsModule {
}
KitIconsModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    HttpClientModule,
                ],
                exports: [
                    KitIconComponent,
                ],
                declarations: [
                    KitIconComponent,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @template T
 */
class KitMomentProvider {
    /**
     * @param {?} platform
     */
    constructor(platform) {
        this.platform = platform;
        this._moment = null;
        if (this.platform.isBrowser()) {
            if (window && 'moment' in window) {
                this._moment = (/** @type {?} */ (window))['moment'];
            }
        }
    }
    /**
     * Get Moment.js instance.
     * Returns null if not available.
     * @return {?}
     */
    get moment() {
        return this._moment;
    }
}
KitMomentProvider.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitMomentProvider.ctorParameters = () => [
    { type: KitPlatformService, },
];
/** @nocollapse */ KitMomentProvider.ngInjectableDef = defineInjectable({ factory: function KitMomentProvider_Factory() { return new KitMomentProvider(inject(KitPlatformService)); }, token: KitMomentProvider, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @abstract
 */
class KitModelInterceptor {
}
KitModelInterceptor.decorators = [
    { type: Injectable },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitInputDateDirective {
    /**
     * @param {?} momentProvider
     */
    constructor(momentProvider) {
        this.momentProvider = momentProvider;
        /**
         * `Date.toLocaleDateString()` options.
         */
        this.options = {};
        this.viewStateChanges = new Subject();
        this.modelStateChanges = new Subject();
        this.moment = null;
        this.moment = this.momentProvider.moment;
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        if (this.format && !this.moment) {
            throw new Error('KitInputDateDirective: Format option requires moment.js!\n' +
                '==========\n' +
                'Possible solution:\n' +
                '  1. Install moment: npm install moment\n' +
                '  2. Add "node_modules/moment/moment.js" to angular.json scripts section.\n' +
                '==========\n');
        }
    }
    /**
     * Handle input changing by user.
     * @param {?} value
     * @param {?} event
     * @return {?}
     */
    input(value, event) {
        const /** @type {?} */ date = this.parse(value);
        this.modelStateChanges.next(this.isValid(date) ? date : null);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    keyDown(event) {
    }
    /**
     * Handle external modal changing.
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        const /** @type {?} */ date = this.parse(value);
        this.viewStateChanges.next(this.isValid(date)
            ? this.moment && this.format ? this.moment(date).format(this.format) : date.toDateString()
            : '');
    }
    /**
     * @param {?} raw
     * @return {?}
     */
    parse(raw) {
        return this.moment && this.format
            ? this.moment(raw, this.format).toDate()
            : new Date(Date.parse(raw));
    }
    /**
     * @param {?} raw
     * @return {?}
     */
    isValid(raw) {
        const /** @type {?} */ date = new Date(raw);
        return !isNaN(date.getTime());
    }
}
KitInputDateDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitInputDate]',
                providers: [
                    {
                        provide: KitModelInterceptor,
                        useExisting: forwardRef(() => KitInputDateDirective),
                    },
                ],
            },] },
];
/** @nocollapse */
KitInputDateDirective.ctorParameters = () => [
    { type: KitMomentProvider, },
];
KitInputDateDirective.propDecorators = {
    "kitInputDate": [{ type: Input },],
    "options": [{ type: Input },],
    "format": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitDefaultModelInterceptor {
    constructor() {
        this.viewStateChanges = new Subject();
        this.modelStateChanges = new Subject();
    }
    /**
     * @param {?} value
     * @param {?} event
     * @return {?}
     */
    input(value, event) {
        this.modelStateChanges.next(value);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    keyDown(event) {
    }
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        this.viewStateChanges.next(value);
    }
}
KitDefaultModelInterceptor.decorators = [
    { type: Injectable },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Service directive, injects middleware.
 */
// tslint:disable-next-line
class KitValueAccessorDirective {
    /**
     * @param {?} renderer
     * @param {?} el
     * @param {?} injInterceptor
     * @param {?} defaultInterceptor
     */
    constructor(renderer, el, injInterceptor, defaultInterceptor) {
        this.renderer = renderer;
        this.el = el;
        this.injInterceptor = injInterceptor;
        this.defaultInterceptor = defaultInterceptor;
        this.changes$ = new Subject();
        this.touches$ = new Subject();
        this.interceptor = this.injInterceptor || this.defaultInterceptor;
        this.interceptor.modelStateChanges.subscribe(this.changes$);
        this.interceptor.viewStateChanges.subscribe((value) => {
            this.renderer.setProperty(this.el.nativeElement, 'value', value || '');
        });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    inputHandler(event) {
        this.interceptor.input(event.target.value, event);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    keydownHandler(event) {
        this.interceptor.keyDown(event);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    blurHandler(event) {
        this.touches$.next();
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.changes$.subscribe(fn);
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this.touches$.subscribe(fn);
    }
    /**
     * @param {?} isDisabled
     * @return {?}
     */
    setDisabledState(isDisabled) {
        this.renderer.setProperty(this.el.nativeElement, 'disabled', isDisabled);
    }
    /**
     * @param {?} rawValue
     * @return {?}
     */
    writeValue(rawValue) {
        this.interceptor.writeValue(rawValue);
    }
}
KitValueAccessorDirective.decorators = [
    { type: Directive, args: [{
                // tslint:disable-next-line
                selector: `
    input:not([type=checkbox]):not([type=radio])[formControlName],
    textarea[formControlName],
    input:not([type=checkbox]):not([type=radio])[formControl],
    textarea[formControl],
    input:not([type=checkbox]):not([type=radio])[ngModel],
    textarea[ngModel],
    [ngDefaultControl]
  `,
                providers: [
                    KitDefaultModelInterceptor,
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => KitValueAccessorDirective),
                        multi: true,
                    },
                ],
            },] },
];
/** @nocollapse */
KitValueAccessorDirective.ctorParameters = () => [
    { type: Renderer2, },
    { type: ElementRef, },
    { type: KitModelInterceptor, decorators: [{ type: Inject, args: [KitModelInterceptor,] }, { type: Optional },] },
    { type: KitDefaultModelInterceptor, },
];
KitValueAccessorDirective.propDecorators = {
    "inputHandler": [{ type: HostListener, args: ['input', ['$event'],] },],
    "keydownHandler": [{ type: HostListener, args: ['keydown', ['$event'],] },],
    "blurHandler": [{ type: HostListener, args: ['blur', ['$event'],] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitValueAccessorModule {
}
KitValueAccessorModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitValueAccessorDirective,
                ],
                exports: [
                    KitValueAccessorDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitInputDateModule {
}
KitInputDateModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitValueAccessorModule,
                    KitInputDateDirective,
                ],
                declarations: [
                    KitInputDateDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitIntersectionDirective {
    /**
     * @param {?} intersection
     */
    constructor(intersection) {
        this.intersection = intersection;
        this.kitIntersection = new EventEmitter();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.intersection.observe().subscribe(isIntersecting => {
            this.kitIntersection.emit(!!isIntersecting);
        });
    }
}
KitIntersectionDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitIntersection]',
                providers: [
                    KitIntersectionService,
                ],
            },] },
];
/** @nocollapse */
KitIntersectionDirective.ctorParameters = () => [
    { type: KitIntersectionService, },
];
KitIntersectionDirective.propDecorators = {
    "kitIntersection": [{ type: Output },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitIntersectionModule {
}
KitIntersectionModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    KitIntersectionDirective,
                ],
                exports: [
                    KitIntersectionDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const kitLoadingGlobal = 'global';
/** @enum {string} */
const KitLoadingState = {
    InProgress: 'in-progress',
    None: 'none',
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitLoadingProgress {
    /**
     * @param {?} id
     */
    constructor(id) {
        this.id = id;
        this.current = new Set();
        this._state = KitLoadingState.None;
        this._stateChanges = new Subject();
    }
    /**
     * @return {?}
     */
    get state() {
        return this._state;
    }
    /**
     * @return {?}
     */
    get stateChanges() {
        return this._stateChanges.asObservable();
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    start(key) {
        this.current.add(key || uuid());
        this.checkState();
        return () => {
            this.end(key);
        };
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    end(key) {
        if (key) {
            this.current.delete(key);
        }
        else {
            this.current.clear();
        }
        this.checkState();
    }
    /**
     * @return {?}
     */
    checkState() {
        if (this.current.size > 0 && this._state === KitLoadingState.None) {
            this.setState(KitLoadingState.InProgress);
        }
        if (this.current.size === 0 && this._state === KitLoadingState.InProgress) {
            this.setState(KitLoadingState.None);
        }
    }
    /**
     * @param {?} state
     * @return {?}
     */
    setState(state) {
        this._state = state;
        this._stateChanges.next(this._state);
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitLoadingService {
    /**
     * @param {?} router
     */
    constructor(router) {
        this.router = router;
        this.progresses = new Map();
        // create global progress
        const /** @type {?} */ globalProgress = this.progress(kitLoadingGlobal);
        // subscribe globalProgress to router events
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                globalProgress.start('routing');
            }
            if (event instanceof NavigationEnd) {
                globalProgress.end('routing');
            }
        });
    }
    /**
     * @return {?}
     */
    get global() {
        return this.progress(kitLoadingGlobal);
    }
    /**
     * @param {?} id
     * @return {?}
     */
    progress(id) {
        if (this.progresses.has(id)) {
            return /** @type {?} */ (this.progresses.get(id));
        }
        else {
            const /** @type {?} */ progress = new KitLoadingProgress(id);
            this.progresses.set(id, progress);
            return progress;
        }
    }
}
KitLoadingService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitLoadingService.ctorParameters = () => [
    { type: Router, },
];
/** @nocollapse */ KitLoadingService.ngInjectableDef = defineInjectable({ factory: function KitLoadingService_Factory() { return new KitLoadingService(inject(Router)); }, token: KitLoadingService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const kitMqBreakpoints = new InjectionToken('kitMqPoints');
/**
 * @record
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const breakpointsError = 'Provide breakpoints for KitMqService:\n' +
    'providers: [\n' +
    '  {\n' +
    '    provide: kitMqBreakpoints,\n' +
    '    useValue: {\n' +
    '      mobile: \'320px\',\n' +
    '      tablet: \'740px\',\n' +
    '      desktop: \'980px\',\n' +
    '      wide: \'1300px\',\n' +
    '    }\n' +
    '  }\n' +
    ']';
/**
 * \@todo remove mq observer on destroy
 */
class KitMqService {
    /**
     * @param {?} platform
     * @param {?} breakpoints
     */
    constructor(platform, breakpoints) {
        this.platform = platform;
        this.breakpoints = breakpoints;
        this.mqs = new Map();
        if (!this.breakpoints) {
            throw new Error(breakpointsError);
        }
        if (this.platform.isBrowser() && 'matchMedia' in window) {
            this.matchMedia = window.matchMedia.bind(window);
        }
    }
    /**
     * @param {?} params
     * @return {?}
     */
    check(params) {
        return this.checkRaw(this.buildQuery(params));
    }
    /**
     * @param {?} mediaQuery
     * @return {?}
     */
    checkRaw(mediaQuery) {
        if (this.matchMedia) {
            const /** @type {?} */ mq = this.getMq(mediaQuery);
            return mq.matches;
        }
        else {
            return null;
        }
    }
    /**
     * @param {?} params
     * @return {?}
     */
    observe(params) {
        return this.observeRaw(this.buildQuery(params));
    }
    /**
     * @param {?} mediaQuery
     * @return {?}
     */
    observeRaw(mediaQuery) {
        return new Observable((observer) => {
            if (this.matchMedia) {
                const /** @type {?} */ listener = (mql) => {
                    observer.next(mql.matches);
                };
                const /** @type {?} */ mq = this.getMq(mediaQuery);
                observer.next(mq.matches);
                mq.addListener(listener);
            }
            else {
                observer.next(null);
                observer.complete();
            }
        });
    }
    /**
     * @param {?} params
     * @return {?}
     */
    buildQuery(params) {
        if (!params.from && !params.until) {
            throw new Error(`KitMqService: invalid mq params`);
        }
        let /** @type {?} */ query = '';
        // Compile media type
        if (params.type) {
            query = `${params.type}`;
        }
        // Compile from
        if (params.from) {
            if (!this.breakpoints[params.from]) {
                throw new Error(`KitMqService: breakpoint "${params.from}" has not been registered!`);
            }
            query = this.concatQuery(query, `(min-width: ${this.breakpoints[params.from]})`);
        }
        // Compile until
        if (params.until) {
            if (!this.breakpoints[params.until]) {
                throw new Error(`KitMqService: breakpoint "${params.until}" has not been registered!`);
            }
            query = this.concatQuery(query, `(max-width: ${this.breakpoints[params.until]})`);
        }
        // Compile "and"
        if (params.and) {
            query = this.concatQuery(query, params.and);
        }
        return query;
    }
    /**
     * @param {?} query
     * @param {?} attach
     * @return {?}
     */
    concatQuery(query, attach) {
        return query && query.length > 0 ? `${query} and ${attach}` : attach;
    }
    /**
     * @param {?} query
     * @return {?}
     */
    getMq(query) {
        let /** @type {?} */ mq = this.mqs.get(query);
        if (!mq) {
            mq = this.matchMedia(query);
            this.mqs.set(query, mq);
        }
        return mq;
    }
}
KitMqService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitMqService.ctorParameters = () => [
    { type: KitPlatformService, },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [kitMqBreakpoints,] },] },
];
/** @nocollapse */ KitMqService.ngInjectableDef = defineInjectable({ factory: function KitMqService_Factory() { return new KitMqService(inject(KitPlatformService), inject(kitMqBreakpoints, 8)); }, token: KitMqService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitMqDirective {
    /**
     * @param {?} templateRef
     * @param {?} cdr
     * @param {?} vcr
     * @param {?} mq
     */
    constructor(templateRef, cdr, vcr, mq) {
        this.templateRef = templateRef;
        this.cdr = cdr;
        this.vcr = vcr;
        this.mq = mq;
    }
    /**
     * @return {?}
     */
    get viewRef() {
        return this._viewRef;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['kitMq']) {
            if (this.subscription) {
                this.subscription.unsubscribe();
            }
            this.subscription = this.mq.observe(this.kitMq)
                .subscribe(matches => {
                this.updateHost(!!matches);
                this.cdr.detectChanges();
            });
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.destroyView();
    }
    /**
     * @param {?} matches
     * @return {?}
     */
    updateHost(matches) {
        if (matches && !this._viewRef) {
            this._viewRef = this.vcr.createEmbeddedView(this.templateRef);
        }
        else if (!matches) {
            this.destroyView();
        }
    }
    /**
     * @return {?}
     */
    destroyView() {
        if (this._viewRef) {
            this._viewRef.destroy();
            this._viewRef = null;
        }
    }
}
KitMqDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitMq]',
            },] },
];
/** @nocollapse */
KitMqDirective.ctorParameters = () => [
    { type: TemplateRef, },
    { type: ChangeDetectorRef, },
    { type: ViewContainerRef, },
    { type: KitMqService, },
];
KitMqDirective.propDecorators = {
    "kitMq": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitMqModule {
}
KitMqModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    KitMqDirective,
                ],
                exports: [
                    KitMqDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitModalBackdropComponent {
    /**
     * @param {?} cdr
     */
    constructor(cdr) {
        this.cdr = cdr;
        this.close = new EventEmitter();
        this._display = false;
    }
    /**
     * @return {?}
     */
    get display() {
        return this._display;
    }
    /**
     * @param {?} display
     * @return {?}
     */
    set display(display) {
        if (display !== this._display) {
            this._display = display;
            this.cdr.detectChanges();
        }
    }
}
KitModalBackdropComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-modal-backdrop',
                template: `
    <div *ngIf="display"
         class="backdrop"
         [@fade]="true"
         (click)="close.emit()">
    </div>
  `,
                styles: [`
    .backdrop {
      background: rgba(0, 0, 0, .4);
      position: fixed;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
    }
  `],
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('fade', [
                        transition(':enter', [
                            style({
                                opacity: 0,
                            }),
                            animate('150ms ease-out', style({
                                opacity: 1,
                            })),
                        ]),
                        transition(':leave', [
                            style({ opacity: 1 }),
                            animate('150ms ease-in', style({
                                opacity: 0,
                            })),
                        ]),
                    ]),
                ],
            },] },
];
/** @nocollapse */
KitModalBackdropComponent.ctorParameters = () => [
    { type: ChangeDetectorRef, },
];
KitModalBackdropComponent.propDecorators = {
    "close": [{ type: Output },],
    "display": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @template T
 */
class KitOverlayComponentRef {
    /**
     * Pass input to the hosted component.
     * @param {?} input
     * @return {?}
     */
    input(input) {
        if (this.componentRef && this.componentRef.instance) {
            // Set props and gather changes object
            const /** @type {?} */ changes = {};
            for (const /** @type {?} */ name in input) {
                if (input.hasOwnProperty(name)) {
                    const /** @type {?} */ prev = this.componentRef.instance[name];
                    // @ts-ignore
                    this.componentRef.instance[name] = input[name];
                    changes[name] = new SimpleChange(prev, input[name], false);
                }
            }
            // Emit ngOnChanges hook
            if (this.componentRef.instance['ngOnChanges']) {
                this.componentRef.instance['ngOnChanges'](changes);
            }
            // Run change detection on the component host (for applying host bindings)
            this.componentRef.changeDetectorRef.detectChanges();
            // Run change detection inside component
            this.componentRef.injector.get(/** @type {?} */ (ChangeDetectorRef)).detectChanges();
        }
        else {
            throw new Error('Modal initiated without instance. Input could be passed programmatically only for ' +
                'service-hosted modals.');
        }
    }
}
KitOverlayComponentRef.decorators = [
    { type: Injectable },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOverlayHostWrapperComponent {
    /**
     * @param {?} vcr
     */
    constructor(vcr) {
        this.vcr = vcr;
    }
}
KitOverlayHostWrapperComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-overlay-host-wrapper',
                template: '',
                changeDetection: ChangeDetectionStrategy.OnPush,
            },] },
];
/** @nocollapse */
KitOverlayHostWrapperComponent.ctorParameters = () => [
    { type: ViewContainerRef, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOverlayHostComponent {
    /**
     * @param {?} zone
     * @param {?} vcr
     * @param {?} cdr
     * @param {?} elRef
     */
    constructor(zone, vcr, cdr, elRef) {
        this.zone = zone;
        this.vcr = vcr;
        this.cdr = cdr;
        this.elRef = elRef;
    }
}
KitOverlayHostComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-overlay-host',
                template: '',
                changeDetection: ChangeDetectionStrategy.OnPush,
            },] },
];
/** @nocollapse */
KitOverlayHostComponent.ctorParameters = () => [
    { type: NgZone, },
    { type: ViewContainerRef, },
    { type: ChangeDetectorRef, },
    { type: ElementRef, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOverlayService {
    /**
     * @param {?} document
     * @param {?} cfr
     * @param {?} injector
     * @param {?} parent
     * @param {?} platform
     */
    constructor(document, cfr, injector, parent, platform) {
        this.document = document;
        this.cfr = cfr;
        this.injector = injector;
        this.parent = parent;
        this.platform = platform;
        this._onHostStable = new Subject();
        this.isRoot = !this.parent;
        if (this.isRoot) {
            this.mountHost();
        }
    }
    /**
     * @return {?}
     */
    get onHostStable() {
        return this.isRoot
            ? this._onHostStable.asObservable()
            : this.parent.onHostStable;
    }
    /**
     * Render component in the overlay.
     * @template T
     * @param {?} __0
     * @return {?}
     */
    hostComponent({ component, providers = [], componentFactoryResolver, viewContainerRef }) {
        if (this.isRoot) {
            // Pick passed vcr or from host
            const /** @type {?} */ hostVcr = viewContainerRef || this.host.vcr;
            // Provide passed providers and parent injector
            const /** @type {?} */ injector = Injector.create({
                providers,
                parent: hostVcr.injector,
            });
            // Create component
            const /** @type {?} */ componentFactory = componentFactoryResolver
                ? componentFactoryResolver.resolveComponentFactory(component)
                : this.cfr.resolveComponentFactory(component);
            const /** @type {?} */ ref = new KitOverlayComponentRef();
            ref.componentRef = hostVcr.createComponent(componentFactory, hostVcr.length, injector);
            // Move component to the host
            this.host.elRef.nativeElement.appendChild(this.getComponentRootNode(ref.componentRef));
            // Force change detection
            ref.componentRef.changeDetectorRef.detectChanges();
            // Proxy CD to the hosted component from host
            const /** @type {?} */ cdSub = hostVcr.injector.get(NgZone).onStable
                .subscribe(() => {
                ref.componentRef.changeDetectorRef.detectChanges();
            });
            ref.componentRef.onDestroy(() => {
                cdSub.unsubscribe();
            });
            // Return the ref
            return ref;
        }
        else {
            // Proxy to root
            return this.parent.hostComponent({ component, providers, componentFactoryResolver, viewContainerRef });
        }
    }
    /**
     * Render template (passed by TemplateRef) on the overlay.
     * @param {?} __0
     * @return {?}
     */
    hostTemplate({ templateRef, context = {}, viewContainerRef }) {
        if (this.isRoot) {
            const /** @type {?} */ hostVcr = viewContainerRef || this.host.vcr;
            const /** @type {?} */ ref = hostVcr.createEmbeddedView(templateRef, context);
            this.host.elRef.nativeElement.appendChild(this.getTemplateRootNode(ref));
            return ref;
        }
        else {
            return this.parent.hostTemplate({ templateRef, context, viewContainerRef });
        }
    }
    /**
     * Move passed ViewRef under target ViewRef.
     * Used for multi-modals backdrop handling.
     * @param {?} ref
     * @param {?} target
     * @return {?}
     */
    moveUnder(ref, target) {
        if (this.isRoot) {
            this.getTemplateRootNode(this.hostRef.hostView)
                .insertBefore(this.getTemplateRootNode(ref), this.getTemplateRootNode(target));
        }
        else {
            this.parent.moveUnder(ref, target);
        }
    }
    /**
     * Gets the root HTMLElement for an instantiated component.
     * @param {?} componentRef
     * @return {?}
     */
    getComponentRootNode(componentRef) {
        return this.getTemplateRootNode(componentRef.hostView);
    }
    /**
     * @param {?} viewRef
     * @return {?}
     */
    getTemplateRootNode(viewRef) {
        return /** @type {?} */ ((/** @type {?} */ (viewRef)).rootNodes[0]);
    }
    /**
     * @return {?}
     */
    mountHost() {
        if (!this.isRoot) {
            throw new Error(`Run .mountHost() only for root service`);
        }
        // Init container
        this.container = this.document.createElement('div');
        // Append container, only in browser
        if (this.platform.isBrowser()) {
            this.container.classList.add('kit-overlay-container');
            this.document.body.appendChild(this.container);
        }
        // Create host-wrapper
        const /** @type {?} */ hostWrapperFactory = this.cfr.resolveComponentFactory(KitOverlayHostWrapperComponent);
        this.hostWrapperRef = hostWrapperFactory.create(this.injector);
        this.container.appendChild(this.getComponentRootNode(this.hostWrapperRef));
        // Create host
        const /** @type {?} */ hostFactory = this.cfr.resolveComponentFactory(KitOverlayHostComponent);
        const /** @type {?} */ wrapperVcr = this.hostWrapperRef.instance.vcr;
        this.hostRef = wrapperVcr.createComponent(hostFactory, wrapperVcr.length, this.injector);
        this.host = this.hostRef.instance;
        this.container.appendChild(this.getComponentRootNode(this.hostRef));
        // Track CD
        this.host.zone.onStable.subscribe(() => {
            this._onHostStable.next();
        });
    }
}
KitOverlayService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitOverlayService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] },] },
    { type: ComponentFactoryResolver, },
    { type: Injector, },
    { type: KitOverlayService, decorators: [{ type: Optional }, { type: Inject, args: [forwardRef(() => KitOverlayService),] }, { type: SkipSelf },] },
    { type: KitPlatformService, },
];
/** @nocollapse */ KitOverlayService.ngInjectableDef = defineInjectable({ factory: function KitOverlayService_Factory() { return new KitOverlayService(inject(DOCUMENT), inject(ComponentFactoryResolver), inject(INJECTOR), inject(KitOverlayService, 12), inject(KitPlatformService)); }, token: KitOverlayService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOverlayDirective {
    /**
     * @param {?} templateRef
     * @param {?} service
     * @param {?} cdr
     * @param {?} vcr
     */
    constructor(templateRef, service, cdr, vcr) {
        this.templateRef = templateRef;
        this.service = service;
        this.cdr = cdr;
        this.vcr = vcr;
        this._displayed = new BehaviorSubject(false);
    }
    /**
     * @return {?}
     */
    get displayed() {
        return this._displayed.asObservable();
    }
    /**
     * @return {?}
     */
    get viewRef() {
        return this._viewRef;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['kitOverlay']) {
            this.updateHost();
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.destroyView();
    }
    /**
     * @return {?}
     */
    updateHost() {
        if (this.kitOverlay && !this._viewRef) {
            this._viewRef = this.service.hostTemplate({
                templateRef: this.templateRef,
                viewContainerRef: this.vcr,
            });
            this._viewRef.detectChanges();
            this.doCheckSub = this.service.onHostStable.subscribe(() => {
                if (!this.cdr['destroyed']) {
                    this.cdr.detectChanges();
                }
            });
            this._displayed.next(true);
        }
        else if (!this.kitOverlay) {
            this.destroyView();
            this._displayed.next(false);
        }
    }
    /**
     * @return {?}
     */
    destroyView() {
        if (this._viewRef) {
            this._viewRef.destroy();
            this._viewRef = null;
        }
        if (this.doCheckSub) {
            this.doCheckSub.unsubscribe();
        }
    }
}
KitOverlayDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitOverlay]',
            },] },
];
/** @nocollapse */
KitOverlayDirective.ctorParameters = () => [
    { type: TemplateRef, },
    { type: KitOverlayService, },
    { type: ChangeDetectorRef, },
    { type: ViewContainerRef, },
];
KitOverlayDirective.propDecorators = {
    "kitOverlay": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @template T
 */
class KitModalRef {
    constructor() {
        /**
         * \@internal
         */
        this.id = uuid();
        this.onClose = new Subject();
        this.onDestroy = new Subject();
        this._options = {};
    }
    /**
     * @return {?}
     */
    get options() {
        return this._options;
    }
    /**
     * @param {?} options
     * @return {?}
     */
    set options(options) {
        this._options = Object.assign({}, options);
    }
    /**
     * @return {?}
     */
    get instance() {
        if (this.componentRef) {
            return this.componentRef.componentRef.instance;
        }
        else {
            throw new Error('Modal initiated without instance.');
        }
    }
    /**
     * \@internal
     * @param {?} params
     * @return {?}
     */
    applyParams(params) {
        this._options = Object.assign({}, this.options, params);
    }
    /**
     * Emit close event.
     * @return {?}
     */
    close() {
        this.onClose.next();
    }
    /**
     * Pass input to the hosted component.
     * @param {?} input
     * @return {?}
     */
    input(input) {
        if (this.componentRef) {
            this.componentRef.input(input);
        }
        else {
            throw new Error('Modal initiated without instance. Input could be passed programmatically only for ' +
                'service-hosted modals.');
        }
    }
}
KitModalRef.decorators = [
    { type: Injectable },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitModalOptions {
    constructor() {
        this.backdropClose = true;
        this.escClose = true;
        this.scrollLock = true;
    }
}
KitModalOptions.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */ KitModalOptions.ngInjectableDef = defineInjectable({ factory: function KitModalOptions_Factory() { return new KitModalOptions(); }, token: KitModalOptions, providedIn: "root" });
/**
 * @record
 * @template T
 */

/**
 * @record
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitModalService {
    /**
     * @param {?} overlay
     * @param {?} em
     * @param {?} options
     * @param {?} document
     * @param {?} platform
     * @param {?} parent
     * @param {?} cfr
     */
    constructor(overlay, em, options, document, platform, parent, cfr) {
        this.overlay = overlay;
        this.em = em;
        this.options = options;
        this.document = document;
        this.platform = platform;
        this.parent = parent;
        this.cfr = cfr;
        this.displayed = new Set();
        this.isRoot = !this.parent;
    }
    /**
     * Display component as modal in the overlay.
     * @template T
     * @param {?} __0
     * @return {?}
     */
    show({ component, options, componentFactoryResolver, viewContainerRef, }) {
        if (this.isRoot) {
            this.initBackdrop();
            const /** @type {?} */ ref = new KitModalRef();
            const /** @type {?} */ componentRef = this.overlay
                .hostComponent({
                component,
                providers: [
                    {
                        provide: KitModalRef,
                        useValue: ref,
                    },
                ],
                componentFactoryResolver: componentFactoryResolver,
                viewContainerRef: viewContainerRef,
            });
            ref.options = Object.assign({}, this.options, options);
            ref.componentRef = componentRef;
            ref.viewRef = componentRef.componentRef.hostView;
            ref.onClose.subscribe(() => {
                // run closing guard if defined
                if (!ref.instance['canClose'] || ref.instance['canClose']()) {
                    componentRef.componentRef.destroy();
                    ref.onDestroy.next();
                }
            });
            this.addRef(ref);
            return ref;
        }
        else {
            return this.parent.show({
                component,
                options,
                componentFactoryResolver: componentFactoryResolver || this.cfr,
                viewContainerRef,
            });
        }
    }
    /**
     * \@internal
     * @param {?} ref
     * @return {?}
     */
    addRef(ref) {
        if (this.isRoot) {
            this.initBackdrop();
            this.displayed.add(ref);
            // update backdrop
            ref.onDestroy.subscribe(() => {
                this.displayed.delete(ref);
                this.checkBackdrop();
            });
            this.checkBackdrop();
        }
        else {
            this.parent.addRef(ref);
        }
    }
    /**
     * @return {?}
     */
    checkBackdrop() {
        this.backdropRef.input({ display: this.displayed.size > 0 });
        // move backdrop
        const /** @type {?} */ top = this.getTopModalRef();
        if (top) {
            this.overlay.moveUnder(this.backdropRef.componentRef.hostView, top.viewRef);
        }
        // handle body scroll-lock
        if (this.platform.isBrowser() && this.document) {
            if (top && top.options.scrollLock) {
                this.document.body.style.overflow = 'hidden';
            }
            else {
                this.document.body.style.removeProperty('overflow');
            }
        }
    }
    /**
     * @return {?}
     */
    backdropClickHandler() {
        const /** @type {?} */ top = this.getTopModalRef();
        if (top && top.options.backdropClose) {
            top.onClose.next();
        }
    }
    /**
     * @return {?}
     */
    escHandler() {
        const /** @type {?} */ top = this.getTopModalRef();
        if (top && top.options.escClose) {
            top.onClose.next();
        }
    }
    /**
     * @return {?}
     */
    getTopModalRef() {
        return Array.from(this.displayed.values()).pop();
    }
    /**
     * @return {?}
     */
    initBackdrop() {
        if (!this.backdropRef) {
            this.backdropRef = this.overlay.hostComponent({ component: KitModalBackdropComponent });
            // backdrop close handler
            this.backdropRef.componentRef.instance.close.subscribe(() => {
                this.backdropClickHandler();
            });
            // control esc
            this.em.listenGlobal('keydown', (event) => {
                if (event.keyCode === keyEscape) {
                    this.escHandler();
                }
            }, true);
        }
    }
}
KitModalService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
/** @nocollapse */
KitModalService.ctorParameters = () => [
    { type: KitOverlayService, },
    { type: KitEventManagerService, },
    { type: KitModalOptions, },
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] },] },
    { type: KitPlatformService, },
    { type: KitModalService, decorators: [{ type: Optional }, { type: Inject, args: [forwardRef(() => KitModalService),] }, { type: SkipSelf },] },
    { type: ComponentFactoryResolver, },
];
/** @nocollapse */ KitModalService.ngInjectableDef = defineInjectable({ factory: function KitModalService_Factory() { return new KitModalService(inject(KitOverlayService), inject(KitEventManagerService), inject(KitModalOptions), inject(DOCUMENT), inject(KitPlatformService), inject(KitModalService, 12), inject(ComponentFactoryResolver)); }, token: KitModalService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitModalComponent {
    /**
     * @param {?} ref
     * @param {?} service
     * @param {?} options
     */
    constructor(ref, service, options) {
        this.ref = ref;
        this.service = service;
        this.options = options;
        /**
         * Emits when modal should be closed.
         */
        this.close = new EventEmitter();
        this._displayed = false;
        this.ref.options = this.options;
        this.ref.onClose.subscribe(() => {
            this.close.emit();
        });
    }
    /**
     * Indicating if clicking the backdrop should close the modal.
     * @param {?} backdropClose
     * @return {?}
     */
    set backdropClose(backdropClose) {
        this.ref.applyParams({ backdropClose });
    }
    /**
     * Indicating if pressing the `esc` key should close the modal.
     * @param {?} escClose
     * @return {?}
     */
    set escClose(escClose) {
        this.ref.applyParams({ escClose });
    }
    /**
     * Indicating if scroll of body is disabled while modal is displayed.
     * @param {?} scrollLock
     * @return {?}
     */
    set scrollLock(scrollLock) {
        this.ref.applyParams({ scrollLock });
    }
    /**
     * @return {?}
     */
    ngAfterContentInit() {
        this.overlay.displayed.subscribe(displayed => {
            if (this._displayed !== displayed) {
                this._displayed = displayed;
                if (displayed && this.overlay.viewRef) {
                    this.ref.viewRef = this.overlay.viewRef;
                    this.service.addRef(this.ref);
                }
                else {
                    this.ref.onDestroy.next();
                }
            }
        });
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.ref.onDestroy.next();
    }
}
KitModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-modal',
                template: '<ng-content></ng-content>',
                providers: [
                    KitModalRef,
                ],
            },] },
];
/** @nocollapse */
KitModalComponent.ctorParameters = () => [
    { type: KitModalRef, },
    { type: KitModalService, },
    { type: KitModalOptions, },
];
KitModalComponent.propDecorators = {
    "close": [{ type: Output },],
    "overlay": [{ type: ContentChild, args: [KitOverlayDirective,] },],
    "backdropClose": [{ type: Input },],
    "escClose": [{ type: Input },],
    "scrollLock": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitModalModule {
}
KitModalModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitModalBackdropComponent,
                    KitModalComponent,
                ],
                exports: [
                    KitModalComponent,
                ],
                entryComponents: [
                    KitModalBackdropComponent,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOutsideClickService {
    /**
     * @param {?} zone
     * @param {?} em
     * @param {?} elementRef
     */
    constructor(zone, em, elementRef) {
        this.zone = zone;
        this.em = em;
        this.elementRef = elementRef;
        this.skip = [];
        this._outsideClick = new Subject();
        this.zone.runOutsideAngular(() => {
            this.unsubFn = this.em.listenGlobal('click', (event) => {
                const /** @type {?} */ path = event['path'] || this.em.getEventPath(event);
                // Check event path
                const /** @type {?} */ skip = [this.elementRef.nativeElement, ...this.skip];
                if (skip.every(e => path.indexOf(e) === -1)) {
                    this.zone.run(() => {
                        this._outsideClick.next(event);
                    });
                }
            }, true);
        });
    }
    /**
     * @return {?}
     */
    get outsideClick() {
        return this._outsideClick.asObservable();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.unsubFn) {
            this.unsubFn();
        }
    }
}
KitOutsideClickService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitOutsideClickService.ctorParameters = () => [
    { type: NgZone, },
    { type: KitEventManagerService, },
    { type: ElementRef, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Emitted when user clicks not on current element.
 *
 * Handy for popup closing.
 *
 * ```html
 * <div (kitOutsideClick)="close()">Popup content</div>
 * ```
 */
class KitOutsideClickDirective {
    /**
     * @param {?} service
     */
    constructor(service) {
        this.service = service;
        this.kitOutsideClick = new EventEmitter();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.service.outsideClick.subscribe(e => {
            this.kitOutsideClick.emit(e);
        });
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        this.service.skip = [
            ...this.anchor ? [this.anchor.nativeEl] : [],
            ...this.skip
                ? isArray(this.skip) ? this.skip.map(s => s.nativeEl || s) : [this.skip.nativeEl || this.skip]
                : [],
        ];
    }
}
KitOutsideClickDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitOutsideClick]',
                providers: [
                    KitOutsideClickService,
                ],
            },] },
];
/** @nocollapse */
KitOutsideClickDirective.ctorParameters = () => [
    { type: KitOutsideClickService, },
];
KitOutsideClickDirective.propDecorators = {
    "anchor": [{ type: Input },],
    "skip": [{ type: Input },],
    "kitOutsideClick": [{ type: Output },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOutsideClickModule {
}
KitOutsideClickModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitOutsideClickDirective,
                ],
                exports: [
                    KitOutsideClickDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOverlayToggleDirective {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
        this.trigger = 'click';
        this._state = new BehaviorSubject$1(false);
    }
    /**
     * @return {?}
     */
    get stateChanges() {
        return this._state.asObservable();
    }
    /**
     * Get state.
     * @return {?}
     */
    get state() {
        return this._state.value;
    }
    /**
     * Get reference to anchored element.
     * @return {?}
     */
    get elementRef() {
        return this._elementRef;
    }
    /**
     * Get anchored html-element.
     * @return {?}
     */
    get nativeEl() {
        return this._elementRef.nativeElement;
    }
    /**
     * @return {?}
     */
    clickHandler() {
        if (this.trigger === 'click') {
            this.toggle();
        }
    }
    /**
     * @return {?}
     */
    mouseenterHandler() {
        if (this.trigger === 'hover') {
            this.show();
        }
    }
    /**
     * @return {?}
     */
    mouseleaveHandler() {
        if (this.trigger === 'hover') {
            this.close();
        }
    }
    /**
     * Set state to true.
     * @return {?}
     */
    show() {
        this._state.next(true);
    }
    /**
     * Set state to false.
     * @return {?}
     */
    close() {
        this._state.next(false);
    }
    /**
     * Toggle state.
     * @return {?}
     */
    toggle() {
        this._state.next(!this._state.value);
    }
}
KitOverlayToggleDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitOverlayToggle]',
                exportAs: 'toggle',
            },] },
];
/** @nocollapse */
KitOverlayToggleDirective.ctorParameters = () => [
    { type: ElementRef, },
];
KitOverlayToggleDirective.propDecorators = {
    "trigger": [{ type: Input },],
    "clickHandler": [{ type: HostListener, args: ['click',] },],
    "mouseenterHandler": [{ type: HostListener, args: ['mouseenter',] },],
    "mouseleaveHandler": [{ type: HostListener, args: ['mouseleave',] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitOverlayModule {
}
KitOverlayModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitOverlayDirective,
                    KitOverlayToggleDirective,
                ],
                declarations: [
                    KitOverlayDirective,
                    KitOverlayHostWrapperComponent,
                    KitOverlayHostComponent,
                    KitOverlayToggleDirective,
                ],
                entryComponents: [
                    KitOverlayHostWrapperComponent,
                    KitOverlayHostComponent,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const positionPairs = {
    top: 'bottom',
    bottom: 'top',
    left: 'right',
    right: 'left',
};
/**
 * @record
 */

/**
 * @record
 */

/**
 * @record
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Service that works exactly like `ngStyle`, but can be provided on a component or directive.
 *
 * ```typescript
 * providers: [KitStyleService],
 * ...
 * constructor(private style: KitStyleService) {
 * }
 * ...
 * this.style.style = {
 *  background: 'red',
 *  color: '#fff',
 * };
 * ```
 */
class KitStyleService {
    /**
     * @param {?} el
     * @param {?} differs
     * @param {?} renderer
     */
    constructor(el, differs, renderer) {
        this.el = el;
        this.differs = differs;
        this.renderer = renderer;
    }
    /**
     * @param {?} v
     * @return {?}
     */
    set style(v) {
        this._style = v;
        if (!this._differ && v) {
            this._differ = this.differs.find(v).create();
        }
        const /** @type {?} */ changes = this._differ.diff(this._style);
        if (changes) {
            this.applyChanges(changes);
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    applyChanges(changes) {
        changes.forEachRemovedItem((record) => this.setStyle(record.key, null));
        changes.forEachAddedItem((record) => this.setStyle(record.key, record.currentValue));
        changes.forEachChangedItem((record) => this.setStyle(record.key, record.currentValue));
    }
    /**
     * @param {?} nameAndUnit
     * @param {?} value
     * @return {?}
     */
    setStyle(nameAndUnit, value) {
        const [name, unit] = nameAndUnit.split('.');
        value = value != null && unit ? `${value}${unit}` : value;
        this.renderer.setStyle(this.el.nativeElement, name, /** @type {?} */ (value));
    }
}
KitStyleService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitStyleService.ctorParameters = () => [
    { type: ElementRef, },
    { type: KeyValueDiffers, },
    { type: Renderer2, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitPinPositionDirective {
    /**
     * @param {?} elementRef
     * @param {?} zone
     * @param {?} style
     * @param {?} platform
     * @param {?} em
     */
    constructor(elementRef, zone, style$$1, platform, em) {
        this.elementRef = elementRef;
        this.zone = zone;
        this.style = style$$1;
        this.platform = platform;
        this.em = em;
        this.unsubs = [];
        this.style.style = {
            left: '0',
            position: 'fixed',
            top: '0',
        };
        if (this.platform.isBrowser()) {
            this.zone.onStable
                .pipe(take(1))
                .subscribe(() => {
                this.zone.runOutsideAngular(() => {
                    this.unsubs = [
                        ...this.unsubs,
                        this.em.listenGlobal('scroll', this.reposition.bind(this), true),
                        this.em.listenGlobal('resize', this.reposition.bind(this), true),
                    ];
                });
            });
        }
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        this.reposition();
    }
    /**
     * @return {?}
     */
    reposition() {
        const /** @type {?} */ field = this.getField();
        const /** @type {?} */ anchor = this.getRect(this.anchor);
        this.style.style = this.calc(this.position, field, anchor);
    }
    /**
     * @param {?} position
     * @param {?} field
     * @param {?} anchor
     * @return {?}
     */
    calc(position, field, anchor) {
        const /** @type {?} */ common = {
            display: 'flex',
            position: 'fixed',
        };
        const /** @type {?} */ vSideLeft = field.width / 2 > anchor.left + anchor.width / 2;
        const /** @type {?} */ vSideTop = field.height / 2 > anchor.top + anchor.height / 2;
        switch (this.position) {
            case 'top':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', height: this.px(anchor.top), left: this.px(anchor.left), width: this.px(anchor.width) });
            case 'top-center':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', justifyContent: 'center', height: this.px(anchor.top), left: vSideLeft ? '0' : this.px(anchor.left - (field.width - anchor.right)), width: vSideLeft ? this.px(anchor.left + anchor.right) : this.px(anchor.width + (field.width - anchor.right) * 2) });
            case 'top-right':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', justifyContent: 'flex-end', height: this.px(anchor.top), left: '0', width: this.px(anchor.right) });
            case 'top-left':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', justifyContent: 'flex-start', height: this.px(anchor.top), left: this.px(anchor.left), width: this.px(field.width - anchor.left) });
            case 'right':
                return Object.assign({}, common, { flexDirection: 'column', height: this.px(anchor.height), left: this.px(anchor.right), top: this.px(anchor.top) });
            case 'right-center':
                return Object.assign({}, common, { flexDirection: 'column', justifyContent: 'center', height: vSideTop ? this.px(anchor.top + anchor.bottom) : this.px(anchor.height + (field.height - anchor.bottom) * 2), left: this.px(anchor.right), top: vSideTop ? '0' : this.px(anchor.top - (field.height - anchor.bottom)) });
            case 'right-top':
                return Object.assign({}, common, { flexDirection: 'column', height: this.px(field.height - anchor.top), justifyContent: 'flex-start', left: this.px(anchor.right), top: this.px(anchor.top) });
            case 'right-bottom':
                return Object.assign({}, common, { flexDirection: 'column', height: this.px(anchor.bottom), justifyContent: 'flex-end', left: this.px(anchor.right), top: '0' });
            case 'bottom':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', height: this.px(field.height - anchor.bottom), left: this.px(anchor.left), top: this.px(anchor.bottom), width: this.px(anchor.width) });
            case 'bottom-center':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'center', height: this.px(field.height - anchor.bottom), left: vSideLeft ? '0' : this.px(anchor.left - (field.width - anchor.right)), top: this.px(anchor.bottom), width: vSideLeft ? this.px(anchor.left + anchor.right) : this.px(anchor.width + (field.width - anchor.right) * 2) });
            case 'bottom-right':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'flex-end', height: this.px(field.height - anchor.bottom), left: '0', width: this.px(anchor.right), top: this.px(anchor.bottom) });
            case 'bottom-left':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'flex-start', height: this.px(field.height - anchor.bottom), left: this.px(anchor.left), top: this.px(anchor.bottom), width: this.px(field.width - anchor.left) });
            case 'left':
                return Object.assign({}, common, { alignItems: 'flex-end', left: '0', flexDirection: 'column', height: this.px(anchor.height), top: this.px(anchor.top), width: this.px(anchor.left) });
            case 'left-center':
                return Object.assign({}, common, { alignItems: 'flex-end', flexDirection: 'column', justifyContent: 'center', height: vSideTop ? this.px(anchor.top + anchor.bottom) : this.px(anchor.height + (field.height - anchor.bottom) * 2), left: '0', top: vSideTop ? '0' : this.px(anchor.top - (field.height - anchor.bottom)), width: this.px(anchor.left) });
            case 'left-top':
                return Object.assign({}, common, { alignItems: 'flex-end', flexDirection: 'column', justifyContent: 'flex-start', height: this.px(field.height - anchor.top), left: '0', right: this.px(field.width - anchor.left), top: this.px(anchor.top), width: this.px(anchor.left) });
            case 'left-bottom':
                return Object.assign({}, common, { alignItems: 'flex-end', flexDirection: 'column', justifyContent: 'flex-end', height: this.px(anchor.bottom), left: '0', top: '0', width: this.px(anchor.left) });
            default:
                throw new Error(`Position ${position} in not correct!`);
        }
    }
    /**
     * @param {?} el
     * @return {?}
     */
    getRect(el) {
        return this.getEl(el).getBoundingClientRect();
    }
    /**
     * @param {?} el
     * @return {?}
     */
    getEl(el) {
        return el['nativeEl'] ? el['nativeEl'] : el;
    }
    /**
     * @return {?}
     */
    getField() {
        return {
            height: window.innerHeight,
            width: window.innerWidth,
        };
    }
    /**
     * @param {?} value
     * @return {?}
     */
    px(value) {
        return `${Math.round(value)}px`;
    }
}
KitPinPositionDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitPinPosition]',
                providers: [
                    KitStyleService,
                ],
            },] },
];
/** @nocollapse */
KitPinPositionDirective.ctorParameters = () => [
    { type: ElementRef, },
    { type: NgZone, },
    { type: KitStyleService, },
    { type: KitPlatformService, },
    { type: KitEventManagerService, },
];
KitPinPositionDirective.propDecorators = {
    "kitPinPosition": [{ type: Input },],
    "anchor": [{ type: Input },],
    "position": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitPositionModule {
}
KitPositionModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitPinPositionDirective,
                ],
                exports: [
                    KitPinPositionDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Structural directive for template projecting.
 */
class KitRefDirective {
    /**
     * @param {?} _template
     */
    constructor(_template) {
        this._template = _template;
    }
    /**
     * @return {?}
     */
    get template() {
        return this._template;
    }
}
KitRefDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitRef]',
                exportAs: 'ref',
            },] },
];
/** @nocollapse */
KitRefDirective.ctorParameters = () => [
    { type: TemplateRef, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitRefModule {
}
KitRefModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitRefDirective,
                ],
                exports: [
                    KitRefDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Structural directive for template repeating.
 *
 * Usage:
 *
 * ```html
 * <ng-container *kitRepeat="number; let index = index"></ng-container>
 * ```
 */
class KitRepeatDirective {
    /**
     * @param {?} vcr
     * @param {?} template
     */
    constructor(vcr, template) {
        this.vcr = vcr;
        this.template = template;
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        if (this.kitRepeat) {
            this.vcr.clear();
            for (let /** @type {?} */ index = 0; index < this.kitRepeat; index++) {
                this.vcr.createEmbeddedView(this.template, { index });
            }
        }
    }
}
KitRepeatDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitRepeat]',
            },] },
];
/** @nocollapse */
KitRepeatDirective.ctorParameters = () => [
    { type: ViewContainerRef, },
    { type: TemplateRef, },
];
KitRepeatDirective.propDecorators = {
    "kitRepeat": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitRepeatModule {
}
KitRepeatModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitRepeatDirective,
                ],
                exports: [
                    KitRepeatDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Scroll area helpers.
 * Should be provided on component.
 */
class KitScrollService {
    /**
     * @param {?} platform
     * @param {?} elRef
     * @param {?} hammerProvider
     */
    constructor(platform, elRef, hammerProvider) {
        this.platform = platform;
        this.elRef = elRef;
        this.hammerProvider = hammerProvider;
        this._state = new BehaviorSubject({
            nativeScrollbarWidth: 0,
            dragging: false,
            vBar: {
                active: false,
                size: 0,
                position: 0,
            },
            hBar: {
                active: false,
                size: 0,
                position: 0,
            },
        });
        if (!this.hammerProvider.hammer) {
            throw new Error('KitScrollService requires Hammer.JS');
        }
        this._state.next(Object.assign({}, this.state, { nativeScrollbarWidth: this.platform.getScrollbarWidth() }));
    }
    /**
     * @return {?}
     */
    get state() {
        return this._state.value;
    }
    /**
     * @return {?}
     */
    get stateChanges() {
        return this._state.asObservable();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.mutationObserver.disconnect();
    }
    /**
     * @param {?} refs
     * @return {?}
     */
    registerRefs(refs) {
        this.refs = refs;
        this.initVListeners();
        this.initHListeners();
        this.initMutationObserver();
    }
    /**
     * @return {?}
     */
    update() {
        this.updateVBar();
        this.updateHBar();
    }
    /**
     * @return {?}
     */
    updateVBar() {
        const /** @type {?} */ state = this.calcBar(this.refs.vWrapper.scrollHeight - this.state.nativeScrollbarWidth, this.elRef.nativeElement.offsetHeight, this.refs.vBarWrapper.offsetHeight, this.refs.vWrapper.scrollTop);
        this._state.next(Object.assign({}, this.state, { vBar: state }));
    }
    /**
     * @return {?}
     */
    updateHBar() {
        const /** @type {?} */ state = this.calcBar(this.refs.hWrapper.scrollWidth, this.elRef.nativeElement.offsetWidth, this.refs.hBarWrapper.offsetWidth, this.refs.hWrapper.scrollLeft);
        this._state.next(Object.assign({}, this.state, { hBar: state }));
    }
    /**
     * @param {?} contentSize
     * @param {?} hostSize
     * @param {?} barWrapperSize
     * @param {?} scrollPosition
     * @return {?}
     */
    calcBar(contentSize, hostSize, barWrapperSize, scrollPosition) {
        if (contentSize > hostSize) {
            const /** @type {?} */ size = Math.round(Math.max((hostSize / contentSize) * barWrapperSize, 30));
            return {
                active: true,
                size,
                position: Math.round((barWrapperSize - size) * (scrollPosition / (contentSize - hostSize))),
            };
        }
        else {
            return {
                active: false,
                size: 0,
                position: 0,
            };
        }
    }
    /**
     * @return {?}
     */
    initVListeners() {
        const /** @type {?} */ vBarHammerConfig = new HammerGestureConfig();
        vBarHammerConfig.overrides = {
            pan: {
                direction: KitHammerTypes.DIRECTION_VERTICAL,
                threshold: 1,
            },
        };
        const /** @type {?} */ vBarHammer = vBarHammerConfig.buildHammer(this.refs.vBar);
        let /** @type {?} */ scrollStart = null;
        // Pan
        vBarHammer.on('pan', (event) => {
            // Start
            if (scrollStart === null) {
                scrollStart = this.refs.vWrapper.scrollTop;
                this._state.next(Object.assign({}, this.state, { dragging: true }));
            }
            // Calc
            const /** @type {?} */ contentHeight = this.refs.hWrapper.scrollHeight;
            const /** @type {?} */ hostHeight = this.elRef.nativeElement.offsetHeight;
            const /** @type {?} */ coef = contentHeight / hostHeight;
            if (scrollStart !== null) {
                this.refs.vWrapper.scrollTop = Math.round(scrollStart + event.deltaY * coef);
            }
            // Final
            if (event.isFinal) {
                scrollStart = null;
                this._state.next(Object.assign({}, this.state, { dragging: false }));
            }
        });
        // Tap
        const /** @type {?} */ vBarWrapperHammer = vBarHammerConfig.buildHammer(this.refs.vBarWrapper);
        vBarWrapperHammer.on('tap', (event) => {
            if (event.target === this.refs.vBarWrapper) {
                const /** @type {?} */ pos = this.hammerProvider.calcRelatedPosition(this.refs.vBarWrapper, event.center);
                // Calc
                this.refs.vWrapper.scrollTop += pos.y > this.state.vBar.position ? 200 : -200;
            }
        });
    }
    /**
     * @return {?}
     */
    initHListeners() {
        const /** @type {?} */ hBarHammerConfig = new HammerGestureConfig();
        hBarHammerConfig.overrides = {
            pan: {
                direction: KitHammerTypes.DIRECTION_HORIZONTAL,
                threshold: 1,
            },
        };
        const /** @type {?} */ hBarHammer = hBarHammerConfig.buildHammer(this.refs.hBar);
        let /** @type {?} */ scrollStart = null;
        // Pan
        hBarHammer.on('pan', (event) => {
            // Start
            if (scrollStart === null) {
                scrollStart = this.refs.hWrapper.scrollLeft;
                this._state.next(Object.assign({}, this.state, { dragging: true }));
            }
            // Calc
            const /** @type {?} */ contentWidth = this.refs.hWrapper.scrollWidth;
            const /** @type {?} */ hostWidth = this.elRef.nativeElement.offsetWidth;
            const /** @type {?} */ coef = contentWidth / hostWidth;
            if (scrollStart !== null) {
                this.refs.hWrapper.scrollLeft = Math.round(scrollStart + event.deltaX * coef);
            }
            // Final
            if (event.isFinal) {
                scrollStart = null;
                this._state.next(Object.assign({}, this.state, { dragging: false }));
            }
        });
        // Tap
        const /** @type {?} */ hBarWrapperHammer = hBarHammerConfig.buildHammer(this.refs.hBarWrapper);
        hBarWrapperHammer.on('tap', (event) => {
            if (event.target === this.refs.hBarWrapper) {
                const /** @type {?} */ pos = this.hammerProvider.calcRelatedPosition(this.refs.hBarWrapper, event.center);
                // Calc
                this.refs.hWrapper.scrollLeft += pos.x > this.state.hBar.position ? 200 : -200;
            }
        });
    }
    /**
     * @return {?}
     */
    initMutationObserver() {
        this.mutationObserver = new MutationObserver(mutations => {
            if (mutations.length > 0) {
                this.update();
            }
        });
        this.mutationObserver.observe(this.refs.hWrapper, {
            attributes: true,
            childList: true,
            characterData: true,
            subtree: true,
        });
    }
}
KitScrollService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitScrollService.ctorParameters = () => [
    { type: KitPlatformService, },
    { type: ElementRef, },
    { type: KitHammerProvider, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitSlideHostService {
    /**
     * @param {?} zone
     */
    constructor(zone) {
        this.zone = zone;
        /**
         * Activate first slide on init.
         */
        this.activateFirst = true;
        this._active = new BehaviorSubject(null);
        this._direction = new BehaviorSubject('next');
        this.firstRegistration = false;
        this.ids = new Set();
        this.lastId = 0;
    }
    /**
     * Get active slide id.
     * @return {?}
     */
    get active() {
        return this._active.value;
    }
    /**
     * Set active side by id.
     * @param {?} id
     * @return {?}
     */
    set active(id) {
        this._direction.next(this._active.value === null
            ? 'initial'
            : id !== null && this.getIndex(id) > this.getIndex(this._active.value)
                ? 'next'
                : 'prev');
        // run after stabilization for correct animation trigger setup
        this.zone.onStable.pipe(take(1)).subscribe(() => {
            this._active.next(id);
        });
    }
    /**
     * Set active and emit only 'initial' direction.
     * @param {?} id
     * @return {?}
     */
    set activeInitial(id) {
        this._direction.next('initial');
        // run after stabilization for correct animation trigger setup
        this.zone.onStable.pipe(take(1)).subscribe(() => {
            this._active.next(id);
        });
    }
    /**
     * Get `Observable` with active slide id.
     * @return {?}
     */
    get activeChanges() {
        return this._active.asObservable();
    }
    /**
     * Get `Observable` with direction of slide changing (next, prev).
     * @return {?}
     */
    get directionChanges() {
        return this._direction.asObservable();
    }
    /**
     * Register slide.
     * @param {?} id
     * @return {?}
     */
    addId(id) {
        if (!this.firstRegistration) {
            this.firstRegistration = true;
            if (this.activateFirst) {
                this.active = id;
            }
        }
        this.ids.add(id);
    }
    /**
     * Delete slide.
     * @param {?} id
     * @return {?}
     */
    deleteId(id) {
        this.ids.delete(id);
    }
    /**
     * Generate slide id.
     * @return {?}
     */
    genId() {
        this.lastId++;
        return this.lastId;
    }
    /**
     * Activate next slide.
     * @param {?=} cycle
     * @return {?}
     */
    next(cycle = false) {
        const /** @type {?} */ ids = Array.from(this.ids);
        const /** @type {?} */ currentIndex = this.getCurrentIndex();
        if (currentIndex < ids.length - 1) {
            this.active = ids[currentIndex + 1];
        }
        else if (cycle) {
            this.active = ids[0];
        }
    }
    /**
     * Activate prev slide.
     * @param {?=} cycle
     * @return {?}
     */
    prev(cycle = false) {
        const /** @type {?} */ ids = Array.from(this.ids);
        const /** @type {?} */ currentIndex = this.getCurrentIndex();
        if (currentIndex > 0) {
            this.active = ids[currentIndex - 1];
        }
        else if (cycle) {
            this.active = ids[ids.length - 1];
        }
    }
    /**
     * @return {?}
     */
    getCurrentIndex() {
        return this.getIndex(this._active.value);
    }
    /**
     * @param {?} value
     * @return {?}
     */
    getIndex(value) {
        const /** @type {?} */ ids = Array.from(this.ids);
        return ids.findIndex(i => i === value);
    }
}
KitSlideHostService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
KitSlideHostService.ctorParameters = () => [
    { type: NgZone, },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Structure directive that display slides.
 */
class KitSlideDirective {
    /**
     * @param {?} vcr
     * @param {?} template
     * @param {?} host
     * @param {?} cdr
     * @param {?} zone
     */
    constructor(vcr, template, host, cdr, zone) {
        this.vcr = vcr;
        this.template = template;
        this.host = host;
        this.cdr = cdr;
        this.zone = zone;
        /**
         * Slide id.
         *
         * If not set will be generated automatically.
         */
        this.kitSlide = null;
        this.destroy = new Subject();
        this.displayed = false;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['kitSlide'] && changes['kitSlide'].currentValue !== null) {
            this.host.deleteId(changes['kitSlide'].previousValue);
            this.host.addId(changes['kitSlide'].currentValue);
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.host.deleteId(this.kitSlide);
        this.destroy.next();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // gen slideId if not set
        if (this.kitSlide === null) {
            this.kitSlide = this.host.genId();
            this.host.addId(this.kitSlide);
        }
        // handle displaying
        this.host.activeChanges
            .pipe(takeUntil(this.destroy))
            .subscribe((id) => {
            if (id === this.kitSlide) {
                if (!this.displayed) {
                    this.zone.run(() => {
                        this.vcr.createEmbeddedView(this.template);
                        this.displayed = true;
                        this.cdr.detectChanges();
                    });
                }
            }
            else {
                if (this.displayed) {
                    this.zone.run(() => {
                        this.vcr.clear();
                        this.displayed = false;
                        this.cdr.detectChanges();
                    });
                }
            }
        });
    }
}
KitSlideDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitSlide]',
            },] },
];
/** @nocollapse */
KitSlideDirective.ctorParameters = () => [
    { type: ViewContainerRef, },
    { type: TemplateRef, },
    { type: KitSlideHostService, },
    { type: ChangeDetectorRef, },
    { type: NgZone, },
];
KitSlideDirective.propDecorators = {
    "kitSlide": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitSlideModule {
}
KitSlideModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitSlideDirective,
                ],
                declarations: [
                    KitSlideDirective,
                ],
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class KitStyleModule {
}
KitStyleModule.decorators = [
    { type: NgModule, args: [{},] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} value
 * @return {?}
 */
function isMergeableObject(value) {
    return isNonNullObject(value) && isNotSpecial(value);
}
/**
 * @param {?} value
 * @return {?}
 */
function isNonNullObject(value) {
    return !!value && typeof value === 'object';
}
/**
 * @param {?} value
 * @return {?}
 */
function isNotSpecial(value) {
    const /** @type {?} */ stringValue = Object.prototype.toString.call(value);
    return stringValue !== '[object RegExp]'
        && stringValue !== '[object Date]';
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} x
 * @return {?}
 */
function isObject(x) {
    return x != null && typeof x === 'object';
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} val
 * @return {?}
 */
function emptyTarget(val) {
    return Array.isArray(val) ? [] : {};
}
/**
 * @param {?} value
 * @param {?=} optionsArgument
 * @return {?}
 */
function cloneIfNecessary(value, optionsArgument) {
    const /** @type {?} */ clone = optionsArgument && optionsArgument.clone === true;
    return (clone && isMergeableObject(value)) ? mergeDeep(emptyTarget(value), value, optionsArgument) : value;
}
/**
 * @param {?} target
 * @param {?} source
 * @param {?} optionsArgument
 * @return {?}
 */
function defaultArrayMerge(target, source, optionsArgument) {
    const /** @type {?} */ destination = target.slice();
    source.forEach(function (e, i) {
        if (typeof destination[i] === 'undefined') {
            destination[i] = cloneIfNecessary(e, optionsArgument);
        }
        else if (isMergeableObject(e)) {
            destination[i] = mergeDeep(target[i], e, optionsArgument);
        }
        else if (target.indexOf(e) === -1) {
            destination.push(cloneIfNecessary(e, optionsArgument));
        }
    });
    return destination;
}
/**
 * @param {?} target
 * @param {?} source
 * @param {?=} optionsArgument
 * @return {?}
 */
function mergeObject(target, source, optionsArgument) {
    const /** @type {?} */ destination = {};
    if (isMergeableObject(target)) {
        Object.keys(target).forEach(function (key) {
            destination[key] = cloneIfNecessary(target[key], optionsArgument);
        });
    }
    Object.keys(source).forEach(function (key) {
        if (!isMergeableObject(source[key]) || !target[key]) {
            destination[key] = cloneIfNecessary(source[key], optionsArgument);
        }
        else {
            destination[key] = mergeDeep(target[key], source[key], optionsArgument);
        }
    });
    return destination;
}
/**
 * @param {?} target
 * @param {?} source
 * @param {?=} optionsArgument
 * @return {?}
 */
function mergeDeep(target, source, optionsArgument) {
    const /** @type {?} */ sourceIsArray = Array.isArray(source);
    const /** @type {?} */ targetIsArray = Array.isArray(target);
    const /** @type {?} */ options = optionsArgument || { arrayMerge: defaultArrayMerge };
    const /** @type {?} */ sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
    if (!sourceAndTargetTypesMatch) {
        return cloneIfNecessary(source, optionsArgument);
    }
    else if (sourceIsArray) {
        const /** @type {?} */ arrayMerge = options.arrayMerge || defaultArrayMerge;
        return arrayMerge(target, source, optionsArgument);
    }
    else {
        return mergeObject(target, source, optionsArgument);
    }
}
/**
 * @param {?} array
 * @param {?=} optionsArgument
 * @return {?}
 */
function mergeDeepAll(array, optionsArgument) {
    if (!Array.isArray(array) || array.length < 2) {
        throw new Error('first argument should be an array with at least two elements');
    }
    // we are sure there are at least 2 values, so it is safe to have no initial value
    return array.reduce(function (prev, next) {
        return mergeDeep(prev, next, optionsArgument);
    });
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { KitAnchorDirective, KitAnchorModule, KIT_CHECK_VALUE_ACCESSOR, KitCheckDirective, KitCheckModule, KitClassDirective, KitClassModule, KitClassService, KitCollapseDirective, KitCollapseModule, KitCollapseHostService, KitCollapseItemService, KitDatePickerService, KitDatePickerModule, KitEventManagerService, keyArrowUp, keyArrowDown, keyArrowRight, keyArrowLeft, keyPageUp, keyPageDown, keyHome, keyEnd, keyEnter, keySpace, keyTab, keyEscape, keyBackspace, keyDelete, keyShift, keyCtrl, keyAlt, KitFocusListenerService, KitFocusManagerModule, KitFocusManagerService, KitFocusManagerRegistryService, KitFocusDirective, KitFocusTrapDirective, KitFormFieldModule, KitFormFieldService, KitFormErrorDirective, KitNgControlDirective, KitFormTouchModule, KitFormTouchDirective, KitHammerProvider, KitHammerTypes, KitIconComponent, KitIconsModule, KitIconsRegistryService, KitInputDateDirective, KitInputDateModule, KitIntersectionModule, KitIntersectionService, KitIntersectionDirective, KitLoadingService, KitLoadingProgress, kitLoadingGlobal, KitLoadingState, KitMqModule, KitMqService, kitMqBreakpoints, KitMqDirective, KitModalModule, KitModalService, KitModalRef, KitModalOptions, KitModalComponent, KitMomentProvider, KitOutsideClickDirective, KitOutsideClickModule, KitOutsideClickService, KitOverlayModule, KitOverlayDirective, KitOverlayService, KitOverlayComponentRef, KitOverlayToggleDirective, positionPairs, KitPlatformService, KitPositionModule, KitPinPositionDirective, KitRefDirective, KitRefModule, KitRepeatDirective, KitRepeatModule, KitScrollService, KitSlideDirective, KitSlideModule, KitSlideHostService, KitStyleService, KitStyleModule, KitValueAccessorDirective, KitValueAccessorModule, KitModelInterceptor, isArray, isDefined, isMergeableObject, isNonNullObject, isNotSpecial, isObject, isString, isUndefined, mergeDeep, mergeDeepAll, uuid, KitModalBackdropComponent as ɵb, KitOverlayHostWrapperComponent as ɵc, KitOverlayHostComponent as ɵd, KitDefaultModelInterceptor as ɵa };
//# sourceMappingURL=ngx-kit-core.js.map
