const path = require('path');
const fs = require('fs-extra');

const mainPkg = require(path.resolve(__dirname,'../../package.json'));
const pkg = require(path.resolve(__dirname,'./package.json'));

pkg.version = mainPkg.version;
fs.writeFileSync(path.resolve(__dirname,'./package.json'), JSON.stringify(pkg, null, 2));

console.log('pre-build.js finished!');
