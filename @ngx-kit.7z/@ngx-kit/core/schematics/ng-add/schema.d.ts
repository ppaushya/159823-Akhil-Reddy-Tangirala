export interface Schema {
    skipPackageJson: boolean;
    project?: string;
}
