export * from './<%= dasherize(name) %>.module';
export * from './<%= dasherize(name) %>/<%= dasherize(name) %>.component';
