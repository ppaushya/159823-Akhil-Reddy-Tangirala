import { OnDestroy, Renderer2 } from '@angular/core';
import { Observable } from 'rxjs';
import { KitDatePickerGrid } from './meta';
/**
 * Service encapsulates complex date-picker grid logic.
 */
export declare class KitDatePickerService implements OnDestroy {
    private renderer;
    private _active;
    private _focus;
    private moveHandlerUnsubs;
    private readonly _grid;
    private readonly _monthCursor;
    private readonly _pick;
    constructor(renderer: Renderer2);
    /**
     * Set active date.
     */
    active: Date;
    /**
     * Observable with grid state.
     */
    readonly gridChanges: Observable<KitDatePickerGrid>;
    /**
     * Observable with month cursor state.
     */
    readonly monthCursorChanges: Observable<Date | null>;
    /**
     * Observable with pick date events.
     */
    readonly pick: Observable<Date>;
    /**
     * Weekdays array.
     */
    readonly weekdays: Date[];
    ngOnDestroy(): void;
    /**
     * Focus date (open correspondent month).
     */
    focus(date: Date): void;
    /**
     * Modify opened month.
     */
    modMonth(modifier: number): void;
    /**
     * Modify opened year.
     */
    modYear(modifier: number): void;
    /**
     * Handle keyboard movement.
     */
    handleMove(target: any): void;
    /**
     * Compare two dates.
     */
    private isDatesEqual(x, y);
    /**
     * Start of month of passed date.
     */
    private startOfMonth(curr);
    /**
     * Start of week of passed date.
     */
    private startOfWeek(curr);
    /**
     * Redraw grid based on monthCursor and current date.
     */
    private updateGrid();
    /**
     * Calc number of weeks in month.
     */
    private weeksInMonth(curr);
}
