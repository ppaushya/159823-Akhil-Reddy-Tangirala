export declare class KitDatePickerModule {
}
