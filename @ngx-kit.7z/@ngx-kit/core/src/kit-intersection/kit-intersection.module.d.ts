export declare class KitIntersectionModule {
}
