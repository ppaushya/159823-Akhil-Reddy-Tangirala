import { ElementRef, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { KitPlatformService } from '../kit-platform/kit-platform.service';
/**
 * Should be provided on a component or a directive.
 */
export declare class KitIntersectionService implements OnDestroy {
    private elementRef;
    private platform;
    private observer;
    private io;
    constructor(elementRef: ElementRef, platform: KitPlatformService);
    readonly isIntersecting: boolean;
    ngOnDestroy(): void;
    observe(): Observable<boolean | null>;
    private initObserver();
}
