import { EventEmitter, OnInit } from '@angular/core';
import { KitIntersectionService } from '../kit-intersection.service';
export declare class KitIntersectionDirective implements OnInit {
    private intersection;
    kitIntersection: EventEmitter<boolean>;
    constructor(intersection: KitIntersectionService);
    ngOnInit(): void;
}
