import { Observable } from 'rxjs';
import { KitLoadingEndFn, KitLoadingState } from './meta';
export declare class KitLoadingProgress {
    readonly id: string;
    private current;
    private _state;
    private _stateChanges;
    constructor(id: string);
    readonly state: KitLoadingState;
    readonly stateChanges: Observable<KitLoadingState>;
    start(key?: string): KitLoadingEndFn;
    end(key?: string): void;
    private checkState();
    private setState(state);
}
