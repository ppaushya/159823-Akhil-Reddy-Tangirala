export declare const kitLoadingGlobal = "global";
export declare type KitLoadingEndFn = () => void;
export declare enum KitLoadingState {
    InProgress = "in-progress",
    None = "none",
}
