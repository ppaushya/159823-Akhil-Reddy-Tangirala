import { Router } from '@angular/router';
import { KitLoadingProgress } from './kit-loading-progress';
export declare class KitLoadingService {
    private router;
    private progresses;
    constructor(router: Router);
    readonly global: KitLoadingProgress;
    progress(id: string): KitLoadingProgress;
}
