import { ElementRef, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { KitHammerProvider } from '../kit-hammer/kit-hammer-provider';
import { KitPlatformService } from '../kit-platform/kit-platform.service';
import { KitScrollRefs, KitScrollState } from './meta';
/**
 * Scroll area helpers.
 * Should be provided on component.
 */
export declare class KitScrollService implements OnDestroy {
    private platform;
    private elRef;
    private hammerProvider;
    refs: KitScrollRefs;
    private _state;
    private mutationObserver;
    constructor(platform: KitPlatformService, elRef: ElementRef, hammerProvider: KitHammerProvider<any>);
    readonly state: KitScrollState;
    readonly stateChanges: Observable<KitScrollState>;
    ngOnDestroy(): void;
    registerRefs(refs: KitScrollRefs): void;
    update(): void;
    updateVBar(): void;
    updateHBar(): void;
    private calcBar(contentSize, hostSize, barWrapperSize, scrollPosition);
    private initVListeners();
    private initHListeners();
    private initMutationObserver();
}
