export declare class KitFormTouchModule {
}
