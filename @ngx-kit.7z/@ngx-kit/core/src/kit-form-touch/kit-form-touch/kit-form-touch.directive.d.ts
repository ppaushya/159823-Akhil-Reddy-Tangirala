import { ControlContainer, FormGroup } from '@angular/forms';
export declare class KitFormTouchDirective {
    private container;
    constructor(container: ControlContainer);
    clickHandler(): void;
    /**
     * Touches all FormGroup controls and controls in nested FormGroups at any level.
     */
    formTouchAll(form: FormGroup, revalidate?: boolean): void;
}
