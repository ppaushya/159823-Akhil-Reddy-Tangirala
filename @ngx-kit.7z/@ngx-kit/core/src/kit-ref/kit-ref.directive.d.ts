import { TemplateRef } from '@angular/core';
/**
 * Structural directive for template projecting.
 */
export declare class KitRefDirective {
    private _template;
    constructor(_template: TemplateRef<any>);
    readonly template: TemplateRef<any>;
}
