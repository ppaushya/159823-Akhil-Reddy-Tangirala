export declare class KitRefModule {
}
