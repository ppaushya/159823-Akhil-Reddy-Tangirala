export declare class KitStyleModule {
}
