import { ElementRef, KeyValueDiffers, Renderer2 } from '@angular/core';
import { KitStyles } from './meta';
/**
 * Service that works exactly like `ngStyle`, but can be provided on a component or directive.
 *
 * ```typescript
 * providers: [KitStyleService],
 * ...
 * constructor(private style: KitStyleService) {
 * }
 * ...
 * this.style.style = {
 *  background: 'red',
 *  color: '#fff',
 * };
 * ```
 */
export declare class KitStyleService {
    private el;
    private differs;
    private renderer;
    private _differ;
    private _style;
    constructor(el: ElementRef, differs: KeyValueDiffers, renderer: Renderer2);
    style: KitStyles;
    private applyChanges(changes);
    private setStyle(nameAndUnit, value);
}
