export interface KitStyles {
    [key: string]: string;
}
