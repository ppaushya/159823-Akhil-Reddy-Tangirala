import { KitPlatformService } from '../kit-platform/kit-platform.service';
export declare class KitEventManagerService {
    private platform;
    constructor(platform: KitPlatformService);
    /**
     * Listen event on the global root object.
     *
     * Reason: native Angular EventManager does not provide event listener with useCapture param.
     */
    listenGlobal(eventName: string, handler: Function, useCapture?: boolean): Function;
    /**
     * Get array of objects visited by event.
     */
    getEventPath(event: Event): EventTarget[];
}
