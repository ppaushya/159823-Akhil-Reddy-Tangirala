import { OnChanges, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { KitClassService } from '../kit-class/kit-class.service';
export declare const KIT_CHECK_VALUE_ACCESSOR: any;
/**
 * Adds to any element ValueAccessor and checkbox/radio behavior.
 *
 * When is checked - adds class "checked" to the element.
 *
 * For a value changing the directive listen click event.
 */
export declare class KitCheckDirective implements OnChanges, ControlValueAccessor {
    private kitClass;
    /**
     * Class applied when active.
     */
    checkedClass: string;
    kitCheck: void;
    /**
     * Value that passed to VALUE_ACCESSOR.
     *
     * Enables radio-behavior.
     */
    value: any;
    private changes;
    private checked;
    private disabled;
    private touches;
    constructor(kitClass: KitClassService);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Listen to mouse clicks on element.
     */
    clickListener(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    private applyClass();
}
