export declare class KitCheckModule {
}
