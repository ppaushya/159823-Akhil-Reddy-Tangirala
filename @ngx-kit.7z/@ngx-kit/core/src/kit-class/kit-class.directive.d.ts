import { OnChanges, SimpleChanges } from '@angular/core';
import { KitClassService } from './kit-class.service';
import { KitClassSetter } from './meta';
/**
 * Provides `KitClassService` and pass input value to `KitClassService.apply` method.
 *
 * ```html
 * <div [kitClass]="{color: 'red', active: true, primary: false}">
 * <!--<div class="color-red active">-->
 * ```
 */
export declare class KitClassDirective implements OnChanges {
    private service;
    kitClass: KitClassSetter;
    constructor(service: KitClassService);
    ngOnChanges(changes: SimpleChanges): void;
}
