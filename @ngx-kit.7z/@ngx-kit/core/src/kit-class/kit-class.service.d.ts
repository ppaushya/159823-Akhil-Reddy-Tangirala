import { ElementRef, IterableDiffers, Renderer2 } from '@angular/core';
import { KitClassSetter } from './meta';
/**
 * Apply classes to an element.
 *
 * Must be provided on a component or directive.
 *
 * ```typescript
 * constructor(private kitClass: KitClassService) {}
 * ...
 * this.kitClass.apply({color: 'red', active: true, primary: false});
 * ```
 *
 * Adds to element: `class="color-red active"`
 */
export declare class KitClassService {
    private renderer;
    private el;
    private differs;
    private _state;
    private _differ;
    constructor(renderer: Renderer2, el: ElementRef, differs: IterableDiffers);
    /**
     * Override class declaration state.
     */
    state: KitClassSetter;
    /**
     * Merge to class declaration state.
     */
    apply(setter: KitClassSetter): void;
    private process(newState);
    private applyChanges(changes);
    private processObj(obj);
}
