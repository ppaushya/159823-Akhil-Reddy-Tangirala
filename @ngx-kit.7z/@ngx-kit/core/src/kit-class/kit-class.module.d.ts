export declare class KitClassModule {
}
