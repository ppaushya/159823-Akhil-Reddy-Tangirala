export interface KitClassSetter {
    [key: string]: KitClassValue;
}
export declare type KitClassValue = string | number | boolean | null;
