import { EventManager } from '@angular/platform-browser';
import { Observable } from 'rxjs';
/**
 * Handles leaving focus from a group of elements.
 */
export declare class KitFocusListenerService {
    private em;
    private _focused;
    private _focus;
    private _blur;
    private elements;
    constructor(em: EventManager);
    /**
     * Emits, if user focuses one of registered element.
     */
    readonly focus: Observable<any>;
    /**
     * Emits, if focus leave one of registered element and target node is not one of registered element (or it's child).
     */
    readonly blur: Observable<any>;
    /**
     * Is one of registered element focused now.
     */
    readonly focused: boolean;
    add(el: HTMLElement): void;
    remove(el: HTMLElement): void;
    private checkLeave(event?);
}
