export declare class KitSlideModule {
}
