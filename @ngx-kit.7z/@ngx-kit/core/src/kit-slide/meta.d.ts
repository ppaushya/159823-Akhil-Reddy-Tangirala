export declare type KitSlideDirection = 'initial' | 'prev' | 'next';
export declare type KitSlideId = string | number | null;
