import { NgZone } from '@angular/core';
import { Observable } from 'rxjs';
import { KitSlideDirection, KitSlideId } from './meta';
export declare class KitSlideHostService {
    private zone;
    /**
     * Activate first slide on init.
     */
    activateFirst: boolean;
    private _active;
    private _direction;
    private firstRegistration;
    private ids;
    private lastId;
    constructor(zone: NgZone);
    /**
     * Get active slide id.
     */
    /**
     * Set active side by id.
     */
    active: KitSlideId;
    /**
     * Set active and emit only 'initial' direction.
     */
    activeInitial: KitSlideId;
    /**
     * Get `Observable` with active slide id.
     */
    readonly activeChanges: Observable<KitSlideId>;
    /**
     * Get `Observable` with direction of slide changing (next, prev).
     */
    readonly directionChanges: Observable<KitSlideDirection>;
    /**
     * Register slide.
     */
    addId(id: KitSlideId): void;
    /**
     * Delete slide.
     */
    deleteId(id: KitSlideId): void;
    /**
     * Generate slide id.
     */
    genId(): number;
    /**
     * Activate next slide.
     */
    next(cycle?: boolean): void;
    /**
     * Activate prev slide.
     */
    prev(cycle?: boolean): void;
    private getCurrentIndex();
    private getIndex(value);
}
