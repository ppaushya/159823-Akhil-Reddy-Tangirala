import { ChangeDetectorRef, NgZone, OnChanges, OnDestroy, OnInit, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import { KitSlideHostService } from '../kit-slide-host.service';
import { KitSlideId } from '../meta';
/**
 * Structure directive that display slides.
 */
export declare class KitSlideDirective implements OnInit, OnDestroy, OnChanges {
    private vcr;
    private template;
    private host;
    private cdr;
    private zone;
    /**
     * Slide id.
     *
     * If not set will be generated automatically.
     */
    kitSlide: KitSlideId;
    private destroy;
    private displayed;
    constructor(vcr: ViewContainerRef, template: TemplateRef<any>, host: KitSlideHostService, cdr: ChangeDetectorRef, zone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    ngOnInit(): void;
}
