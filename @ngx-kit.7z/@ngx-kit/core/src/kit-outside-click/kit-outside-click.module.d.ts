export declare class KitOutsideClickModule {
}
