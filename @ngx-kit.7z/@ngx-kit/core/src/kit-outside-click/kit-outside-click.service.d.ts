import { ElementRef, NgZone, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { KitEventManagerService } from '../kit-event-manager/kit-event-manager.service';
export declare class KitOutsideClickService implements OnDestroy {
    private zone;
    private em;
    private elementRef;
    skip: HTMLElement[];
    private _outsideClick;
    private unsubFn;
    constructor(zone: NgZone, em: KitEventManagerService, elementRef: ElementRef);
    readonly outsideClick: Observable<any>;
    ngOnDestroy(): void;
}
