import { EventEmitter, OnChanges, OnInit } from '@angular/core';
import { KitAnchor } from '../kit-anchor/meta';
import { KitOutsideClickService } from './kit-outside-click.service';
/**
 * Emitted when user clicks not on current element.
 *
 * Handy for popup closing.
 *
 * ```html
 * <div (kitOutsideClick)="close()">Popup content</div>
 * ```
 */
export declare class KitOutsideClickDirective implements OnInit, OnChanges {
    private service;
    anchor: KitAnchor;
    /**
     * Define elements that are not considered as outside.
     */
    skip: KitAnchor | KitAnchor[];
    kitOutsideClick: EventEmitter<any>;
    constructor(service: KitOutsideClickService);
    ngOnInit(): void;
    ngOnChanges(): void;
}
