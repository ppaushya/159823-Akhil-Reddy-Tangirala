import { InjectionToken, Type } from '@angular/core';
export declare const KitNotificationHost: InjectionToken<Type<any>>;
export declare type KitNotificationPosition = 'top-left' | 'top-right' | 'bottom-right' | 'bottom-left';
export interface KitNotificationHostConfig {
    duration: number;
    position: KitNotificationPosition;
}
export interface KitNotificationItem {
    __id: string;
    params: any;
}
