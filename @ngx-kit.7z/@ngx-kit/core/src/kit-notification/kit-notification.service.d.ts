import { Observable } from 'rxjs';
import { KitNotificationHostConfig, KitNotificationItem } from './meta';
/**
 *
 *  ## Global config
 *
 *  ```typescript
 *  constructor(private notificationService: KitNotificationService) {
 *   this.notificationService.config({
 *     duration: 4000,
 *     position: 'top-right',
 *   });
 * }
 *  ```
 *
 *  ## Open notification
 *
 *  ```typescript
 *  constructor(private notificationService: KitNotificationService) {
 *   this.notificationService.open(NotifViewComponent, {first: 1, second: 2});
 * }
 *  ```
 *
 *  @deprecated Service is redundant, moved to the collection.
 *
 *  @todo remove in next major version.
 *
 */
export declare class KitNotificationService {
    private _config;
    private _items;
    readonly configChanges: Observable<KitNotificationHostConfig>;
    readonly itemsChanges: Observable<KitNotificationItem[]>;
    close(__id: string): void;
    /**
     * Configure notification service.
     */
    config(config: Partial<KitNotificationHostConfig>): void;
    /**
     * Display notification message.
     */
    open(params: any): void;
}
