export declare namespace KitHammerTypes {
    const INPUT_TYPE_TOUCH = "touch";
    const INPUT_TYPE_PEN = "pen";
    const INPUT_TYPE_MOUSE = "mouse";
    const INPUT_TYPE_KINECT = "kinect";
    const COMPUTE_INTERVAL = 25;
    const INPUT_START = 1;
    const INPUT_MOVE = 2;
    const INPUT_END = 4;
    const INPUT_CANCEL = 8;
    const DIRECTION_NONE = 1;
    const DIRECTION_LEFT = 2;
    const DIRECTION_RIGHT = 4;
    const DIRECTION_UP = 8;
    const DIRECTION_DOWN = 16;
    const DIRECTION_HORIZONTAL: number;
    const DIRECTION_VERTICAL: number;
    const DIRECTION_ALL: number;
}
