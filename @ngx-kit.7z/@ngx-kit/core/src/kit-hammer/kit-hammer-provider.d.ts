import { KitPlatformService } from '../kit-platform/kit-platform.service';
export declare class KitHammerProvider<T> {
    private platform;
    private _hammer;
    constructor(platform: KitPlatformService);
    /**
     * Get Hammer.JS.
     * Returns null if not available.
     */
    readonly hammer: T | null;
    /**
     * Get event position relative to passed element, not the viewport.
     */
    calcRelatedPosition(el: HTMLElement, center: {
        x: number;
        y: number;
    }): {
        x: number;
        y: number;
    };
}
