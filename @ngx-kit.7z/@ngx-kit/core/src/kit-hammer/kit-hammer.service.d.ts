import { HammerInstance } from '@angular/platform-browser/src/dom/events/hammer_gestures';
export declare class KitHammerService {
    build(el: HTMLElement, overrides?: {
        [key: string]: Object;
    }): HammerInstance;
    calcRelatedPosition(el: HTMLElement, center: {
        x: number;
        y: number;
    }): {
        x: number;
        y: number;
    };
}
