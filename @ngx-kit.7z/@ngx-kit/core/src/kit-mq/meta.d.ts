import { InjectionToken } from '@angular/core';
export declare const kitMqBreakpoints: InjectionToken<{}>;
export interface KitMqParams {
    type?: 'all' | 'print' | 'screen' | 'speech';
    from?: string;
    until?: string;
    and?: string;
}
