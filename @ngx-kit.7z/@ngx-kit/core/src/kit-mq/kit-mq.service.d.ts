import { Observable } from 'rxjs';
import { KitPlatformService } from '../kit-platform/kit-platform.service';
import { KitMqParams } from './meta';
/**
 * @todo remove mq observer on destroy
 */
export declare class KitMqService {
    private platform;
    private breakpoints;
    private matchMedia;
    private mqs;
    constructor(platform: KitPlatformService, breakpoints: any);
    check(params: KitMqParams): boolean | null;
    checkRaw(mediaQuery: string): boolean | null;
    observe(params: KitMqParams): Observable<boolean | null>;
    observeRaw(mediaQuery: string): Observable<boolean | null>;
    private buildQuery(params);
    private concatQuery(query, attach);
    private getMq(query);
}
