import { ChangeDetectorRef, OnChanges, OnDestroy, SimpleChanges, TemplateRef, ViewContainerRef, ViewRef } from '@angular/core';
import { KitMqService } from '../kit-mq.service';
import { KitMqParams } from '../meta';
export declare class KitMqDirective implements OnChanges, OnDestroy {
    private templateRef;
    private cdr;
    private vcr;
    private mq;
    kitMq: KitMqParams;
    private _viewRef;
    private subscription;
    constructor(templateRef: TemplateRef<any>, cdr: ChangeDetectorRef, vcr: ViewContainerRef, mq: KitMqService);
    readonly viewRef: ViewRef | null;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    updateHost(matches: boolean): void;
    private destroyView();
}
