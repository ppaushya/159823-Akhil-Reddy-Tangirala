export declare class KitMqModule {
}
