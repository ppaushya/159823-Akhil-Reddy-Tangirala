export declare class KitPlatformService {
    private platformId;
    constructor(platformId: Object);
    isBrowser(): boolean;
    isServer(): boolean;
    /**
     * Calc native scroll width.
     */
    getScrollbarWidth(): number;
}
