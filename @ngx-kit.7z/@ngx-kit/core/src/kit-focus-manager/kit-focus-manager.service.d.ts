import { ElementRef, NgZone, OnDestroy, Renderer2 } from '@angular/core';
import { KitEventManagerService } from '../kit-event-manager/kit-event-manager.service';
import { KitFocusManagerRegistryService } from './kit-focus-manager-registry.service';
import { KitFocusDirective } from './kit-focus/kit-focus.directive';
export declare class KitFocusManagerService implements OnDestroy {
    private el;
    private zone;
    private renderer;
    private em;
    private registry;
    /**
     * Automatically capture focus after creating.
     */
    autoCapture: boolean;
    onHold: boolean;
    private current;
    private focusTrap;
    private items;
    private outsideSource;
    private unsubs;
    constructor(el: ElementRef, zone: NgZone, renderer: Renderer2, em: KitEventManagerService, registry: KitFocusManagerRegistryService);
    private readonly documentActiveElement;
    ngOnDestroy(): void;
    /**
     * Activate focus-trap.
     */
    capture(): void;
    /**
     * Focus first focusable element.
     */
    focusFirst(): void;
    /**
     * Focus item dy id.
     */
    focusItem(id: string | number): void;
    /**
     * Focus last focusable element.
     */
    focusLast(): void;
    /**
     * Focus next focusable element (from current focused).
     */
    focusNext(): void;
    /**
     * Focus prev focusable element (from currect focused).
     */
    focusPrev(): void;
    /**
     * Required method for start service.
     */
    init(): void;
    /**
     * Register item for manual focus.
     */
    add(item: KitFocusDirective): void;
    /**
     * Disable focus-trap.
     */
    release(): void;
    /**
     * Remove item.
     */
    remove(item: KitFocusDirective): void;
    private focusinHandler(event);
    private focusoutHandler(event);
    private getTabbable();
    private isDescendant(parent, child);
    private keydownHandler(event);
}
