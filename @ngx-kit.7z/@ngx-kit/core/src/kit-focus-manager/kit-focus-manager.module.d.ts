export declare class KitFocusManagerModule {
}
