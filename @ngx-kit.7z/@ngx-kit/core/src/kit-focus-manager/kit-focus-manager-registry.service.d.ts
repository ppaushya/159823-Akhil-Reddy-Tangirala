import { KitFocusManagerService } from './kit-focus-manager.service';
export declare class KitFocusManagerRegistryService {
    stack: KitFocusManagerService[];
    capture(manager: KitFocusManagerService): void;
    release(manager: KitFocusManagerService): void;
    private getTop();
}
