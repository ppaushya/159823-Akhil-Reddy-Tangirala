import { ElementRef, OnDestroy } from '@angular/core';
import { KitFocusManagerService } from '../kit-focus-manager.service';
/**
 * Directive that registered in `KitFocusManagerService` and can be focused from outside.
 */
export declare class KitFocusDirective implements OnDestroy {
    private service;
    private el;
    /**
     * Element id.
     */
    kitFocus: string | number;
    constructor(service: KitFocusManagerService, el: ElementRef);
    ngOnDestroy(): void;
    focus(): void;
}
