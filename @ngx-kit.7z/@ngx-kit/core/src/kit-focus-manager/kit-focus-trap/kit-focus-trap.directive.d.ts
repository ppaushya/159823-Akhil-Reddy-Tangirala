import { OnInit } from '@angular/core';
import { KitFocusManagerService } from '../kit-focus-manager.service';
export declare class KitFocusTrapDirective implements OnInit {
    private service;
    constructor(service: KitFocusManagerService);
    ngOnInit(): void;
}
