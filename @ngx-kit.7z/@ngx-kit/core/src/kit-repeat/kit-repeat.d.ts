export * from './kit-repeat.directive';
export * from './kit-repeat.module';
