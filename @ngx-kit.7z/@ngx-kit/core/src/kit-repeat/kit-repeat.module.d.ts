export declare class KitRepeatModule {
}
