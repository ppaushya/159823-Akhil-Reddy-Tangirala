import { OnChanges, TemplateRef, ViewContainerRef } from '@angular/core';
/**
 * Structural directive for template repeating.
 *
 * Usage:
 *
 * ```html
 * <ng-container *kitRepeat="number; let index = index"></ng-container>
 * ```
 */
export declare class KitRepeatDirective implements OnChanges {
    private vcr;
    private template;
    /**
     * Number of repeats.
     */
    kitRepeat: number;
    private componentRef;
    constructor(vcr: ViewContainerRef, template: TemplateRef<any>);
    ngOnChanges(): void;
}
