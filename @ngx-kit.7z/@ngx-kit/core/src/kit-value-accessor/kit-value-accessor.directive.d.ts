import { ElementRef, Renderer2 } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { KitDefaultModelInterceptor } from './kit-default-model-interceptor';
import { KitModelInterceptor } from './kit-model-interceptor';
/**
 * Service directive, injects middleware.
 */
export declare class KitValueAccessorDirective implements ControlValueAccessor {
    private renderer;
    private el;
    private injInterceptor;
    private defaultInterceptor;
    private changes$;
    private touches$;
    private interceptor;
    constructor(renderer: Renderer2, el: ElementRef, injInterceptor: KitModelInterceptor, defaultInterceptor: KitDefaultModelInterceptor);
    inputHandler(event: any): void;
    keydownHandler(event: any): void;
    blurHandler(event: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(rawValue: any): void;
}
