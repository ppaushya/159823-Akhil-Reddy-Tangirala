import { Subject } from 'rxjs';
import { KitModelInterceptor } from './kit-model-interceptor';
export declare class KitDefaultModelInterceptor implements KitModelInterceptor {
    readonly viewStateChanges: Subject<string>;
    readonly modelStateChanges: Subject<any>;
    input(value: string, event: any): void;
    keyDown(event: any): void;
    writeValue(value: any): void;
}
