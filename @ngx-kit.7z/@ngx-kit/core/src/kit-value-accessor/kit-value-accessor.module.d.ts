export declare class KitValueAccessorModule {
}
