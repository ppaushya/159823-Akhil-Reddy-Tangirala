import { KitNgControlDirective } from './kit-ng-control/kit-ng-control.directive';
export declare class KitFormFieldService {
    private _controls;
    readonly control: KitNgControlDirective;
    readonly controls: KitNgControlDirective[];
    /**
     * Register KitNgControlDirective in the service.
     */
    add(control: KitNgControlDirective): void;
    remove(control: KitNgControlDirective): void;
    /**
     * Check if error exists.
     */
    hasError(name: string): boolean;
    /**
     * Has any error and control touched or dirty.
     */
    getErrorsToDisplay(): string[];
    /**
     * Is main control required.
     */
    isRequired(): boolean;
}
