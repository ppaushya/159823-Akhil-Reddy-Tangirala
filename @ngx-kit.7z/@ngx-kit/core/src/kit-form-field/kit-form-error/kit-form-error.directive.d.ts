import { TemplateRef } from '@angular/core';
/**
 * Structure directive for capturing form-error template.
 */
export declare class KitFormErrorDirective {
    templateRef: TemplateRef<any>;
    kitFormError: string;
    constructor(templateRef: TemplateRef<any>);
    readonly name: string;
}
