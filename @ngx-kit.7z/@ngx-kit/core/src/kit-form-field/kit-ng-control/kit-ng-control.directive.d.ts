import { DoCheck, IterableDiffers, OnDestroy } from '@angular/core';
import { NgControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { KitFormFieldService } from '../kit-form-field.service';
/**
 * Registers `control` in `KitFormFieldService`.
 *
 * Also generates unique _id (needed for correct working label in form-field).
 */
export declare class KitNgControlDirective implements OnDestroy, DoCheck {
    ngControl: NgControl;
    private formFieldService;
    private differs;
    required: boolean;
    private _id;
    private _errorStateChanges;
    private errorsDiffer;
    constructor(ngControl: NgControl, formFieldService: KitFormFieldService, differs: IterableDiffers);
    readonly idBinding: string;
    id: string;
    readonly errorStateChanges: Observable<string[]>;
    ngOnDestroy(): void;
    ngDoCheck(): void;
}
