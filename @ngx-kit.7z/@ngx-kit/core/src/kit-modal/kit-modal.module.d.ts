export declare class KitModalModule {
}
