import { Subject } from 'rxjs';
import { KitOverlayInput } from '../../';
import { Partial } from '../util/util';
import { KitModalOptions } from './meta';
export declare class KitModalRef<T> {
    readonly onClose: Subject<void>;
    readonly onDestroy: Subject<void>;
    private _options;
    options: Partial<KitModalOptions>;
    readonly instance: T;
    /**
     * Emit close event.
     */
    close(): void;
    /**
     * Pass input to the hosted component.
     */
    input(input: KitOverlayInput<T>): void;
}
