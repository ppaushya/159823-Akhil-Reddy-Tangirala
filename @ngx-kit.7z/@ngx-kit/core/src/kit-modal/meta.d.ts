import { ComponentFactoryResolver, Type, ViewContainerRef } from '@angular/core';
import { Partial } from '../../';
export declare class KitModalOptions {
    backdropClose: boolean;
    escClose: boolean;
    scrollLock: boolean;
}
export interface KitModalShowArgs<T> {
    component: Type<T>;
    options?: Partial<KitModalOptions>;
    componentFactoryResolver?: ComponentFactoryResolver;
    viewContainerRef?: ViewContainerRef;
}
export interface KitModalCanClose {
    canClose(): boolean;
}
