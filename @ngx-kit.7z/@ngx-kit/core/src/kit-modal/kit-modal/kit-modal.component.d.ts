import { AfterContentInit, EventEmitter, OnDestroy } from '@angular/core';
import { KitOverlayDirective } from '../../kit-overlay/kit-overlay/kit-overlay.directive';
import { KitModalRef } from '../kit-modal-ref';
import { KitModalService } from '../kit-modal.service';
import { KitModalOptions } from '../meta';
export declare class KitModalComponent implements OnDestroy, AfterContentInit {
    private ref;
    private service;
    private options;
    /**
     * Emits when modal should be closed.
     */
    close: EventEmitter<void>;
    overlay: KitOverlayDirective;
    private _displayed;
    constructor(ref: KitModalRef<any>, service: KitModalService, options: KitModalOptions);
    /**
     * Indicating if clicking the backdrop should close the modal.
     */
    backdropClose: boolean;
    /**
     * Indicating if pressing the `esc` key should close the modal.
     */
    escClose: boolean;
    /**
     * Indicating if scroll of body is disabled while modal is displayed.
     */
    scrollLock: boolean;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
}
