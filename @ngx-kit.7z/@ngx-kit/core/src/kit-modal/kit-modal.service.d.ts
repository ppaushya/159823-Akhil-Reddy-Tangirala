import { ComponentFactoryResolver } from '@angular/core';
import { KitEventManagerService } from '../kit-event-manager/kit-event-manager.service';
import { KitOverlayService } from '../kit-overlay/kit-overlay.service';
import { KitPlatformService } from '../kit-platform/kit-platform.service';
import { KitModalRef } from './kit-modal-ref';
import { KitModalOptions, KitModalShowArgs } from './meta';
export declare class KitModalService {
    private overlay;
    private em;
    private options;
    private document;
    private platform;
    private parent;
    private cfr;
    private backdropRef;
    private displayed;
    private isRoot;
    constructor(overlay: KitOverlayService, em: KitEventManagerService, options: KitModalOptions, document: any, platform: KitPlatformService, parent: KitModalService, cfr: ComponentFactoryResolver);
    /**
     * Display component as modal in the overlay.
     */
    show<T>({component, options, componentFactoryResolver, viewContainerRef}: KitModalShowArgs<T>): KitModalRef<T>;
    private checkBackdrop();
    private backdropClickHandler();
    private escHandler();
    private getTopModalRef();
    private initBackdrop();
}
