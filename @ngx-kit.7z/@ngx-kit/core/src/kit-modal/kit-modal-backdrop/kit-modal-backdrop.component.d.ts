import { ChangeDetectorRef, EventEmitter } from '@angular/core';
export declare class KitModalBackdropComponent {
    private cdr;
    close: EventEmitter<void>;
    private _display;
    constructor(cdr: ChangeDetectorRef);
    display: boolean;
}
