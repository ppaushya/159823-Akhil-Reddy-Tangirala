export declare function isMergeableObject(value: any): boolean;
export declare function isNonNullObject(value: any): boolean;
export declare function isNotSpecial(value: any): boolean;
