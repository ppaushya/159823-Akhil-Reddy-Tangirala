export declare function isString(x: any): x is string;
