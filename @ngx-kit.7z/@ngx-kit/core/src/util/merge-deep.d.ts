export declare function mergeDeep(target: any, source: any, optionsArgument?: any): any;
export declare function mergeDeepAll(array: any[], optionsArgument?: any): any;
