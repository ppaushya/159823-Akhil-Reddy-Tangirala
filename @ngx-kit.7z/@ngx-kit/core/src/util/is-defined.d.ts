export declare function isDefined(val: any): boolean;
