export declare function isObject(x: any): x is Object;
