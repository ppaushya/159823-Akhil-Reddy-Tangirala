export declare type Partial<T> = {
    [P in keyof T]?: T[P];
};
export declare type DeepPartial<T> = {
    [P in keyof T]?: DeepPartial<T[P]>;
};
