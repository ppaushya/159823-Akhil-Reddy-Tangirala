export declare function isUndefined(x: any): x is undefined;
