import { Observable } from 'rxjs';
import { KitCollapseId } from './meta';
export declare class KitCollapseHostService {
    multiple: boolean;
    private _active;
    private ids;
    /**
     * Get `Observable` with activated items.
     */
    readonly activeChanges: Observable<Set<KitCollapseId>>;
    /**
     * Get Set with activated items.
     */
    readonly active: Set<KitCollapseId>;
    /**
     * Activate item with id.
     */
    activate(id: KitCollapseId): void;
    /**
     * Activate first registered item.
     */
    activateFirst(): void;
    /**
     * Add item.
     */
    addId(id: KitCollapseId): void;
    /**
     * Deactivate item.
     */
    deactivate(id: KitCollapseId): void;
    /**
     * Delete item.
     */
    deleteId(id: KitCollapseId): void;
    /**
     * Is item activated.
     */
    isActive(id: KitCollapseId): boolean;
    /**
     * Change item activation state.
     */
    toggle(id: KitCollapseId): void;
}
