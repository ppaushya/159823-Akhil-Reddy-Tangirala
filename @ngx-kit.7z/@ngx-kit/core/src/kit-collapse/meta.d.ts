export declare type KitCollapseId = string | number | null;
