export declare class KitCollapseModule {
}
