import { OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { KitCollapseHostService } from '../kit-collapse-host.service';
import { KitCollapseItemService } from '../kit-collapse-item.service';
/**
 * Structure directive that collapsing.
 *
 * State based on `KitCollapseItemService` provided on a parent.
 */
export declare class KitCollapseDirective implements OnInit, OnDestroy {
    private vcr;
    private template;
    private host;
    private item;
    kitCollapse: void;
    private destroy;
    private displayed;
    constructor(vcr: ViewContainerRef, template: TemplateRef<any>, host: KitCollapseHostService, item: KitCollapseItemService);
    ngOnDestroy(): void;
    ngOnInit(): void;
}
