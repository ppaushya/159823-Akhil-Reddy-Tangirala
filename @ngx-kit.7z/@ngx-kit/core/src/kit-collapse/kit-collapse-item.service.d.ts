import { OnDestroy } from '@angular/core';
import { KitCollapseHostService } from './kit-collapse-host.service';
import { KitCollapseId } from './meta';
export declare class KitCollapseItemService implements OnDestroy {
    private host;
    private _id;
    constructor(host: KitCollapseHostService);
    /**
     * Is item activated.
     */
    /**
     * Set activation state.
     */
    active: boolean;
    /**
     * Get item id.
     */
    /**
     * Set item id.
     */
    id: KitCollapseId;
    ngOnDestroy(): void;
    /**
     * Toggle activation state.
     */
    toggle(): void;
}
