export declare class KitInputDateModule {
}
