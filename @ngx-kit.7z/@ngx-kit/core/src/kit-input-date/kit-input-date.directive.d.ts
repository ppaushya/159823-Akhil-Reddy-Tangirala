import { OnChanges } from '@angular/core';
import { Subject } from 'rxjs';
import { KitMomentProvider } from '../kit-moment/kit-moment-provider';
import { KitModelInterceptor } from '../kit-value-accessor/kit-model-interceptor';
export declare class KitInputDateDirective implements KitModelInterceptor, OnChanges {
    private momentProvider;
    kitInputDate: void;
    /**
     * `Date.toLocaleDateString()` options.
     */
    options: any;
    /**
     * Parse and render format (works only with moment.js).
     */
    format: string;
    readonly viewStateChanges: Subject<string>;
    readonly modelStateChanges: Subject<any>;
    private moment;
    constructor(momentProvider: KitMomentProvider<any>);
    ngOnChanges(): void;
    /**
     * Handle input changing by user.
     */
    input(value: string, event: any): void;
    keyDown(event: any): void;
    /**
     * Handle external modal changing.
     */
    writeValue(value: any): void;
    private parse(raw);
    private isValid(raw);
}
