import { ElementRef, OnChanges, OnDestroy, Renderer2, SimpleChanges } from '@angular/core';
import { KitIntersectionService } from '../../kit-intersection/kit-intersection.service';
import { KitPlatformService } from '../../kit-platform/kit-platform.service';
import { KitIconsRegistryService } from '../kit-icons-registry.service';
export declare class KitIconComponent implements OnChanges, OnDestroy {
    private registry;
    private el;
    private renderer;
    private platform;
    private intersection;
    /**
     * Svg fill color.
     */
    color: string;
    /**
     * Name in the registry.
     */
    name: string;
    /**
     * Size. If not specified icon size depends on line-height.
     * Height and width can be specified separately by passing array `[height, width]`.
     * Accepts any css sizing ('32px', '100%', '2em').
     */
    size: string | [string, string];
    /**
     * A11y title.
     */
    title: string;
    /**
     * A11y description.
     */
    desc: string;
    /**
     * Load and render icon only when visible.
     */
    intersectionLoad: boolean;
    private source;
    private svg;
    private nameChanges;
    private destroy;
    private titleEl;
    private descEl;
    constructor(registry: KitIconsRegistryService, el: ElementRef, renderer: Renderer2, platform: KitPlatformService, intersection: KitIntersectionService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private clear();
    private updateStyles();
    /**
     * Creates a DOM element from the given SVG string.
     */
    private svgElementFromString(str);
    private updateA11y();
    private mount();
}
