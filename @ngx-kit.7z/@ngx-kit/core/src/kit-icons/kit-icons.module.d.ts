/**
 * @todo register icons in forRoot().
 */
export declare class KitIconsModule {
}
