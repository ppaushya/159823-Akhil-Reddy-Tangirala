import { HttpClient } from '@angular/common/http';
import { KitIcon } from './meta';
/**
 * Icons registry.
 *
 * ```typescript
 * this.iconsRegistry.add({name: 'star', url: '/assets/icons/star.svg'});
 * // or
 * this.iconsRegistry.add([
 * {name: 'star', url: '/assets/icons/star.svg'},
 * {name: 'cloud', url: '/assets/icons/cloud.svg'},
 * ]);
 * ```
 *
 * Use in a template
 *
 * ```html
 * <kit-icon name="star"></kit-icon>
 * ```
 */
export declare class KitIconsRegistryService {
    private http;
    private cache;
    private icons;
    constructor(http: HttpClient);
    /**
     * Add icons to registry.
     */
    add(icon: KitIcon | KitIcon[]): void;
}
