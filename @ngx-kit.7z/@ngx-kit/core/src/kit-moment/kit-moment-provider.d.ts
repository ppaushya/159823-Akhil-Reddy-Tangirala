import { KitPlatformService } from '../kit-platform/kit-platform.service';
export declare class KitMomentProvider<T> {
    private platform;
    private _moment;
    constructor(platform: KitPlatformService);
    /**
     * Get Moment.js instance.
     * Returns null if not available.
     */
    readonly moment: T | null;
}
