import { ElementRef } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { KitAnchor } from '../../kit-anchor/meta';
import { KitOverlayToggleTrigger } from '../meta';
export declare class KitOverlayToggleDirective implements KitAnchor {
    private _elementRef;
    trigger: KitOverlayToggleTrigger;
    private _state;
    constructor(_elementRef: ElementRef);
    readonly stateChanges: Observable<boolean>;
    /**
     * Get state.
     */
    readonly state: boolean;
    /**
     * Get reference to anchored element.
     */
    readonly elementRef: ElementRef;
    /**
     * Get anchored html-element.
     */
    readonly nativeEl: any;
    clickHandler(): void;
    mouseenterHandler(): void;
    mouseleaveHandler(): void;
    /**
     * Set state to true.
     */
    show(): void;
    /**
     * Set state to false.
     */
    close(): void;
    /**
     * Toggle state.
     */
    toggle(): void;
}
