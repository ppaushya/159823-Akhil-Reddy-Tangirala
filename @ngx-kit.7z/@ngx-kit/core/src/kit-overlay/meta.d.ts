import { KitAnchor } from '../kit-anchor/meta';
export declare type KitOverlayPosition = 'top' | 'right' | 'bottom' | 'left' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'left-top' | 'left-bottom' | 'right-top' | 'right-bottom';
export declare type KitOverlayType = 'dropdown' | 'side';
export declare type KitOverlayAutofix = 'none' | 'switch-position';
export declare const positionPairs: {
    top: string;
    bottom: string;
    left: string;
    right: string;
};
export interface KitOverlayPositionDirectiveParams {
    anchor: KitAnchor | HTMLElement;
    autofix: KitOverlayAutofix;
    position: KitOverlayPosition;
    type: KitOverlayType;
}
export interface StrategyEl {
    bottom: number;
    height: number;
    left: number;
    right: number;
    top: number;
    width: number;
}
export interface StrategyField {
    width: number;
    height: number;
}
export declare type KitOverlayInput<T> = {
    [key in keyof T]?: T[key];
};
export declare type KitOverlayToggleTrigger = 'click' | 'hover';
