export declare class KitOverlayModule {
}
