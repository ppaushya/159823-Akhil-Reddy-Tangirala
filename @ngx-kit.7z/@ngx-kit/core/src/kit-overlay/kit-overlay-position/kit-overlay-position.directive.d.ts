import { OnChanges } from '@angular/core';
import { KitOverlayPositionDirectiveParams } from '../meta';
import { KitOverlayPositionService } from './kit-overlay-position.service';
/**
 * @deprecated Use KitPositionModule instead.
 * @todo remove in the next major release.
 */
export declare class KitOverlayPositionDirective implements OnChanges {
    private service;
    kitOverlayPosition: Partial<KitOverlayPositionDirectiveParams>;
    constructor(service: KitOverlayPositionService);
    ngOnChanges(): void;
}
