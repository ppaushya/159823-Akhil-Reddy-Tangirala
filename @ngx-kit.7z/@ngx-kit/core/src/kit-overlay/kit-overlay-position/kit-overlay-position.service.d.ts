import { ElementRef, NgZone, OnDestroy } from '@angular/core';
import { KitAnchor } from '../../kit-anchor/meta';
import { KitEventManagerService } from '../../kit-event-manager/kit-event-manager.service';
import { KitPlatformService } from '../../kit-platform/kit-platform.service';
import { KitStyleService } from '../../kit-style/kit-style.service';
import { KitOverlayAutofix, KitOverlayPosition, KitOverlayPositionDirectiveParams, KitOverlayType, StrategyEl } from '../meta';
import { DropdownPositioningService } from './dropdown-positioning.service';
import { SidePositioningService } from './side-positioning.service';
/**
 * Implements positioning mechanism.
 *
 * Should be provided on component or directive.
 *
 * @deprecated Use KitPositionModule instead.
 * @todo remove in the next major release.
 */
export declare class KitOverlayPositionService implements OnDestroy {
    private zone;
    private el;
    private style;
    private platform;
    private em;
    private dropdownStrategy;
    private sideStrategy;
    /**
     * Anchor element for placing.
     */
    anchor: KitAnchor | HTMLElement;
    /**
     * Do not cross window boundaries.
     *
     * * none - do nothing
     * * switch-position - change direction top-bottom / left-right
     */
    autofix: KitOverlayAutofix;
    position: KitOverlayPosition;
    type: KitOverlayType;
    private rawPosition;
    private unsubs;
    constructor(zone: NgZone, el: ElementRef, style: KitStyleService, platform: KitPlatformService, em: KitEventManagerService, dropdownStrategy: DropdownPositioningService, sideStrategy: SidePositioningService);
    ngOnDestroy(): void;
    applyParams(params: Partial<KitOverlayPositionDirectiveParams>): void;
    getRect(el: KitAnchor | HTMLElement): StrategyEl;
    reposition(): void;
    private autofixDropdown();
    private autofixSide(lastPosition?);
    private getEl(el);
    private getFieldSize();
    private repositionDropdown();
    private repositionSide();
    private runAutofix();
}
