import { KitStyles } from '../../kit-style/meta';
import { KitOverlayAutofix, KitOverlayPosition, StrategyEl, StrategyField } from '../meta';
export declare class DropdownPositioningService {
    autofix(el: StrategyEl, anchor: StrategyEl, field: StrategyField, position: KitOverlayPosition, autofix: KitOverlayAutofix): null | {
        position: KitOverlayPosition;
        styles: KitStyles;
    };
    reposition(anchor: StrategyEl, field: StrategyField, position: KitOverlayPosition): KitStyles;
}
