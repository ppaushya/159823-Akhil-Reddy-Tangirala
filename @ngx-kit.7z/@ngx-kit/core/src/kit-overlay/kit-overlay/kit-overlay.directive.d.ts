import { ChangeDetectorRef, OnChanges, OnDestroy, SimpleChanges, TemplateRef, ViewContainerRef, ViewRef } from '@angular/core';
import { Observable } from 'rxjs';
import { KitOverlayService } from '../kit-overlay.service';
export declare class KitOverlayDirective implements OnChanges, OnDestroy {
    private templateRef;
    private service;
    private cdr;
    private vcr;
    kitOverlay: boolean;
    private doCheckSub;
    private _viewRef;
    private _displayed;
    constructor(templateRef: TemplateRef<any>, service: KitOverlayService, cdr: ChangeDetectorRef, vcr: ViewContainerRef);
    readonly displayed: Observable<boolean>;
    readonly viewRef: ViewRef | null;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    updateHost(): void;
    private destroyView();
}
