import { ComponentRef } from '@angular/core';
import { KitOverlayInput } from './meta';
export declare class KitOverlayComponentRef<T> {
    componentRef: ComponentRef<T>;
    /**
     * Pass input to the hosted component.
     */
    input(input: KitOverlayInput<T>): void;
}
