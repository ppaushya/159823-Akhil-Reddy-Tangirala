import { ComponentFactoryResolver, Injector, TemplateRef, Type, ViewContainerRef, ViewRef } from '@angular/core';
import { StaticProvider } from '@angular/core/src/di/provider';
import { Observable } from 'rxjs';
import { KitPlatformService } from '../kit-platform/kit-platform.service';
import { KitOverlayComponentRef } from './kit-overlay-component-ref';
export declare class KitOverlayService {
    private document;
    private cfr;
    private injector;
    private parent;
    private platform;
    private _onHostStable;
    private hostWrapperRef;
    private hostRef;
    private host;
    private container;
    private isRoot;
    constructor(document: any, cfr: ComponentFactoryResolver, injector: Injector, parent: KitOverlayService, platform: KitPlatformService);
    readonly onHostStable: Observable<void>;
    /**
     * Render component in the overlay.
     */
    hostComponent<T>({component, providers, componentFactoryResolver, viewContainerRef}: {
        component: Type<T>;
        providers?: StaticProvider[];
        componentFactoryResolver?: ComponentFactoryResolver;
        viewContainerRef?: ViewContainerRef;
    }): KitOverlayComponentRef<T>;
    /**
     * Render template (passed by TemplateRef) on the overlay.
     */
    hostTemplate({templateRef, context, viewContainerRef}: {
        templateRef: TemplateRef<any>;
        context?: any;
        viewContainerRef?: ViewContainerRef;
    }): ViewRef;
    /**
     * Move passed ViewRef under target ViewRef.
     * Used for multi-modals backdrop handling.
     */
    moveUnder(ref: ViewRef, target: ViewRef): void;
    /** Gets the root HTMLElement for an instantiated component. */
    private getComponentRootNode(componentRef);
    private getTemplateRootNode(viewRef);
    private mountHost();
}
