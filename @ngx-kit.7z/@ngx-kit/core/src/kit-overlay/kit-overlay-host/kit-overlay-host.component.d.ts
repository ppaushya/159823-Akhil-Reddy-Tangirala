import { ChangeDetectorRef, ElementRef, NgZone, ViewContainerRef } from '@angular/core';
export declare class KitOverlayHostComponent {
    zone: NgZone;
    vcr: ViewContainerRef;
    cdr: ChangeDetectorRef;
    elRef: ElementRef;
    constructor(zone: NgZone, vcr: ViewContainerRef, cdr: ChangeDetectorRef, elRef: ElementRef);
}
