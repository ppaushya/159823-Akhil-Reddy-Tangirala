import { ViewContainerRef } from '@angular/core';
export declare class KitOverlayHostWrapperComponent {
    vcr: ViewContainerRef;
    constructor(vcr: ViewContainerRef);
}
