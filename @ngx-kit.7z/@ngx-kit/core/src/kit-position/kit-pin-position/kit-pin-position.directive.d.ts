import { ElementRef, NgZone, OnChanges } from '@angular/core';
import { KitAnchor } from '../../kit-anchor/meta';
import { KitEventManagerService } from '../../kit-event-manager/kit-event-manager.service';
import { KitPlatformService } from '../../kit-platform/kit-platform.service';
import { KitStyleService } from '../../kit-style/kit-style.service';
import { KitPinPosition } from '../meta';
export declare class KitPinPositionDirective implements OnChanges {
    private elementRef;
    private zone;
    private style;
    private platform;
    private em;
    kitPinPosition: void;
    anchor: KitAnchor | HTMLElement;
    position: KitPinPosition;
    private unsubs;
    constructor(elementRef: ElementRef, zone: NgZone, style: KitStyleService, platform: KitPlatformService, em: KitEventManagerService);
    ngOnChanges(): void;
    private reposition();
    private calc(position, field, anchor);
    private getRect(el);
    private getEl(el);
    private getField();
    private px(value);
}
