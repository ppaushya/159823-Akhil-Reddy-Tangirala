export declare class KitPositionModule {
}
