import { ElementRef } from '@angular/core';
import { KitAnchor } from './meta';
/**
 * Anchor for passing link to element to the overlay or similar.
 */
export declare class KitAnchorDirective implements KitAnchor {
    private _elementRef;
    kitAnchor: any;
    constructor(_elementRef: ElementRef);
    /**
     * Get reference to anchored element.
     */
    readonly elementRef: ElementRef;
    /**
     * Get anchored html-element.
     */
    readonly nativeEl: any;
}
