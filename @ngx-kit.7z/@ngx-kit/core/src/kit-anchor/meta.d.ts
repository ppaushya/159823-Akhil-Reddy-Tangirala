import { ElementRef } from '@angular/core';
export interface KitAnchor {
    elementRef: ElementRef;
    nativeEl: HTMLElement;
}
