export declare class KitAnchorModule {
}
