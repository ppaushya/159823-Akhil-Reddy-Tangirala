The sources for this package are in the main [ngx-kit](https://github.com/ngx-kit/ngx-kit) repo. Please file issues and pull requests against that repo.
