import { __spread, __read } from 'tslib';
import { Directive, ElementRef, Input, NgModule, Injectable, IterableDiffers, Renderer2, forwardRef, Host, HostListener, TemplateRef, ViewContainerRef, Optional, Inject, PLATFORM_ID, NgZone, HostBinding, ChangeDetectionStrategy, Component, EventEmitter, Output, ChangeDetectorRef, InjectionToken, ContentChild, ComponentFactoryResolver, Injector, SkipSelf, SimpleChange, KeyValueDiffers, defineInjectable, inject, INJECTOR } from '@angular/core';
import { CommonModule, isPlatformBrowser, isPlatformServer, DOCUMENT } from '@angular/common';
import { NG_VALUE_ACCESSOR, NgControl, ControlContainer, FormGroup } from '@angular/forms';
import { Subject, BehaviorSubject, from, Observable } from 'rxjs';
import { takeUntil, take, filter, map, tap, mapTo, switchMap } from 'rxjs/operators';
import { EventManager, HammerGestureConfig } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { animate, style, transition, trigger } from '@angular/animations';
import { BehaviorSubject as BehaviorSubject$1 } from 'rxjs/internal/BehaviorSubject';

var KitAnchorDirective = /** @class */ (function () {
    function KitAnchorDirective(_elementRef) {
        this._elementRef = _elementRef;
    }
    Object.defineProperty(KitAnchorDirective.prototype, "elementRef", {
        get: function () {
            return this._elementRef;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitAnchorDirective.prototype, "nativeEl", {
        get: function () {
            return this._elementRef.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    return KitAnchorDirective;
}());
KitAnchorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitAnchor]',
                exportAs: 'anchor',
            },] },
];
KitAnchorDirective.ctorParameters = function () { return [
    { type: ElementRef, },
]; };
KitAnchorDirective.propDecorators = {
    "kitAnchor": [{ type: Input },],
};
var KitAnchorModule = /** @class */ (function () {
    function KitAnchorModule() {
    }
    return KitAnchorModule;
}());
KitAnchorModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitAnchorDirective,
                ],
                exports: [
                    KitAnchorDirective,
                ],
            },] },
];
function isString(x) {
    return typeof x === 'string';
}
var KitClassService = /** @class */ (function () {
    function KitClassService(renderer, el, differs) {
        this.renderer = renderer;
        this.el = el;
        this.differs = differs;
        this._state = {};
    }
    Object.defineProperty(KitClassService.prototype, "state", {
        set: function (setterRaw) {
            var newState = Object.assign({}, setterRaw);
            this.process(newState);
        },
        enumerable: true,
        configurable: true
    });
    KitClassService.prototype.apply = function (setter) {
        var newState = Object.assign({}, this._state, setter);
        this.process(newState);
    };
    KitClassService.prototype.process = function (newState) {
        var classList = this.processObj(newState);
        if (!this._differ) {
            this._differ = this.differs.find(classList).create();
        }
        var changes = this._differ.diff(classList);
        if (changes) {
            this.applyChanges(changes);
            this._state = newState;
        }
    };
    KitClassService.prototype.applyChanges = function (changes) {
        var _this = this;
        changes.forEachRemovedItem(function (record) { return _this.renderer.removeClass(_this.el.nativeElement, record.item); });
        changes.forEachAddedItem(function (record) { return _this.renderer.addClass(_this.el.nativeElement, record.item); });
    };
    KitClassService.prototype.processObj = function (obj) {
        return Object.keys(obj)
            .map(function (key) {
            var value = obj[key];
            return isString(value)
                ? key + "-" + value
                : !!value
                    ? key
                    : null;
        })
            .filter(isString);
    };
    return KitClassService;
}());
KitClassService.decorators = [
    { type: Injectable },
];
KitClassService.ctorParameters = function () { return [
    { type: Renderer2, },
    { type: ElementRef, },
    { type: IterableDiffers, },
]; };
function isDefined(val) {
    return val !== null && val !== undefined;
}
var KIT_CHECK_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(function () { return KitCheckDirective; }),
    multi: true,
};
var KitCheckDirective = /** @class */ (function () {
    function KitCheckDirective(kitClass) {
        this.kitClass = kitClass;
        this.checkedClass = 'checked';
        this.changes = new Subject();
        this.touches = new Subject();
    }
    KitCheckDirective.prototype.ngOnChanges = function (changes) {
    };
    KitCheckDirective.prototype.clickListener = function () {
        if (isDefined(this.value)) {
            this.checked = true;
            this.changes.next(this.value);
        }
        else {
            this.checked = !this.checked;
            this.changes.next(this.checked);
        }
        this.touches.next();
        this.applyClass();
    };
    KitCheckDirective.prototype.registerOnChange = function (fn) {
        this.changes.subscribe(fn);
    };
    KitCheckDirective.prototype.registerOnTouched = function (fn) {
        this.touches.subscribe(fn);
    };
    KitCheckDirective.prototype.setDisabledState = function (isDisabled) {
        this.disabled = isDisabled;
    };
    KitCheckDirective.prototype.writeValue = function (value) {
        if (isDefined(this.value)) {
            this.checked = this.value === value;
        }
        else {
            this.checked = value;
        }
        this.applyClass();
    };
    KitCheckDirective.prototype.applyClass = function () {
        this.kitClass.apply({
            checked: this.checked,
        });
    };
    return KitCheckDirective;
}());
KitCheckDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitCheck]',
                providers: [
                    KIT_CHECK_VALUE_ACCESSOR,
                    KitClassService,
                ],
            },] },
];
KitCheckDirective.ctorParameters = function () { return [
    { type: KitClassService, decorators: [{ type: Host },] },
]; };
KitCheckDirective.propDecorators = {
    "checkedClass": [{ type: Input },],
    "kitCheck": [{ type: Input },],
    "value": [{ type: Input },],
    "clickListener": [{ type: HostListener, args: ['click',] },],
};
var KitCheckModule = /** @class */ (function () {
    function KitCheckModule() {
    }
    return KitCheckModule;
}());
KitCheckModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitCheckDirective,
                ],
                declarations: [
                    KitCheckDirective,
                ],
            },] },
];
var KitClassDirective = /** @class */ (function () {
    function KitClassDirective(service) {
        this.service = service;
    }
    KitClassDirective.prototype.ngOnChanges = function (changes) {
        if (changes['kitClass']) {
            this.service.apply(this.kitClass);
        }
    };
    return KitClassDirective;
}());
KitClassDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitClass]',
                providers: [KitClassService],
            },] },
];
KitClassDirective.ctorParameters = function () { return [
    { type: KitClassService, },
]; };
KitClassDirective.propDecorators = {
    "kitClass": [{ type: Input },],
};
var KitClassModule = /** @class */ (function () {
    function KitClassModule() {
    }
    return KitClassModule;
}());
KitClassModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    KitClassDirective,
                ],
                exports: [
                    KitClassDirective,
                ],
            },] },
];
var KitCollapseHostService = /** @class */ (function () {
    function KitCollapseHostService() {
        this.multiple = false;
        this._active = new BehaviorSubject(new Set());
        this.ids = new Set();
    }
    Object.defineProperty(KitCollapseHostService.prototype, "activeChanges", {
        get: function () {
            return this._active.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitCollapseHostService.prototype, "active", {
        get: function () {
            return new Set(this._active.value);
        },
        enumerable: true,
        configurable: true
    });
    KitCollapseHostService.prototype.activate = function (id) {
        var current = this._active.value;
        if (!current.has(id)) {
            if (this.multiple) {
                this._active.next(new Set(current).add(id));
            }
            else {
                this._active.next(new Set().add(id));
            }
        }
    };
    KitCollapseHostService.prototype.activateFirst = function () {
        this.activate(this.ids.values().next().value);
    };
    KitCollapseHostService.prototype.addId = function (id) {
        this.ids.add(id);
    };
    KitCollapseHostService.prototype.deactivate = function (id) {
        var current = this._active.value;
        if (current.has(id)) {
            this._active.next(new Set(Array.from(current).filter(function (i) { return i !== id; })));
        }
    };
    KitCollapseHostService.prototype.deleteId = function (id) {
        this.ids.delete(id);
    };
    KitCollapseHostService.prototype.isActive = function (id) {
        var current = this._active.value;
        return current.has(id);
    };
    KitCollapseHostService.prototype.toggle = function (id) {
        var current = this._active.value;
        if (current.has(id)) {
            this.deactivate(id);
        }
        else {
            this.activate(id);
        }
    };
    return KitCollapseHostService;
}());
KitCollapseHostService.decorators = [
    { type: Injectable },
];
function uuid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}
var KitCollapseItemService = /** @class */ (function () {
    function KitCollapseItemService(host) {
        this.host = host;
        this.id = uuid();
    }
    Object.defineProperty(KitCollapseItemService.prototype, "active", {
        get: function () {
            return this.host.isActive(this._id);
        },
        set: function (active) {
            if (active) {
                this.host.activate(this._id);
            }
            else {
                this.host.deactivate(this._id);
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitCollapseItemService.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (id) {
            if (id) {
                this.host.deleteId(this._id);
                this.host.addId(id);
                this._id = id;
            }
            else {
                throw new Error('id is empty');
            }
        },
        enumerable: true,
        configurable: true
    });
    KitCollapseItemService.prototype.ngOnDestroy = function () {
        this.host.deleteId(this._id);
    };
    KitCollapseItemService.prototype.toggle = function () {
        this.host.toggle(this._id);
    };
    return KitCollapseItemService;
}());
KitCollapseItemService.decorators = [
    { type: Injectable },
];
KitCollapseItemService.ctorParameters = function () { return [
    { type: KitCollapseHostService, },
]; };
var KitCollapseDirective = /** @class */ (function () {
    function KitCollapseDirective(vcr, template, host, item) {
        this.vcr = vcr;
        this.template = template;
        this.host = host;
        this.item = item;
        this.destroy = new Subject();
        this.displayed = false;
    }
    KitCollapseDirective.prototype.ngOnDestroy = function () {
        this.destroy.next();
    };
    KitCollapseDirective.prototype.ngOnInit = function () {
        var _this = this;
        this.host.activeChanges
            .pipe(takeUntil(this.destroy))
            .subscribe(function (ids) {
            if (ids.has(_this.item.id)) {
                if (!_this.displayed) {
                    _this.vcr.createEmbeddedView(_this.template);
                    _this.displayed = true;
                }
            }
            else {
                if (_this.displayed) {
                    _this.vcr.clear();
                    _this.displayed = false;
                }
            }
        });
    };
    return KitCollapseDirective;
}());
KitCollapseDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitCollapse]',
            },] },
];
KitCollapseDirective.ctorParameters = function () { return [
    { type: ViewContainerRef, },
    { type: TemplateRef, },
    { type: KitCollapseHostService, },
    { type: KitCollapseItemService, },
]; };
KitCollapseDirective.propDecorators = {
    "kitCollapse": [{ type: Input },],
};
var KitCollapseModule = /** @class */ (function () {
    function KitCollapseModule() {
    }
    return KitCollapseModule;
}());
KitCollapseModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitCollapseDirective,
                ],
                declarations: [
                    KitCollapseDirective,
                ],
            },] },
];
var KitDatePickerService = /** @class */ (function () {
    function KitDatePickerService(renderer) {
        this.renderer = renderer;
        this.moveHandlerUnsubs = [];
        this._grid = new BehaviorSubject([]);
        this._monthCursor = new BehaviorSubject(null);
        this._pick = new Subject();
    }
    Object.defineProperty(KitDatePickerService.prototype, "active", {
        set: function (date) {
            this._active = new Date(date);
            this._focus = new Date(date);
            this.updateGrid();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitDatePickerService.prototype, "gridChanges", {
        get: function () {
            return this._grid.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitDatePickerService.prototype, "monthCursorChanges", {
        get: function () {
            return this._monthCursor.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitDatePickerService.prototype, "pick", {
        get: function () {
            return this._pick.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitDatePickerService.prototype, "weekdays", {
        get: function () {
            var weekdays = [];
            var cursor = this.startOfWeek(new Date());
            for (var i = 0; i < 7; i++) {
                weekdays.push(new Date(cursor));
                cursor.setDate(cursor.getDate() + 1);
            }
            return weekdays;
        },
        enumerable: true,
        configurable: true
    });
    KitDatePickerService.prototype.ngOnDestroy = function () {
        this.moveHandlerUnsubs.forEach(function (u) { return u(); });
    };
    KitDatePickerService.prototype.focus = function (date) {
        this._focus = new Date(date);
        this.updateGrid();
    };
    KitDatePickerService.prototype.modMonth = function (modifier) {
        this._focus.setMonth(this._focus.getMonth() + modifier);
        this.updateGrid();
    };
    KitDatePickerService.prototype.modYear = function (modifier) {
        this._focus.setFullYear(this._focus.getFullYear() + modifier);
        this.updateGrid();
    };
    KitDatePickerService.prototype.handleMove = function (target) {
        var _this = this;
        if (this.renderer) {
            this.moveHandlerUnsubs = [
                this.renderer.listen(target, 'keydown.ArrowRight', function (e) {
                    e.preventDefault();
                    _this._focus.setDate(_this._focus.getDate() + 1);
                    _this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.ArrowLeft', function (e) {
                    e.preventDefault();
                    _this._focus.setDate(_this._focus.getDate() - 1);
                    _this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.ArrowUp', function (e) {
                    e.preventDefault();
                    _this._focus.setDate(_this._focus.getDate() - 7);
                    _this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.ArrowDown', function (e) {
                    e.preventDefault();
                    _this._focus.setDate(_this._focus.getDate() + 7);
                    _this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.Home', function (e) {
                    e.preventDefault();
                    _this._focus.setDate(1);
                    _this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.End', function (e) {
                    e.preventDefault();
                    _this._focus.setMonth(_this._focus.getMonth() + 1, 0);
                    _this.updateGrid();
                }),
                this.renderer.listen(target, 'keydown.PageUp', function (e) {
                    e.preventDefault();
                    _this.modMonth(-1);
                }),
                this.renderer.listen(target, 'keydown.PageDown', function (e) {
                    e.preventDefault();
                    _this.modMonth(1);
                }),
                this.renderer.listen(target, 'keydown.Alt.PageUp', function (e) {
                    e.preventDefault();
                    _this.modYear(-1);
                }),
                this.renderer.listen(target, 'keydown.Alt.PageDown', function (e) {
                    e.preventDefault();
                    _this.modYear(1);
                }),
                this.renderer.listen(target, 'keydown.Enter', function (e) {
                    e.preventDefault();
                    _this._pick.next(new Date(_this._focus));
                }),
                this.renderer.listen(target, 'keydown.Space', function (e) {
                    e.preventDefault();
                    _this._pick.next(new Date(_this._focus));
                }),
            ];
        }
    };
    KitDatePickerService.prototype.isDatesEqual = function (x, y) {
        if (x && y) {
            var xp = new Date(x);
            xp.setHours(0, 0, 0, 0);
            var yp = new Date(y);
            yp.setHours(0, 0, 0, 0);
            return +xp === +yp;
        }
        else {
            throw new Error('isDatesEqual params error');
        }
    };
    KitDatePickerService.prototype.startOfMonth = function (curr) {
        return new Date(curr.getFullYear(), curr.getMonth(), 1);
    };
    KitDatePickerService.prototype.startOfWeek = function (curr) {
        var date = new Date(curr);
        var day = date.getDay() || 7;
        if (day !== 1) {
            date.setHours(-24 * (day - 1));
        }
        return date;
    };
    KitDatePickerService.prototype.updateGrid = function () {
        var _this = this;
        if (this._monthCursor.value &&
            this.isDatesEqual(this.startOfMonth(this._focus), this.startOfMonth(this._monthCursor.value))) {
            var grid = this._grid.value;
            grid.forEach(function (r) { return r.forEach(function (c) {
                c.active = _this.isDatesEqual(c.date, _this._active);
                c.focus = _this.isDatesEqual(c.date, _this._focus);
            }); });
            this._grid.next(grid);
        }
        else {
            var month = this.startOfMonth(this._focus);
            var grid = [];
            var cursor = this.startOfWeek(month);
            for (var row = 0; row < this.weeksInMonth(month); row++) {
                var line = [];
                for (var col = 0; col < 7; col++) {
                    var date = new Date(cursor);
                    line.push({
                        active: this.isDatesEqual(date, this._active),
                        date: date,
                        focus: this.isDatesEqual(date, this._focus),
                        outside: date.getMonth() !== month.getMonth(),
                    });
                    cursor.setDate(cursor.getDate() + 1);
                }
                grid.push(line);
            }
            this._monthCursor.next(month);
            this._grid.next(grid);
        }
    };
    KitDatePickerService.prototype.weeksInMonth = function (curr) {
        var firstOfMonth = new Date(curr.getFullYear(), curr.getMonth(), 1);
        var day = firstOfMonth.getDay() || 6;
        day = day === 1 ? 0 : day;
        if (day) {
            day--;
        }
        var diff = 7 - day;
        var lastOfMonth = new Date(curr.getFullYear(), curr.getMonth() + 1, 0);
        var lastDate = lastOfMonth.getDate();
        if (lastOfMonth.getDay() === 1) {
            diff--;
        }
        return Math.ceil((lastDate - diff) / 7) + 1;
    };
    return KitDatePickerService;
}());
KitDatePickerService.decorators = [
    { type: Injectable },
];
KitDatePickerService.ctorParameters = function () { return [
    { type: Renderer2, decorators: [{ type: Optional },] },
]; };
var KitDatePickerModule = /** @class */ (function () {
    function KitDatePickerModule() {
    }
    return KitDatePickerModule;
}());
KitDatePickerModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
            },] },
];
var KitPlatformService = /** @class */ (function () {
    function KitPlatformService(platformId) {
        this.platformId = platformId;
    }
    KitPlatformService.prototype.isBrowser = function () {
        return isPlatformBrowser(this.platformId);
    };
    KitPlatformService.prototype.isServer = function () {
        return isPlatformServer(this.platformId);
    };
    KitPlatformService.prototype.getScrollbarWidth = function () {
        if (this.isBrowser()) {
            if (typeof document === 'undefined') {
                return 0;
            }
            var body = document.body;
            var box = document.createElement('div');
            var boxStyle = box.style;
            var width = void 0;
            boxStyle.position = 'absolute';
            boxStyle.position = boxStyle.position = '-9999px';
            boxStyle.height = boxStyle.width = '100px';
            boxStyle.overflow = 'scroll';
            body.appendChild(box);
            width = box.offsetWidth - box.clientWidth;
            body.removeChild(box);
            return width;
        }
        else {
            return 0;
        }
    };
    return KitPlatformService;
}());
KitPlatformService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitPlatformService.ctorParameters = function () { return [
    { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] },] },
]; };
KitPlatformService.ngInjectableDef = defineInjectable({ factory: function KitPlatformService_Factory() { return new KitPlatformService(inject(PLATFORM_ID)); }, token: KitPlatformService, providedIn: "root" });
var KitEventManagerService = /** @class */ (function () {
    function KitEventManagerService(platform) {
        this.platform = platform;
    }
    KitEventManagerService.prototype.listenGlobal = function (eventName, handler, useCapture) {
        if (this.platform.isBrowser()) {
            window.addEventListener(eventName, (handler), useCapture);
            return function () { return window.removeEventListener(eventName, (handler), useCapture); };
        }
        else {
            return function () {
            };
        }
    };
    KitEventManagerService.prototype.getEventPath = function (event) {
        if (this.platform.isBrowser()) {
            var path = [];
            var node = event.target;
            while (node && node !== document.body) {
                path.push(node);
                node = node['parentNode'];
            }
            return path;
        }
        else {
            return [];
        }
    };
    return KitEventManagerService;
}());
KitEventManagerService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitEventManagerService.ctorParameters = function () { return [
    { type: KitPlatformService, },
]; };
KitEventManagerService.ngInjectableDef = defineInjectable({ factory: function KitEventManagerService_Factory() { return new KitEventManagerService(inject(KitPlatformService)); }, token: KitEventManagerService, providedIn: "root" });
var keyArrowUp = 38;
var keyArrowDown = 40;
var keyArrowRight = 39;
var keyArrowLeft = 37;
var keyPageUp = 33;
var keyPageDown = 34;
var keyHome = 36;
var keyEnd = 35;
var keyEnter = 13;
var keySpace = 32;
var keyTab = 9;
var keyEscape = 27;
var keyBackspace = 8;
var keyDelete = 46;
var keyShift = 16;
var keyCtrl = 17;
var keyAlt = 18;
var KitFocusListenerService = /** @class */ (function () {
    function KitFocusListenerService(em) {
        this.em = em;
        this._focused = false;
        this._focus = new Subject();
        this._blur = new Subject();
        this.elements = [];
    }
    Object.defineProperty(KitFocusListenerService.prototype, "focus", {
        get: function () {
            return this._focus.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitFocusListenerService.prototype, "blur", {
        get: function () {
            return this._blur.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitFocusListenerService.prototype, "focused", {
        get: function () {
            return this._focused;
        },
        enumerable: true,
        configurable: true
    });
    KitFocusListenerService.prototype.add = function (el) {
        var _this = this;
        this.elements.push({
            el: el,
            focus: this.em.addEventListener(el, 'focus', function (event) {
                if (!_this._focused) {
                    _this._focused = true;
                    _this._focus.next(event);
                }
            }),
            blur: this.em.addEventListener(el, 'blur', function (event) {
                _this.checkLeave(event);
            }),
        });
    };
    KitFocusListenerService.prototype.remove = function (el) {
        var index = this.elements.findIndex(function (e) { return e.el === el; });
        if (index) {
            var element = this.elements[index];
            element.focus();
            element.blur();
            this.elements.splice(index, 1);
        }
        else {
            throw new Error('Element has not been registered in KitFocusListenerService');
        }
    };
    KitFocusListenerService.prototype.checkLeave = function (event) {
        var leave = true;
        this.elements.forEach(function (el) {
            if (el.el.contains(event.relatedTarget)) {
                leave = false;
            }
        });
        if (leave) {
            this._focused = false;
            this._blur.next(event);
        }
    };
    return KitFocusListenerService;
}());
KitFocusListenerService.decorators = [
    { type: Injectable },
];
KitFocusListenerService.ctorParameters = function () { return [
    { type: EventManager, },
]; };
var KitFocusManagerRegistryService = /** @class */ (function () {
    function KitFocusManagerRegistryService() {
        this.stack = [];
    }
    KitFocusManagerRegistryService.prototype.capture = function (manager) {
        var top = this.getTop();
        if (top) {
            top.onHold = true;
        }
        this.stack.push(manager);
    };
    KitFocusManagerRegistryService.prototype.release = function (manager) {
        var index = this.stack.indexOf(manager);
        if (index !== -1) {
            var isTop = this.stack.indexOf(manager) === this.stack.length - 1;
            this.stack.splice(index, 1);
            if (isTop) {
                var newTop = this.getTop();
                if (newTop) {
                    newTop.onHold = false;
                }
            }
        }
    };
    KitFocusManagerRegistryService.prototype.getTop = function () {
        return this.stack[this.stack.length - 1];
    };
    return KitFocusManagerRegistryService;
}());
KitFocusManagerRegistryService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitFocusManagerRegistryService.ngInjectableDef = defineInjectable({ factory: function KitFocusManagerRegistryService_Factory() { return new KitFocusManagerRegistryService(); }, token: KitFocusManagerRegistryService, providedIn: "root" });
var KitFocusManagerService = /** @class */ (function () {
    function KitFocusManagerService(el, zone, renderer, em, registry) {
        this.el = el;
        this.zone = zone;
        this.renderer = renderer;
        this.em = em;
        this.registry = registry;
        this.autoCapture = false;
        this.onHold = false;
        this.focusTrap = false;
        this.items = new Set();
        this.unsubs = [];
    }
    Object.defineProperty(KitFocusManagerService.prototype, "documentActiveElement", {
        get: function () {
            return (this.el.nativeElement.ownerDocument.activeElement);
        },
        enumerable: true,
        configurable: true
    });
    KitFocusManagerService.prototype.ngOnDestroy = function () {
        this.unsubs.forEach(function (u) { return u(); });
        if (this.outsideSource) {
            this.release();
        }
    };
    KitFocusManagerService.prototype.capture = function () {
        this.registry.capture(this);
        this.focusTrap = true;
        this.outsideSource = this.documentActiveElement;
        this.focusFirst();
    };
    KitFocusManagerService.prototype.focusFirst = function () {
        var nodes = this.getTabbable();
        if (nodes.length > 0) {
            nodes[0].focus();
        }
    };
    KitFocusManagerService.prototype.focusItem = function (id) {
        var _this = this;
        this.zone.onStable
            .pipe(take(1))
            .subscribe(function () {
            _this.items.forEach(function (i) {
                if (i.kitFocus === id) {
                    i.focus();
                }
            });
        });
    };
    KitFocusManagerService.prototype.focusLast = function () {
        var nodes = this.getTabbable();
        if (nodes.length > 0) {
            nodes[nodes.length - 1].focus();
        }
    };
    KitFocusManagerService.prototype.focusNext = function () {
        var current = this.documentActiveElement;
        var nodes = this.getTabbable();
        var currentIndex = nodes.findIndex(function (n) { return n === current; });
        if (currentIndex !== -1 && currentIndex < nodes.length - 1) {
            nodes[currentIndex + 1].focus();
        }
        else {
            this.focusFirst();
        }
    };
    KitFocusManagerService.prototype.focusPrev = function () {
        var current = this.documentActiveElement;
        var nodes = this.getTabbable();
        var currentIndex = nodes.findIndex(function (n) { return n === current; });
        if (currentIndex !== -1 && currentIndex > 0) {
            nodes[currentIndex - 1].focus();
        }
        else {
            this.focusLast();
        }
    };
    KitFocusManagerService.prototype.init = function () {
        var _this = this;
        this.zone.runOutsideAngular(function () {
            _this.unsubs = [
                _this.renderer.listen(_this.el.nativeElement, 'focusin', _this.focusinHandler.bind(_this)),
                _this.renderer.listen(_this.el.nativeElement, 'focusout', _this.focusoutHandler.bind(_this)),
                _this.em.listenGlobal('keydown', _this.keydownHandler.bind(_this), true),
            ];
        });
        if (this.autoCapture) {
            this.zone.onStable
                .pipe(take(1))
                .subscribe(function () {
                _this.capture();
            });
        }
    };
    KitFocusManagerService.prototype.add = function (item) {
        this.items.add(item);
    };
    KitFocusManagerService.prototype.release = function () {
        this.registry.release(this);
        this.focusTrap = false;
        this.outsideSource.focus();
    };
    KitFocusManagerService.prototype.remove = function (item) {
        this.items.delete(item);
    };
    KitFocusManagerService.prototype.focusinHandler = function (event) {
        if (!this.onHold && this.isDescendant(this.el.nativeElement, (event.target))) {
            this.current = (event.target);
        }
    };
    KitFocusManagerService.prototype.focusoutHandler = function (event) {
        if (!this.onHold
            && event.relatedTarget
            && !this.isDescendant(this.el.nativeElement, (event.relatedTarget))) {
            if (this.focusTrap) {
                if (this.current) {
                    this.current.focus();
                }
                else {
                    this.focusFirst();
                }
            }
        }
    };
    KitFocusManagerService.prototype.getTabbable = function () {
        var selectors = [
            'input',
            'select',
            'a[href]',
            'textarea',
            'button',
            '[tabindex]',
        ];
        var candidates = this.el.nativeElement.querySelectorAll(selectors);
        var basicTabbables = [];
        var orderedTabbables = [];
        for (var i = 0, l = candidates.length; i < l; i++) {
            var candidate = candidates[i];
            var candidateIndex = parseInt(candidate.getAttribute('tabindex'), 10) || candidate.tabIndex;
            if (candidateIndex < 0
                || (candidate.tagName === 'INPUT' && candidate.type === 'hidden')
                || candidate.disabled) {
                continue;
            }
            if (candidateIndex === 0) {
                basicTabbables.push(candidate);
            }
            else {
                orderedTabbables.push({
                    index: i,
                    tabIndex: candidateIndex,
                    node: candidate,
                });
            }
        }
        var tabbableNodes = orderedTabbables
            .sort(function (a, b) {
            return a.tabIndex === b.tabIndex ? a.index - b.index : a.tabIndex - b.tabIndex;
        })
            .map(function (a) {
            return a.node;
        });
        Array.prototype.push.apply(tabbableNodes, basicTabbables);
        return tabbableNodes;
    };
    KitFocusManagerService.prototype.isDescendant = function (parent, child) {
        if (child) {
            var node = child.parentNode;
            while (node !== null) {
                if (node === parent) {
                    return true;
                }
                node = node.parentNode;
            }
            return false;
        }
        else {
            return false;
        }
    };
    KitFocusManagerService.prototype.keydownHandler = function (event) {
        if (!this.onHold && event.keyCode === keyTab) {
            event.preventDefault();
            if (event.shiftKey) {
                this.focusPrev();
            }
            else {
                this.focusNext();
            }
        }
    };
    return KitFocusManagerService;
}());
KitFocusManagerService.decorators = [
    { type: Injectable },
];
KitFocusManagerService.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: NgZone, },
    { type: Renderer2, },
    { type: KitEventManagerService, },
    { type: KitFocusManagerRegistryService, },
]; };
var KitFocusTrapDirective = /** @class */ (function () {
    function KitFocusTrapDirective(service) {
        this.service = service;
        this.service.autoCapture = true;
    }
    KitFocusTrapDirective.prototype.ngOnInit = function () {
        this.service.init();
    };
    return KitFocusTrapDirective;
}());
KitFocusTrapDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFocusTrap]',
                providers: [
                    KitFocusManagerService,
                ],
            },] },
];
KitFocusTrapDirective.ctorParameters = function () { return [
    { type: KitFocusManagerService, },
]; };
var KitFocusDirective = /** @class */ (function () {
    function KitFocusDirective(service, el) {
        this.service = service;
        this.el = el;
        if (this.service) {
            this.service.add(this);
        }
    }
    KitFocusDirective.prototype.ngOnDestroy = function () {
        if (this.service) {
            this.service.remove(this);
        }
    };
    KitFocusDirective.prototype.focus = function () {
        this.el.nativeElement.focus();
    };
    return KitFocusDirective;
}());
KitFocusDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFocus]',
            },] },
];
KitFocusDirective.ctorParameters = function () { return [
    { type: KitFocusManagerService, decorators: [{ type: Optional },] },
    { type: ElementRef, },
]; };
KitFocusDirective.propDecorators = {
    "kitFocus": [{ type: Input },],
};
var KitFocusManagerModule = /** @class */ (function () {
    function KitFocusManagerModule() {
    }
    return KitFocusManagerModule;
}());
KitFocusManagerModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitFocusDirective,
                    KitFocusTrapDirective,
                ],
                exports: [
                    KitFocusDirective,
                    KitFocusTrapDirective,
                ],
            },] },
];
var KitFormErrorDirective = /** @class */ (function () {
    function KitFormErrorDirective(templateRef) {
        this.templateRef = templateRef;
    }
    Object.defineProperty(KitFormErrorDirective.prototype, "name", {
        get: function () {
            return this.kitFormError;
        },
        enumerable: true,
        configurable: true
    });
    return KitFormErrorDirective;
}());
KitFormErrorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFormError]',
            },] },
];
KitFormErrorDirective.ctorParameters = function () { return [
    { type: TemplateRef, },
]; };
KitFormErrorDirective.propDecorators = {
    "kitFormError": [{ type: Input },],
};
function isUndefined(x) {
    return x === undefined || x === null;
}
var KitFormFieldService = /** @class */ (function () {
    function KitFormFieldService() {
        this._controls = [];
    }
    Object.defineProperty(KitFormFieldService.prototype, "control", {
        get: function () {
            return this._controls[0];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitFormFieldService.prototype, "controls", {
        get: function () {
            return this._controls;
        },
        enumerable: true,
        configurable: true
    });
    KitFormFieldService.prototype.add = function (control) {
        this._controls.push(control);
    };
    KitFormFieldService.prototype.remove = function (control) {
        var index = this._controls.indexOf(control);
        if (index !== -1) {
            this._controls.splice(index, 1);
        }
    };
    KitFormFieldService.prototype.hasError = function (name) {
        return !!this._controls.find(function (c) { return c.ngControl.hasError(name); });
    };
    KitFormFieldService.prototype.getErrorsToDisplay = function () {
        var errors = [];
        this._controls.forEach(function (control) {
            var hasErrors = control.ngControl.invalid && control.ngControl.touched;
            if (hasErrors) {
                errors = __spread(errors, Object.keys(control.ngControl.errors || {}));
            }
        });
        return errors;
    };
    KitFormFieldService.prototype.isRequired = function () {
        return this.control && !(isUndefined(this.control.required) || this.control.required === false);
    };
    return KitFormFieldService;
}());
KitFormFieldService.decorators = [
    { type: Injectable },
];
var KitNgControlDirective = /** @class */ (function () {
    function KitNgControlDirective(ngControl, formFieldService, differs) {
        this.ngControl = ngControl;
        this.formFieldService = formFieldService;
        this.differs = differs;
        this._id = uuid();
        this._errorStateChanges = new Subject();
        if (this.ngControl && this.formFieldService) {
            this.formFieldService.add(this);
        }
    }
    Object.defineProperty(KitNgControlDirective.prototype, "idBinding", {
        get: function () {
            return this._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitNgControlDirective.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (id) {
            this._id = id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitNgControlDirective.prototype, "errorStateChanges", {
        get: function () {
            return this._errorStateChanges.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    KitNgControlDirective.prototype.ngOnDestroy = function () {
        if (this.formFieldService) {
            this.formFieldService.remove(this);
        }
    };
    KitNgControlDirective.prototype.ngDoCheck = function () {
        if (this.formFieldService) {
            var errors = this.formFieldService.getErrorsToDisplay();
            if (errors && !this.errorsDiffer) {
                this.errorsDiffer = this.differs.find(errors).create();
                this._errorStateChanges.next(errors);
            }
            if (this.errorsDiffer) {
                var diff = this.errorsDiffer.diff(errors);
                if (diff) {
                    this._errorStateChanges.next(errors);
                }
            }
        }
    };
    return KitNgControlDirective;
}());
KitNgControlDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ngModel],[formControl],[formControlName]',
            },] },
];
KitNgControlDirective.ctorParameters = function () { return [
    { type: NgControl, decorators: [{ type: Host }, { type: Optional },] },
    { type: KitFormFieldService, decorators: [{ type: Optional },] },
    { type: IterableDiffers, },
]; };
KitNgControlDirective.propDecorators = {
    "required": [{ type: Input },],
    "idBinding": [{ type: HostBinding, args: ['attr.id',] },],
    "id": [{ type: Input },],
};
var KitFormFieldModule = /** @class */ (function () {
    function KitFormFieldModule() {
    }
    return KitFormFieldModule;
}());
KitFormFieldModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitFormErrorDirective,
                    KitNgControlDirective,
                ],
                exports: [
                    KitFormErrorDirective,
                    KitNgControlDirective,
                ],
                providers: [],
            },] },
];
var KitFormTouchDirective = /** @class */ (function () {
    function KitFormTouchDirective(container) {
        this.container = container;
    }
    KitFormTouchDirective.prototype.clickHandler = function () {
        if (this.container) {
            this.formTouchAll(((this.container.formDirective)).form);
        }
        else {
            throw new Error('Use kitFormTouch inside NgForm or FormGroup');
        }
    };
    KitFormTouchDirective.prototype.formTouchAll = function (form, revalidate) {
        form.markAsTouched();
        for (var i in form.controls) {
            if (form.controls.hasOwnProperty(i)) {
                var control = form.controls[i];
                if (control) {
                    control.markAsTouched();
                    if (control instanceof FormGroup) {
                        this.formTouchAll(control);
                    }
                    else if (revalidate) {
                        control.setValue(control.value);
                    }
                }
            }
        }
    };
    return KitFormTouchDirective;
}());
KitFormTouchDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitFormTouch]',
            },] },
];
KitFormTouchDirective.ctorParameters = function () { return [
    { type: ControlContainer, decorators: [{ type: Optional },] },
]; };
KitFormTouchDirective.propDecorators = {
    "clickHandler": [{ type: HostListener, args: ['click',] },],
};
var KitFormTouchModule = /** @class */ (function () {
    function KitFormTouchModule() {
    }
    return KitFormTouchModule;
}());
KitFormTouchModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitFormTouchDirective,
                ],
                exports: [
                    KitFormTouchDirective,
                ],
                providers: [],
            },] },
];
var KitHammerProvider = /** @class */ (function () {
    function KitHammerProvider(platform) {
        this.platform = platform;
        this._hammer = null;
        if (this.platform.isBrowser()) {
            if (window && 'Hammer' in window) {
                this._hammer = ((window))['Hammer'];
            }
        }
    }
    Object.defineProperty(KitHammerProvider.prototype, "hammer", {
        get: function () {
            return this._hammer;
        },
        enumerable: true,
        configurable: true
    });
    KitHammerProvider.prototype.calcRelatedPosition = function (el, center) {
        var rect = el.getBoundingClientRect();
        return {
            x: center.x - rect.left,
            y: center.y - rect.top,
        };
    };
    return KitHammerProvider;
}());
KitHammerProvider.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitHammerProvider.ctorParameters = function () { return [
    { type: KitPlatformService, },
]; };
KitHammerProvider.ngInjectableDef = defineInjectable({ factory: function KitHammerProvider_Factory() { return new KitHammerProvider(inject(KitPlatformService)); }, token: KitHammerProvider, providedIn: "root" });
var KitHammerTypes;
(function (KitHammerTypes) {
    KitHammerTypes.INPUT_TYPE_TOUCH = 'touch';
    KitHammerTypes.INPUT_TYPE_PEN = 'pen';
    KitHammerTypes.INPUT_TYPE_MOUSE = 'mouse';
    KitHammerTypes.INPUT_TYPE_KINECT = 'kinect';
    KitHammerTypes.COMPUTE_INTERVAL = 25;
    KitHammerTypes.INPUT_START = 1;
    KitHammerTypes.INPUT_MOVE = 2;
    KitHammerTypes.INPUT_END = 4;
    KitHammerTypes.INPUT_CANCEL = 8;
    KitHammerTypes.DIRECTION_NONE = 1;
    KitHammerTypes.DIRECTION_LEFT = 2;
    KitHammerTypes.DIRECTION_RIGHT = 4;
    KitHammerTypes.DIRECTION_UP = 8;
    KitHammerTypes.DIRECTION_DOWN = 16;
    KitHammerTypes.DIRECTION_HORIZONTAL = KitHammerTypes.DIRECTION_LEFT | KitHammerTypes.DIRECTION_RIGHT;
    KitHammerTypes.DIRECTION_VERTICAL = KitHammerTypes.DIRECTION_UP | KitHammerTypes.DIRECTION_DOWN;
    KitHammerTypes.DIRECTION_ALL = KitHammerTypes.DIRECTION_HORIZONTAL | KitHammerTypes.DIRECTION_VERTICAL;
})(KitHammerTypes || (KitHammerTypes = {}));
var KitIntersectionService = /** @class */ (function () {
    function KitIntersectionService(elementRef, platform) {
        this.elementRef = elementRef;
        this.platform = platform;
        this.observer = new BehaviorSubject(false);
    }
    Object.defineProperty(KitIntersectionService.prototype, "isIntersecting", {
        get: function () {
            return this.observer.value;
        },
        enumerable: true,
        configurable: true
    });
    KitIntersectionService.prototype.ngOnDestroy = function () {
        if (this.io) {
            this.io.disconnect();
        }
    };
    KitIntersectionService.prototype.observe = function () {
        if (this.platform.isBrowser() && 'IntersectionObserver' in window) {
            if (!this.io) {
                this.initObserver();
            }
            return this.observer.asObservable();
        }
        else {
            return from([null]);
        }
    };
    KitIntersectionService.prototype.initObserver = function () {
        var _this = this;
        this.io = new IntersectionObserver(function (data) {
            _this.observer.next(data && data[0] && data[0].isIntersecting);
        });
        this.io.observe(this.elementRef.nativeElement);
    };
    return KitIntersectionService;
}());
KitIntersectionService.decorators = [
    { type: Injectable },
];
KitIntersectionService.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: KitPlatformService, },
]; };
var isArray = Array.isArray || (function (x) { return x && typeof x.length === 'number'; });
var KitIconsRegistryService = /** @class */ (function () {
    function KitIconsRegistryService(http) {
        this.http = http;
        this.cache = [];
        this.icons = [];
    }
    KitIconsRegistryService.prototype.add = function (icon) {
        var icons = isArray(icon) ? icon : [icon];
        icons.forEach(function (i) {
            if (!i.url && !i.xml) {
                throw new Error('KitIconsRegistryService: icon registration requires url or xml.');
            }
        });
        this.icons = __spread(this.icons, icons);
    };
    KitIconsRegistryService.prototype.get = function (name) {
        var icon = this.icons.find(function (i) { return i.name === name; });
        if (icon) {
            var fromCache = this.cache.find(function (c) { return c.name === name; });
            var cached_1 = fromCache
                ? fromCache
                : {
                    name: name,
                    svg: new BehaviorSubject(null),
                };
            if (!fromCache) {
                this.cache.push(cached_1);
                if (icon.url) {
                    return this.http.get(icon.url, { responseType: 'text' })
                        .pipe(tap(function (svg) { return cached_1.svg.next(svg); }), map(function (svg) { return ({ svg: svg, size: icon.size }); }));
                }
                else if (icon.xml) {
                    cached_1.svg.next(icon.xml);
                }
            }
            return cached_1.svg
                .asObservable()
                .pipe(filter(function (svg) { return svg !== null; }), take(1), map(function (svg) { return ({ svg: svg, size: icon.size }); }));
        }
        else {
            throw new Error("Icon \"" + name + "\" not found!");
        }
    };
    return KitIconsRegistryService;
}());
KitIconsRegistryService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitIconsRegistryService.ctorParameters = function () { return [
    { type: HttpClient, },
]; };
KitIconsRegistryService.ngInjectableDef = defineInjectable({ factory: function KitIconsRegistryService_Factory() { return new KitIconsRegistryService(inject(HttpClient)); }, token: KitIconsRegistryService, providedIn: "root" });
var KitIconComponent = /** @class */ (function () {
    function KitIconComponent(registry, el, renderer, platform, intersection) {
        var _this = this;
        this.registry = registry;
        this.el = el;
        this.renderer = renderer;
        this.platform = platform;
        this.intersection = intersection;
        this.color = 'currentcolor';
        this.intersectionLoad = false;
        this.nameChanges = new Subject();
        this.destroy = new Subject();
        this.nameChanges
            .pipe(takeUntil(this.destroy), switchMap(function (name) {
            return _this.intersectionLoad
                ? _this.intersection.observe().pipe(filter(Boolean), take(1), mapTo(name))
                : from([name]);
        }), switchMap(function (name) { return _this.registry.get(name); }))
            .subscribe(function (source) {
            _this.source = source;
            _this.svg = _this.svgElementFromString(_this.source.svg);
            _this.clear();
            _this.updateStyles();
            _this.updateA11y();
            _this.mount();
        });
    }
    KitIconComponent.prototype.ngOnChanges = function (changes) {
        if ('name' in changes) {
            this.nameChanges.next(this.name);
        }
        if ('size' in changes || 'color' in changes) {
            this.updateStyles();
        }
        if ('title' in changes || 'desc' in changes) {
            this.updateA11y();
        }
    };
    KitIconComponent.prototype.ngOnDestroy = function () {
        this.destroy.next();
    };
    KitIconComponent.prototype.clear = function () {
        if (this.platform.isBrowser()) {
            var el = this.el.nativeElement;
            while (el.hasChildNodes() && el.lastChild) {
                el.removeChild(el.lastChild);
            }
        }
        this.titleEl = null;
        this.descEl = null;
    };
    KitIconComponent.prototype.updateStyles = function () {
        if (this.source && this.svg) {
            var height = void 0;
            var width = void 0;
            var position = void 0;
            var top = void 0;
            var size = this.size || this.source.size;
            if (size) {
                if (isArray(size)) {
                    height = size[0];
                    width = size[1];
                }
                else {
                    height = size;
                    width = size;
                }
            }
            else {
                height = '1em';
                width = '1em';
            }
            if (height === '1em') {
                position = 'relative';
                top = '.125em';
            }
            else {
                position = 'static';
                top = 'auto';
            }
            this.renderer.setStyle(this.svg, 'fill', this.color);
            this.renderer.setStyle(this.svg, 'height', height);
            this.renderer.setStyle(this.svg, 'position', position);
            this.renderer.setStyle(this.svg, 'top', top);
            this.renderer.setStyle(this.svg, 'width', width);
        }
    };
    KitIconComponent.prototype.svgElementFromString = function (str) {
        var div = this.renderer.createElement('div');
        div.innerHTML = str;
        var svg = (div.querySelector('svg'));
        if (svg) {
            return svg;
        }
        else {
            throw new Error("SVG has not been rendered from \"" + str + "\"");
        }
    };
    KitIconComponent.prototype.updateA11y = function () {
        if (this.source && this.svg) {
            this.renderer.setAttribute(this.svg, 'role', 'img');
            if (this.title) {
                if (!this.titleEl) {
                    this.titleEl = this.renderer.createElement('title');
                    var titleId = uuid();
                    this.renderer.setAttribute(this.titleEl, 'id', titleId);
                    this.renderer.insertBefore(this.svg, this.titleEl, this.svg.childNodes[0]);
                }
                this.titleEl.innerHTML = this.title;
            }
            if (this.desc) {
                if (!this.descEl) {
                    this.descEl = this.renderer.createElement('desc');
                    var descId = uuid();
                    this.renderer.setAttribute(this.descEl, 'id', descId);
                    this.renderer.appendChild(this.svg, this.descEl);
                }
                this.descEl.innerHTML = this.desc;
            }
            this.renderer.setAttribute(this.svg, 'aria-labelledby', (this.titleEl ? this.titleEl.id : '') + " " + (this.descEl ? this.descEl.id : ''));
        }
    };
    KitIconComponent.prototype.mount = function () {
        this.renderer.appendChild(this.el.nativeElement, this.svg);
    };
    return KitIconComponent;
}());
KitIconComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-icon',
                template: "\n    <ng-content></ng-content>\n  ",
                styles: ["\n    :host {\n      display: inline-flex;\n      align-self: center;\n    }\n  "],
                providers: [
                    KitIntersectionService,
                ],
                changeDetection: ChangeDetectionStrategy.OnPush,
            },] },
];
KitIconComponent.ctorParameters = function () { return [
    { type: KitIconsRegistryService, },
    { type: ElementRef, },
    { type: Renderer2, },
    { type: KitPlatformService, },
    { type: KitIntersectionService, },
]; };
KitIconComponent.propDecorators = {
    "color": [{ type: Input },],
    "name": [{ type: Input },],
    "size": [{ type: Input },],
    "title": [{ type: Input },],
    "desc": [{ type: Input },],
    "intersectionLoad": [{ type: Input },],
};
var KitIconsModule = /** @class */ (function () {
    function KitIconsModule() {
    }
    return KitIconsModule;
}());
KitIconsModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    HttpClientModule,
                ],
                exports: [
                    KitIconComponent,
                ],
                declarations: [
                    KitIconComponent,
                ],
            },] },
];
var KitMomentProvider = /** @class */ (function () {
    function KitMomentProvider(platform) {
        this.platform = platform;
        this._moment = null;
        if (this.platform.isBrowser()) {
            if (window && 'moment' in window) {
                this._moment = ((window))['moment'];
            }
        }
    }
    Object.defineProperty(KitMomentProvider.prototype, "moment", {
        get: function () {
            return this._moment;
        },
        enumerable: true,
        configurable: true
    });
    return KitMomentProvider;
}());
KitMomentProvider.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitMomentProvider.ctorParameters = function () { return [
    { type: KitPlatformService, },
]; };
KitMomentProvider.ngInjectableDef = defineInjectable({ factory: function KitMomentProvider_Factory() { return new KitMomentProvider(inject(KitPlatformService)); }, token: KitMomentProvider, providedIn: "root" });
var KitModelInterceptor = /** @class */ (function () {
    function KitModelInterceptor() {
    }
    return KitModelInterceptor;
}());
KitModelInterceptor.decorators = [
    { type: Injectable },
];
var KitInputDateDirective = /** @class */ (function () {
    function KitInputDateDirective(momentProvider) {
        this.momentProvider = momentProvider;
        this.options = {};
        this.viewStateChanges = new Subject();
        this.modelStateChanges = new Subject();
        this.moment = null;
        this.moment = this.momentProvider.moment;
    }
    KitInputDateDirective.prototype.ngOnChanges = function () {
        if (this.format && !this.moment) {
            throw new Error('KitInputDateDirective: Format option requires moment.js!\n' +
                '==========\n' +
                'Possible solution:\n' +
                '  1. Install moment: npm install moment\n' +
                '  2. Add "node_modules/moment/moment.js" to angular.json scripts section.\n' +
                '==========\n');
        }
    };
    KitInputDateDirective.prototype.input = function (value, event) {
        var date = this.parse(value);
        this.modelStateChanges.next(this.isValid(date) ? date : null);
    };
    KitInputDateDirective.prototype.keyDown = function (event) {
    };
    KitInputDateDirective.prototype.writeValue = function (value) {
        var date = this.parse(value);
        this.viewStateChanges.next(this.isValid(date)
            ? this.moment && this.format ? this.moment(date).format(this.format) : date.toDateString()
            : '');
    };
    KitInputDateDirective.prototype.parse = function (raw) {
        return this.moment && this.format
            ? this.moment(raw, this.format).toDate()
            : new Date(Date.parse(raw));
    };
    KitInputDateDirective.prototype.isValid = function (raw) {
        var date = new Date(raw);
        return !isNaN(date.getTime());
    };
    return KitInputDateDirective;
}());
KitInputDateDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitInputDate]',
                providers: [
                    {
                        provide: KitModelInterceptor,
                        useExisting: forwardRef(function () { return KitInputDateDirective; }),
                    },
                ],
            },] },
];
KitInputDateDirective.ctorParameters = function () { return [
    { type: KitMomentProvider, },
]; };
KitInputDateDirective.propDecorators = {
    "kitInputDate": [{ type: Input },],
    "options": [{ type: Input },],
    "format": [{ type: Input },],
};
var KitDefaultModelInterceptor = /** @class */ (function () {
    function KitDefaultModelInterceptor() {
        this.viewStateChanges = new Subject();
        this.modelStateChanges = new Subject();
    }
    KitDefaultModelInterceptor.prototype.input = function (value, event) {
        this.modelStateChanges.next(value);
    };
    KitDefaultModelInterceptor.prototype.keyDown = function (event) {
    };
    KitDefaultModelInterceptor.prototype.writeValue = function (value) {
        this.viewStateChanges.next(value);
    };
    return KitDefaultModelInterceptor;
}());
KitDefaultModelInterceptor.decorators = [
    { type: Injectable },
];
var KitValueAccessorDirective = /** @class */ (function () {
    function KitValueAccessorDirective(renderer, el, injInterceptor, defaultInterceptor) {
        var _this = this;
        this.renderer = renderer;
        this.el = el;
        this.injInterceptor = injInterceptor;
        this.defaultInterceptor = defaultInterceptor;
        this.changes$ = new Subject();
        this.touches$ = new Subject();
        this.interceptor = this.injInterceptor || this.defaultInterceptor;
        this.interceptor.modelStateChanges.subscribe(this.changes$);
        this.interceptor.viewStateChanges.subscribe(function (value) {
            _this.renderer.setProperty(_this.el.nativeElement, 'value', value || '');
        });
    }
    KitValueAccessorDirective.prototype.inputHandler = function (event) {
        this.interceptor.input(event.target.value, event);
    };
    KitValueAccessorDirective.prototype.keydownHandler = function (event) {
        this.interceptor.keyDown(event);
    };
    KitValueAccessorDirective.prototype.blurHandler = function (event) {
        this.touches$.next();
    };
    KitValueAccessorDirective.prototype.registerOnChange = function (fn) {
        this.changes$.subscribe(fn);
    };
    KitValueAccessorDirective.prototype.registerOnTouched = function (fn) {
        this.touches$.subscribe(fn);
    };
    KitValueAccessorDirective.prototype.setDisabledState = function (isDisabled) {
        this.renderer.setProperty(this.el.nativeElement, 'disabled', isDisabled);
    };
    KitValueAccessorDirective.prototype.writeValue = function (rawValue) {
        this.interceptor.writeValue(rawValue);
    };
    return KitValueAccessorDirective;
}());
KitValueAccessorDirective.decorators = [
    { type: Directive, args: [{
                selector: "\n    input:not([type=checkbox]):not([type=radio])[formControlName],\n    textarea[formControlName],\n    input:not([type=checkbox]):not([type=radio])[formControl],\n    textarea[formControl],\n    input:not([type=checkbox]):not([type=radio])[ngModel],\n    textarea[ngModel],\n    [ngDefaultControl]\n  ",
                providers: [
                    KitDefaultModelInterceptor,
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(function () { return KitValueAccessorDirective; }),
                        multi: true,
                    },
                ],
            },] },
];
KitValueAccessorDirective.ctorParameters = function () { return [
    { type: Renderer2, },
    { type: ElementRef, },
    { type: KitModelInterceptor, decorators: [{ type: Inject, args: [KitModelInterceptor,] }, { type: Optional },] },
    { type: KitDefaultModelInterceptor, },
]; };
KitValueAccessorDirective.propDecorators = {
    "inputHandler": [{ type: HostListener, args: ['input', ['$event'],] },],
    "keydownHandler": [{ type: HostListener, args: ['keydown', ['$event'],] },],
    "blurHandler": [{ type: HostListener, args: ['blur', ['$event'],] },],
};
var KitValueAccessorModule = /** @class */ (function () {
    function KitValueAccessorModule() {
    }
    return KitValueAccessorModule;
}());
KitValueAccessorModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitValueAccessorDirective,
                ],
                exports: [
                    KitValueAccessorDirective,
                ],
            },] },
];
var KitInputDateModule = /** @class */ (function () {
    function KitInputDateModule() {
    }
    return KitInputDateModule;
}());
KitInputDateModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitValueAccessorModule,
                    KitInputDateDirective,
                ],
                declarations: [
                    KitInputDateDirective,
                ],
            },] },
];
var KitIntersectionDirective = /** @class */ (function () {
    function KitIntersectionDirective(intersection) {
        this.intersection = intersection;
        this.kitIntersection = new EventEmitter();
    }
    KitIntersectionDirective.prototype.ngOnInit = function () {
        var _this = this;
        this.intersection.observe().subscribe(function (isIntersecting) {
            _this.kitIntersection.emit(!!isIntersecting);
        });
    };
    return KitIntersectionDirective;
}());
KitIntersectionDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitIntersection]',
                providers: [
                    KitIntersectionService,
                ],
            },] },
];
KitIntersectionDirective.ctorParameters = function () { return [
    { type: KitIntersectionService, },
]; };
KitIntersectionDirective.propDecorators = {
    "kitIntersection": [{ type: Output },],
};
var KitIntersectionModule = /** @class */ (function () {
    function KitIntersectionModule() {
    }
    return KitIntersectionModule;
}());
KitIntersectionModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    KitIntersectionDirective,
                ],
                exports: [
                    KitIntersectionDirective,
                ],
            },] },
];
var kitLoadingGlobal = 'global';
var KitLoadingState = {
    InProgress: 'in-progress',
    None: 'none',
};
var KitLoadingProgress = /** @class */ (function () {
    function KitLoadingProgress(id) {
        this.id = id;
        this.current = new Set();
        this._state = KitLoadingState.None;
        this._stateChanges = new Subject();
    }
    Object.defineProperty(KitLoadingProgress.prototype, "state", {
        get: function () {
            return this._state;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitLoadingProgress.prototype, "stateChanges", {
        get: function () {
            return this._stateChanges.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    KitLoadingProgress.prototype.start = function (key) {
        var _this = this;
        this.current.add(key || uuid());
        this.checkState();
        return function () {
            _this.end(key);
        };
    };
    KitLoadingProgress.prototype.end = function (key) {
        if (key) {
            this.current.delete(key);
        }
        else {
            this.current.clear();
        }
        this.checkState();
    };
    KitLoadingProgress.prototype.checkState = function () {
        if (this.current.size > 0 && this._state === KitLoadingState.None) {
            this.setState(KitLoadingState.InProgress);
        }
        if (this.current.size === 0 && this._state === KitLoadingState.InProgress) {
            this.setState(KitLoadingState.None);
        }
    };
    KitLoadingProgress.prototype.setState = function (state) {
        this._state = state;
        this._stateChanges.next(this._state);
    };
    return KitLoadingProgress;
}());
var KitLoadingService = /** @class */ (function () {
    function KitLoadingService(router) {
        this.router = router;
        this.progresses = new Map();
        var globalProgress = this.progress(kitLoadingGlobal);
        this.router.events.subscribe(function (event) {
            if (event instanceof NavigationStart) {
                globalProgress.start('routing');
            }
            if (event instanceof NavigationEnd) {
                globalProgress.end('routing');
            }
        });
    }
    Object.defineProperty(KitLoadingService.prototype, "global", {
        get: function () {
            return this.progress(kitLoadingGlobal);
        },
        enumerable: true,
        configurable: true
    });
    KitLoadingService.prototype.progress = function (id) {
        if (this.progresses.has(id)) {
            return (this.progresses.get(id));
        }
        else {
            var progress = new KitLoadingProgress(id);
            this.progresses.set(id, progress);
            return progress;
        }
    };
    return KitLoadingService;
}());
KitLoadingService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitLoadingService.ctorParameters = function () { return [
    { type: Router, },
]; };
KitLoadingService.ngInjectableDef = defineInjectable({ factory: function KitLoadingService_Factory() { return new KitLoadingService(inject(Router)); }, token: KitLoadingService, providedIn: "root" });
var kitMqBreakpoints = new InjectionToken('kitMqPoints');
var breakpointsError = 'Provide breakpoints for KitMqService:\n' +
    'providers: [\n' +
    '  {\n' +
    '    provide: kitMqBreakpoints,\n' +
    '    useValue: {\n' +
    '      mobile: \'320px\',\n' +
    '      tablet: \'740px\',\n' +
    '      desktop: \'980px\',\n' +
    '      wide: \'1300px\',\n' +
    '    }\n' +
    '  }\n' +
    ']';
var KitMqService = /** @class */ (function () {
    function KitMqService(platform, breakpoints) {
        this.platform = platform;
        this.breakpoints = breakpoints;
        this.mqs = new Map();
        if (!this.breakpoints) {
            throw new Error(breakpointsError);
        }
        if (this.platform.isBrowser() && 'matchMedia' in window) {
            this.matchMedia = window.matchMedia.bind(window);
        }
    }
    KitMqService.prototype.check = function (params) {
        return this.checkRaw(this.buildQuery(params));
    };
    KitMqService.prototype.checkRaw = function (mediaQuery) {
        if (this.matchMedia) {
            var mq = this.getMq(mediaQuery);
            return mq.matches;
        }
        else {
            return null;
        }
    };
    KitMqService.prototype.observe = function (params) {
        return this.observeRaw(this.buildQuery(params));
    };
    KitMqService.prototype.observeRaw = function (mediaQuery) {
        var _this = this;
        return new Observable(function (observer) {
            if (_this.matchMedia) {
                var listener = function (mql) {
                    observer.next(mql.matches);
                };
                var mq = _this.getMq(mediaQuery);
                observer.next(mq.matches);
                mq.addListener(listener);
            }
            else {
                observer.next(null);
                observer.complete();
            }
        });
    };
    KitMqService.prototype.buildQuery = function (params) {
        if (!params.from && !params.until) {
            throw new Error("KitMqService: invalid mq params");
        }
        var query = '';
        if (params.type) {
            query = "" + params.type;
        }
        if (params.from) {
            if (!this.breakpoints[params.from]) {
                throw new Error("KitMqService: breakpoint \"" + params.from + "\" has not been registered!");
            }
            query = this.concatQuery(query, "(min-width: " + this.breakpoints[params.from] + ")");
        }
        if (params.until) {
            if (!this.breakpoints[params.until]) {
                throw new Error("KitMqService: breakpoint \"" + params.until + "\" has not been registered!");
            }
            query = this.concatQuery(query, "(max-width: " + this.breakpoints[params.until] + ")");
        }
        if (params.and) {
            query = this.concatQuery(query, params.and);
        }
        return query;
    };
    KitMqService.prototype.concatQuery = function (query, attach) {
        return query && query.length > 0 ? query + " and " + attach : attach;
    };
    KitMqService.prototype.getMq = function (query) {
        var mq = this.mqs.get(query);
        if (!mq) {
            mq = this.matchMedia(query);
            this.mqs.set(query, mq);
        }
        return mq;
    };
    return KitMqService;
}());
KitMqService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitMqService.ctorParameters = function () { return [
    { type: KitPlatformService, },
    { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [kitMqBreakpoints,] },] },
]; };
KitMqService.ngInjectableDef = defineInjectable({ factory: function KitMqService_Factory() { return new KitMqService(inject(KitPlatformService), inject(kitMqBreakpoints, 8)); }, token: KitMqService, providedIn: "root" });
var KitMqDirective = /** @class */ (function () {
    function KitMqDirective(templateRef, cdr, vcr, mq) {
        this.templateRef = templateRef;
        this.cdr = cdr;
        this.vcr = vcr;
        this.mq = mq;
    }
    Object.defineProperty(KitMqDirective.prototype, "viewRef", {
        get: function () {
            return this._viewRef;
        },
        enumerable: true,
        configurable: true
    });
    KitMqDirective.prototype.ngOnChanges = function (changes) {
        var _this = this;
        if (changes['kitMq']) {
            if (this.subscription) {
                this.subscription.unsubscribe();
            }
            this.subscription = this.mq.observe(this.kitMq)
                .subscribe(function (matches) {
                _this.updateHost(!!matches);
                _this.cdr.detectChanges();
            });
        }
    };
    KitMqDirective.prototype.ngOnDestroy = function () {
        this.subscription.unsubscribe();
        this.destroyView();
    };
    KitMqDirective.prototype.updateHost = function (matches) {
        if (matches && !this._viewRef) {
            this._viewRef = this.vcr.createEmbeddedView(this.templateRef);
        }
        else if (!matches) {
            this.destroyView();
        }
    };
    KitMqDirective.prototype.destroyView = function () {
        if (this._viewRef) {
            this._viewRef.destroy();
            this._viewRef = null;
        }
    };
    return KitMqDirective;
}());
KitMqDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitMq]',
            },] },
];
KitMqDirective.ctorParameters = function () { return [
    { type: TemplateRef, },
    { type: ChangeDetectorRef, },
    { type: ViewContainerRef, },
    { type: KitMqService, },
]; };
KitMqDirective.propDecorators = {
    "kitMq": [{ type: Input },],
};
var KitMqModule = /** @class */ (function () {
    function KitMqModule() {
    }
    return KitMqModule;
}());
KitMqModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    KitMqDirective,
                ],
                exports: [
                    KitMqDirective,
                ],
            },] },
];
var KitModalBackdropComponent = /** @class */ (function () {
    function KitModalBackdropComponent(cdr) {
        this.cdr = cdr;
        this.close = new EventEmitter();
        this._display = false;
    }
    Object.defineProperty(KitModalBackdropComponent.prototype, "display", {
        get: function () {
            return this._display;
        },
        set: function (display) {
            if (display !== this._display) {
                this._display = display;
                this.cdr.detectChanges();
            }
        },
        enumerable: true,
        configurable: true
    });
    return KitModalBackdropComponent;
}());
KitModalBackdropComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-modal-backdrop',
                template: "\n    <div *ngIf=\"display\"\n         class=\"backdrop\"\n         [@fade]=\"true\"\n         (click)=\"close.emit()\">\n    </div>\n  ",
                styles: ["\n    .backdrop {\n      background: rgba(0, 0, 0, .4);\n      position: fixed;\n      top: 0;\n      right: 0;\n      bottom: 0;\n      left: 0;\n    }\n  "],
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('fade', [
                        transition(':enter', [
                            style({
                                opacity: 0,
                            }),
                            animate('150ms ease-out', style({
                                opacity: 1,
                            })),
                        ]),
                        transition(':leave', [
                            style({ opacity: 1 }),
                            animate('150ms ease-in', style({
                                opacity: 0,
                            })),
                        ]),
                    ]),
                ],
            },] },
];
KitModalBackdropComponent.ctorParameters = function () { return [
    { type: ChangeDetectorRef, },
]; };
KitModalBackdropComponent.propDecorators = {
    "close": [{ type: Output },],
    "display": [{ type: Input },],
};
var KitOverlayComponentRef = /** @class */ (function () {
    function KitOverlayComponentRef() {
    }
    KitOverlayComponentRef.prototype.input = function (input) {
        if (this.componentRef && this.componentRef.instance) {
            var changes = {};
            for (var name in input) {
                if (input.hasOwnProperty(name)) {
                    var prev = this.componentRef.instance[name];
                    this.componentRef.instance[name] = input[name];
                    changes[name] = new SimpleChange(prev, input[name], false);
                }
            }
            if (this.componentRef.instance['ngOnChanges']) {
                this.componentRef.instance['ngOnChanges'](changes);
            }
            this.componentRef.changeDetectorRef.detectChanges();
            this.componentRef.injector.get((ChangeDetectorRef)).detectChanges();
        }
        else {
            throw new Error('Modal initiated without instance. Input could be passed programmatically only for ' +
                'service-hosted modals.');
        }
    };
    return KitOverlayComponentRef;
}());
KitOverlayComponentRef.decorators = [
    { type: Injectable },
];
var KitOverlayHostWrapperComponent = /** @class */ (function () {
    function KitOverlayHostWrapperComponent(vcr) {
        this.vcr = vcr;
    }
    return KitOverlayHostWrapperComponent;
}());
KitOverlayHostWrapperComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-overlay-host-wrapper',
                template: '',
                changeDetection: ChangeDetectionStrategy.OnPush,
            },] },
];
KitOverlayHostWrapperComponent.ctorParameters = function () { return [
    { type: ViewContainerRef, },
]; };
var KitOverlayHostComponent = /** @class */ (function () {
    function KitOverlayHostComponent(zone, vcr, cdr, elRef) {
        this.zone = zone;
        this.vcr = vcr;
        this.cdr = cdr;
        this.elRef = elRef;
    }
    return KitOverlayHostComponent;
}());
KitOverlayHostComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-overlay-host',
                template: '',
                changeDetection: ChangeDetectionStrategy.OnPush,
            },] },
];
KitOverlayHostComponent.ctorParameters = function () { return [
    { type: NgZone, },
    { type: ViewContainerRef, },
    { type: ChangeDetectorRef, },
    { type: ElementRef, },
]; };
var KitOverlayService = /** @class */ (function () {
    function KitOverlayService(document, cfr, injector, parent, platform) {
        this.document = document;
        this.cfr = cfr;
        this.injector = injector;
        this.parent = parent;
        this.platform = platform;
        this._onHostStable = new Subject();
        this.isRoot = !this.parent;
        if (this.isRoot) {
            this.mountHost();
        }
    }
    Object.defineProperty(KitOverlayService.prototype, "onHostStable", {
        get: function () {
            return this.isRoot
                ? this._onHostStable.asObservable()
                : this.parent.onHostStable;
        },
        enumerable: true,
        configurable: true
    });
    KitOverlayService.prototype.hostComponent = function (_a) {
        var component = _a.component, _b = _a.providers, providers = _b === void 0 ? [] : _b, componentFactoryResolver = _a.componentFactoryResolver, viewContainerRef = _a.viewContainerRef;
        if (this.isRoot) {
            var hostVcr = viewContainerRef || this.host.vcr;
            var injector = Injector.create({
                providers: providers,
                parent: hostVcr.injector,
            });
            var componentFactory = componentFactoryResolver
                ? componentFactoryResolver.resolveComponentFactory(component)
                : this.cfr.resolveComponentFactory(component);
            var ref_1 = new KitOverlayComponentRef();
            ref_1.componentRef = hostVcr.createComponent(componentFactory, hostVcr.length, injector);
            this.host.elRef.nativeElement.appendChild(this.getComponentRootNode(ref_1.componentRef));
            ref_1.componentRef.changeDetectorRef.detectChanges();
            var cdSub_1 = hostVcr.injector.get(NgZone).onStable
                .subscribe(function () {
                ref_1.componentRef.changeDetectorRef.detectChanges();
            });
            ref_1.componentRef.onDestroy(function () {
                cdSub_1.unsubscribe();
            });
            return ref_1;
        }
        else {
            return this.parent.hostComponent({ component: component, providers: providers, componentFactoryResolver: componentFactoryResolver, viewContainerRef: viewContainerRef });
        }
    };
    KitOverlayService.prototype.hostTemplate = function (_a) {
        var templateRef = _a.templateRef, _b = _a.context, context = _b === void 0 ? {} : _b, viewContainerRef = _a.viewContainerRef;
        if (this.isRoot) {
            var hostVcr = viewContainerRef || this.host.vcr;
            var ref = hostVcr.createEmbeddedView(templateRef, context);
            this.host.elRef.nativeElement.appendChild(this.getTemplateRootNode(ref));
            return ref;
        }
        else {
            return this.parent.hostTemplate({ templateRef: templateRef, context: context, viewContainerRef: viewContainerRef });
        }
    };
    KitOverlayService.prototype.moveUnder = function (ref, target) {
        if (this.isRoot) {
            this.getTemplateRootNode(this.hostRef.hostView)
                .insertBefore(this.getTemplateRootNode(ref), this.getTemplateRootNode(target));
        }
        else {
            this.parent.moveUnder(ref, target);
        }
    };
    KitOverlayService.prototype.getComponentRootNode = function (componentRef) {
        return this.getTemplateRootNode(componentRef.hostView);
    };
    KitOverlayService.prototype.getTemplateRootNode = function (viewRef) {
        return (((viewRef)).rootNodes[0]);
    };
    KitOverlayService.prototype.mountHost = function () {
        var _this = this;
        if (!this.isRoot) {
            throw new Error("Run .mountHost() only for root service");
        }
        this.container = this.document.createElement('div');
        if (this.platform.isBrowser()) {
            this.container.classList.add('kit-overlay-container');
            this.document.body.appendChild(this.container);
        }
        var hostWrapperFactory = this.cfr.resolveComponentFactory(KitOverlayHostWrapperComponent);
        this.hostWrapperRef = hostWrapperFactory.create(this.injector);
        this.container.appendChild(this.getComponentRootNode(this.hostWrapperRef));
        var hostFactory = this.cfr.resolveComponentFactory(KitOverlayHostComponent);
        var wrapperVcr = this.hostWrapperRef.instance.vcr;
        this.hostRef = wrapperVcr.createComponent(hostFactory, wrapperVcr.length, this.injector);
        this.host = this.hostRef.instance;
        this.container.appendChild(this.getComponentRootNode(this.hostRef));
        this.host.zone.onStable.subscribe(function () {
            _this._onHostStable.next();
        });
    };
    return KitOverlayService;
}());
KitOverlayService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitOverlayService.ctorParameters = function () { return [
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] },] },
    { type: ComponentFactoryResolver, },
    { type: Injector, },
    { type: KitOverlayService, decorators: [{ type: Optional }, { type: Inject, args: [forwardRef(function () { return KitOverlayService; }),] }, { type: SkipSelf },] },
    { type: KitPlatformService, },
]; };
KitOverlayService.ngInjectableDef = defineInjectable({ factory: function KitOverlayService_Factory() { return new KitOverlayService(inject(DOCUMENT), inject(ComponentFactoryResolver), inject(INJECTOR), inject(KitOverlayService, 12), inject(KitPlatformService)); }, token: KitOverlayService, providedIn: "root" });
var KitOverlayDirective = /** @class */ (function () {
    function KitOverlayDirective(templateRef, service, cdr, vcr) {
        this.templateRef = templateRef;
        this.service = service;
        this.cdr = cdr;
        this.vcr = vcr;
        this._displayed = new BehaviorSubject(false);
    }
    Object.defineProperty(KitOverlayDirective.prototype, "displayed", {
        get: function () {
            return this._displayed.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitOverlayDirective.prototype, "viewRef", {
        get: function () {
            return this._viewRef;
        },
        enumerable: true,
        configurable: true
    });
    KitOverlayDirective.prototype.ngOnChanges = function (changes) {
        if (changes['kitOverlay']) {
            this.updateHost();
        }
    };
    KitOverlayDirective.prototype.ngOnDestroy = function () {
        this.destroyView();
    };
    KitOverlayDirective.prototype.updateHost = function () {
        var _this = this;
        if (this.kitOverlay && !this._viewRef) {
            this._viewRef = this.service.hostTemplate({
                templateRef: this.templateRef,
                viewContainerRef: this.vcr,
            });
            this._viewRef.detectChanges();
            this.doCheckSub = this.service.onHostStable.subscribe(function () {
                if (!_this.cdr['destroyed']) {
                    _this.cdr.detectChanges();
                }
            });
            this._displayed.next(true);
        }
        else if (!this.kitOverlay) {
            this.destroyView();
            this._displayed.next(false);
        }
    };
    KitOverlayDirective.prototype.destroyView = function () {
        if (this._viewRef) {
            this._viewRef.destroy();
            this._viewRef = null;
        }
        if (this.doCheckSub) {
            this.doCheckSub.unsubscribe();
        }
    };
    return KitOverlayDirective;
}());
KitOverlayDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitOverlay]',
            },] },
];
KitOverlayDirective.ctorParameters = function () { return [
    { type: TemplateRef, },
    { type: KitOverlayService, },
    { type: ChangeDetectorRef, },
    { type: ViewContainerRef, },
]; };
KitOverlayDirective.propDecorators = {
    "kitOverlay": [{ type: Input },],
};
var KitModalRef = /** @class */ (function () {
    function KitModalRef() {
        this.id = uuid();
        this.onClose = new Subject();
        this.onDestroy = new Subject();
        this._options = {};
    }
    Object.defineProperty(KitModalRef.prototype, "options", {
        get: function () {
            return this._options;
        },
        set: function (options) {
            this._options = Object.assign({}, options);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitModalRef.prototype, "instance", {
        get: function () {
            if (this.componentRef) {
                return this.componentRef.componentRef.instance;
            }
            else {
                throw new Error('Modal initiated without instance.');
            }
        },
        enumerable: true,
        configurable: true
    });
    KitModalRef.prototype.applyParams = function (params) {
        this._options = Object.assign({}, this.options, params);
    };
    KitModalRef.prototype.close = function () {
        this.onClose.next();
    };
    KitModalRef.prototype.input = function (input) {
        if (this.componentRef) {
            this.componentRef.input(input);
        }
        else {
            throw new Error('Modal initiated without instance. Input could be passed programmatically only for ' +
                'service-hosted modals.');
        }
    };
    return KitModalRef;
}());
KitModalRef.decorators = [
    { type: Injectable },
];
var KitModalOptions = /** @class */ (function () {
    function KitModalOptions() {
        this.backdropClose = true;
        this.escClose = true;
        this.scrollLock = true;
    }
    return KitModalOptions;
}());
KitModalOptions.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitModalOptions.ngInjectableDef = defineInjectable({ factory: function KitModalOptions_Factory() { return new KitModalOptions(); }, token: KitModalOptions, providedIn: "root" });
var KitModalService = /** @class */ (function () {
    function KitModalService(overlay, em, options, document, platform, parent, cfr) {
        this.overlay = overlay;
        this.em = em;
        this.options = options;
        this.document = document;
        this.platform = platform;
        this.parent = parent;
        this.cfr = cfr;
        this.displayed = new Set();
        this.isRoot = !this.parent;
    }
    KitModalService.prototype.show = function (_a) {
        var component = _a.component, options = _a.options, componentFactoryResolver = _a.componentFactoryResolver, viewContainerRef = _a.viewContainerRef;
        if (this.isRoot) {
            this.initBackdrop();
            var ref_2 = new KitModalRef();
            var componentRef_1 = this.overlay
                .hostComponent({
                component: component,
                providers: [
                    {
                        provide: KitModalRef,
                        useValue: ref_2,
                    },
                ],
                componentFactoryResolver: componentFactoryResolver,
                viewContainerRef: viewContainerRef,
            });
            ref_2.options = Object.assign({}, this.options, options);
            ref_2.componentRef = componentRef_1;
            ref_2.viewRef = componentRef_1.componentRef.hostView;
            ref_2.onClose.subscribe(function () {
                if (!ref_2.instance['canClose'] || ref_2.instance['canClose']()) {
                    componentRef_1.componentRef.destroy();
                    ref_2.onDestroy.next();
                }
            });
            this.addRef(ref_2);
            return ref_2;
        }
        else {
            return this.parent.show({
                component: component,
                options: options,
                componentFactoryResolver: componentFactoryResolver || this.cfr,
                viewContainerRef: viewContainerRef,
            });
        }
    };
    KitModalService.prototype.addRef = function (ref) {
        var _this = this;
        if (this.isRoot) {
            this.initBackdrop();
            this.displayed.add(ref);
            ref.onDestroy.subscribe(function () {
                _this.displayed.delete(ref);
                _this.checkBackdrop();
            });
            this.checkBackdrop();
        }
        else {
            this.parent.addRef(ref);
        }
    };
    KitModalService.prototype.checkBackdrop = function () {
        this.backdropRef.input({ display: this.displayed.size > 0 });
        var top = this.getTopModalRef();
        if (top) {
            this.overlay.moveUnder(this.backdropRef.componentRef.hostView, top.viewRef);
        }
        if (this.platform.isBrowser() && this.document) {
            if (top && top.options.scrollLock) {
                this.document.body.style.overflow = 'hidden';
            }
            else {
                this.document.body.style.removeProperty('overflow');
            }
        }
    };
    KitModalService.prototype.backdropClickHandler = function () {
        var top = this.getTopModalRef();
        if (top && top.options.backdropClose) {
            top.onClose.next();
        }
    };
    KitModalService.prototype.escHandler = function () {
        var top = this.getTopModalRef();
        if (top && top.options.escClose) {
            top.onClose.next();
        }
    };
    KitModalService.prototype.getTopModalRef = function () {
        return Array.from(this.displayed.values()).pop();
    };
    KitModalService.prototype.initBackdrop = function () {
        var _this = this;
        if (!this.backdropRef) {
            this.backdropRef = this.overlay.hostComponent({ component: KitModalBackdropComponent });
            this.backdropRef.componentRef.instance.close.subscribe(function () {
                _this.backdropClickHandler();
            });
            this.em.listenGlobal('keydown', function (event) {
                if (event.keyCode === keyEscape) {
                    _this.escHandler();
                }
            }, true);
        }
    };
    return KitModalService;
}());
KitModalService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
];
KitModalService.ctorParameters = function () { return [
    { type: KitOverlayService, },
    { type: KitEventManagerService, },
    { type: KitModalOptions, },
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] },] },
    { type: KitPlatformService, },
    { type: KitModalService, decorators: [{ type: Optional }, { type: Inject, args: [forwardRef(function () { return KitModalService; }),] }, { type: SkipSelf },] },
    { type: ComponentFactoryResolver, },
]; };
KitModalService.ngInjectableDef = defineInjectable({ factory: function KitModalService_Factory() { return new KitModalService(inject(KitOverlayService), inject(KitEventManagerService), inject(KitModalOptions), inject(DOCUMENT), inject(KitPlatformService), inject(KitModalService, 12), inject(ComponentFactoryResolver)); }, token: KitModalService, providedIn: "root" });
var KitModalComponent = /** @class */ (function () {
    function KitModalComponent(ref, service, options) {
        var _this = this;
        this.ref = ref;
        this.service = service;
        this.options = options;
        this.close = new EventEmitter();
        this._displayed = false;
        this.ref.options = this.options;
        this.ref.onClose.subscribe(function () {
            _this.close.emit();
        });
    }
    Object.defineProperty(KitModalComponent.prototype, "backdropClose", {
        set: function (backdropClose) {
            this.ref.applyParams({ backdropClose: backdropClose });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitModalComponent.prototype, "escClose", {
        set: function (escClose) {
            this.ref.applyParams({ escClose: escClose });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitModalComponent.prototype, "scrollLock", {
        set: function (scrollLock) {
            this.ref.applyParams({ scrollLock: scrollLock });
        },
        enumerable: true,
        configurable: true
    });
    KitModalComponent.prototype.ngAfterContentInit = function () {
        var _this = this;
        this.overlay.displayed.subscribe(function (displayed) {
            if (_this._displayed !== displayed) {
                _this._displayed = displayed;
                if (displayed && _this.overlay.viewRef) {
                    _this.ref.viewRef = _this.overlay.viewRef;
                    _this.service.addRef(_this.ref);
                }
                else {
                    _this.ref.onDestroy.next();
                }
            }
        });
    };
    KitModalComponent.prototype.ngOnDestroy = function () {
        this.ref.onDestroy.next();
    };
    return KitModalComponent;
}());
KitModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'kit-modal',
                template: '<ng-content></ng-content>',
                providers: [
                    KitModalRef,
                ],
            },] },
];
KitModalComponent.ctorParameters = function () { return [
    { type: KitModalRef, },
    { type: KitModalService, },
    { type: KitModalOptions, },
]; };
KitModalComponent.propDecorators = {
    "close": [{ type: Output },],
    "overlay": [{ type: ContentChild, args: [KitOverlayDirective,] },],
    "backdropClose": [{ type: Input },],
    "escClose": [{ type: Input },],
    "scrollLock": [{ type: Input },],
};
var KitModalModule = /** @class */ (function () {
    function KitModalModule() {
    }
    return KitModalModule;
}());
KitModalModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitModalBackdropComponent,
                    KitModalComponent,
                ],
                exports: [
                    KitModalComponent,
                ],
                entryComponents: [
                    KitModalBackdropComponent,
                ],
            },] },
];
var KitOutsideClickService = /** @class */ (function () {
    function KitOutsideClickService(zone, em, elementRef) {
        var _this = this;
        this.zone = zone;
        this.em = em;
        this.elementRef = elementRef;
        this.skip = [];
        this._outsideClick = new Subject();
        this.zone.runOutsideAngular(function () {
            _this.unsubFn = _this.em.listenGlobal('click', function (event) {
                var path = event['path'] || _this.em.getEventPath(event);
                var skip = __spread([_this.elementRef.nativeElement], _this.skip);
                if (skip.every(function (e) { return path.indexOf(e) === -1; })) {
                    _this.zone.run(function () {
                        _this._outsideClick.next(event);
                    });
                }
            }, true);
        });
    }
    Object.defineProperty(KitOutsideClickService.prototype, "outsideClick", {
        get: function () {
            return this._outsideClick.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    KitOutsideClickService.prototype.ngOnDestroy = function () {
        if (this.unsubFn) {
            this.unsubFn();
        }
    };
    return KitOutsideClickService;
}());
KitOutsideClickService.decorators = [
    { type: Injectable },
];
KitOutsideClickService.ctorParameters = function () { return [
    { type: NgZone, },
    { type: KitEventManagerService, },
    { type: ElementRef, },
]; };
var KitOutsideClickDirective = /** @class */ (function () {
    function KitOutsideClickDirective(service) {
        this.service = service;
        this.kitOutsideClick = new EventEmitter();
    }
    KitOutsideClickDirective.prototype.ngOnInit = function () {
        var _this = this;
        this.service.outsideClick.subscribe(function (e) {
            _this.kitOutsideClick.emit(e);
        });
    };
    KitOutsideClickDirective.prototype.ngOnChanges = function () {
        this.service.skip = __spread(this.anchor ? [this.anchor.nativeEl] : [], this.skip
            ? isArray(this.skip) ? this.skip.map(function (s) { return s.nativeEl || s; }) : [this.skip.nativeEl || this.skip]
            : []);
    };
    return KitOutsideClickDirective;
}());
KitOutsideClickDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitOutsideClick]',
                providers: [
                    KitOutsideClickService,
                ],
            },] },
];
KitOutsideClickDirective.ctorParameters = function () { return [
    { type: KitOutsideClickService, },
]; };
KitOutsideClickDirective.propDecorators = {
    "anchor": [{ type: Input },],
    "skip": [{ type: Input },],
    "kitOutsideClick": [{ type: Output },],
};
var KitOutsideClickModule = /** @class */ (function () {
    function KitOutsideClickModule() {
    }
    return KitOutsideClickModule;
}());
KitOutsideClickModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitOutsideClickDirective,
                ],
                exports: [
                    KitOutsideClickDirective,
                ],
            },] },
];
var KitOverlayToggleDirective = /** @class */ (function () {
    function KitOverlayToggleDirective(_elementRef) {
        this._elementRef = _elementRef;
        this.trigger = 'click';
        this._state = new BehaviorSubject$1(false);
    }
    Object.defineProperty(KitOverlayToggleDirective.prototype, "stateChanges", {
        get: function () {
            return this._state.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitOverlayToggleDirective.prototype, "state", {
        get: function () {
            return this._state.value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitOverlayToggleDirective.prototype, "elementRef", {
        get: function () {
            return this._elementRef;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitOverlayToggleDirective.prototype, "nativeEl", {
        get: function () {
            return this._elementRef.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    KitOverlayToggleDirective.prototype.clickHandler = function () {
        if (this.trigger === 'click') {
            this.toggle();
        }
    };
    KitOverlayToggleDirective.prototype.mouseenterHandler = function () {
        if (this.trigger === 'hover') {
            this.show();
        }
    };
    KitOverlayToggleDirective.prototype.mouseleaveHandler = function () {
        if (this.trigger === 'hover') {
            this.close();
        }
    };
    KitOverlayToggleDirective.prototype.show = function () {
        this._state.next(true);
    };
    KitOverlayToggleDirective.prototype.close = function () {
        this._state.next(false);
    };
    KitOverlayToggleDirective.prototype.toggle = function () {
        this._state.next(!this._state.value);
    };
    return KitOverlayToggleDirective;
}());
KitOverlayToggleDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitOverlayToggle]',
                exportAs: 'toggle',
            },] },
];
KitOverlayToggleDirective.ctorParameters = function () { return [
    { type: ElementRef, },
]; };
KitOverlayToggleDirective.propDecorators = {
    "trigger": [{ type: Input },],
    "clickHandler": [{ type: HostListener, args: ['click',] },],
    "mouseenterHandler": [{ type: HostListener, args: ['mouseenter',] },],
    "mouseleaveHandler": [{ type: HostListener, args: ['mouseleave',] },],
};
var KitOverlayModule = /** @class */ (function () {
    function KitOverlayModule() {
    }
    return KitOverlayModule;
}());
KitOverlayModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitOverlayDirective,
                    KitOverlayToggleDirective,
                ],
                declarations: [
                    KitOverlayDirective,
                    KitOverlayHostWrapperComponent,
                    KitOverlayHostComponent,
                    KitOverlayToggleDirective,
                ],
                entryComponents: [
                    KitOverlayHostWrapperComponent,
                    KitOverlayHostComponent,
                ],
            },] },
];
var positionPairs = {
    top: 'bottom',
    bottom: 'top',
    left: 'right',
    right: 'left',
};
var KitStyleService = /** @class */ (function () {
    function KitStyleService(el, differs, renderer) {
        this.el = el;
        this.differs = differs;
        this.renderer = renderer;
    }
    Object.defineProperty(KitStyleService.prototype, "style", {
        set: function (v) {
            this._style = v;
            if (!this._differ && v) {
                this._differ = this.differs.find(v).create();
            }
            var changes = this._differ.diff(this._style);
            if (changes) {
                this.applyChanges(changes);
            }
        },
        enumerable: true,
        configurable: true
    });
    KitStyleService.prototype.applyChanges = function (changes) {
        var _this = this;
        changes.forEachRemovedItem(function (record) { return _this.setStyle(record.key, null); });
        changes.forEachAddedItem(function (record) { return _this.setStyle(record.key, record.currentValue); });
        changes.forEachChangedItem(function (record) { return _this.setStyle(record.key, record.currentValue); });
    };
    KitStyleService.prototype.setStyle = function (nameAndUnit, value) {
        var _a = __read(nameAndUnit.split('.'), 2), name = _a[0], unit = _a[1];
        value = value != null && unit ? "" + value + unit : value;
        this.renderer.setStyle(this.el.nativeElement, name, (value));
    };
    return KitStyleService;
}());
KitStyleService.decorators = [
    { type: Injectable },
];
KitStyleService.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: KeyValueDiffers, },
    { type: Renderer2, },
]; };
var KitPinPositionDirective = /** @class */ (function () {
    function KitPinPositionDirective(elementRef, zone, style$$1, platform, em) {
        var _this = this;
        this.elementRef = elementRef;
        this.zone = zone;
        this.style = style$$1;
        this.platform = platform;
        this.em = em;
        this.unsubs = [];
        this.style.style = {
            left: '0',
            position: 'fixed',
            top: '0',
        };
        if (this.platform.isBrowser()) {
            this.zone.onStable
                .pipe(take(1))
                .subscribe(function () {
                _this.zone.runOutsideAngular(function () {
                    _this.unsubs = __spread(_this.unsubs, [
                        _this.em.listenGlobal('scroll', _this.reposition.bind(_this), true),
                        _this.em.listenGlobal('resize', _this.reposition.bind(_this), true),
                    ]);
                });
            });
        }
    }
    KitPinPositionDirective.prototype.ngOnChanges = function () {
        this.reposition();
    };
    KitPinPositionDirective.prototype.reposition = function () {
        var field = this.getField();
        var anchor = this.getRect(this.anchor);
        this.style.style = this.calc(this.position, field, anchor);
    };
    KitPinPositionDirective.prototype.calc = function (position, field, anchor) {
        var common = {
            display: 'flex',
            position: 'fixed',
        };
        var vSideLeft = field.width / 2 > anchor.left + anchor.width / 2;
        var vSideTop = field.height / 2 > anchor.top + anchor.height / 2;
        switch (this.position) {
            case 'top':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', height: this.px(anchor.top), left: this.px(anchor.left), width: this.px(anchor.width) });
            case 'top-center':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', justifyContent: 'center', height: this.px(anchor.top), left: vSideLeft ? '0' : this.px(anchor.left - (field.width - anchor.right)), width: vSideLeft ? this.px(anchor.left + anchor.right) : this.px(anchor.width + (field.width - anchor.right) * 2) });
            case 'top-right':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', justifyContent: 'flex-end', height: this.px(anchor.top), left: '0', width: this.px(anchor.right) });
            case 'top-left':
                return Object.assign({}, common, { alignItems: 'flex-end', top: '0', flexDirection: 'row', justifyContent: 'flex-start', height: this.px(anchor.top), left: this.px(anchor.left), width: this.px(field.width - anchor.left) });
            case 'right':
                return Object.assign({}, common, { flexDirection: 'column', height: this.px(anchor.height), left: this.px(anchor.right), top: this.px(anchor.top) });
            case 'right-center':
                return Object.assign({}, common, { flexDirection: 'column', justifyContent: 'center', height: vSideTop ? this.px(anchor.top + anchor.bottom) : this.px(anchor.height + (field.height - anchor.bottom) * 2), left: this.px(anchor.right), top: vSideTop ? '0' : this.px(anchor.top - (field.height - anchor.bottom)) });
            case 'right-top':
                return Object.assign({}, common, { flexDirection: 'column', height: this.px(field.height - anchor.top), justifyContent: 'flex-start', left: this.px(anchor.right), top: this.px(anchor.top) });
            case 'right-bottom':
                return Object.assign({}, common, { flexDirection: 'column', height: this.px(anchor.bottom), justifyContent: 'flex-end', left: this.px(anchor.right), top: '0' });
            case 'bottom':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', height: this.px(field.height - anchor.bottom), left: this.px(anchor.left), top: this.px(anchor.bottom), width: this.px(anchor.width) });
            case 'bottom-center':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'center', height: this.px(field.height - anchor.bottom), left: vSideLeft ? '0' : this.px(anchor.left - (field.width - anchor.right)), top: this.px(anchor.bottom), width: vSideLeft ? this.px(anchor.left + anchor.right) : this.px(anchor.width + (field.width - anchor.right) * 2) });
            case 'bottom-right':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'flex-end', height: this.px(field.height - anchor.bottom), left: '0', width: this.px(anchor.right), top: this.px(anchor.bottom) });
            case 'bottom-left':
                return Object.assign({}, common, { alignItems: 'flex-start', flexDirection: 'row', justifyContent: 'flex-start', height: this.px(field.height - anchor.bottom), left: this.px(anchor.left), top: this.px(anchor.bottom), width: this.px(field.width - anchor.left) });
            case 'left':
                return Object.assign({}, common, { alignItems: 'flex-end', left: '0', flexDirection: 'column', height: this.px(anchor.height), top: this.px(anchor.top), width: this.px(anchor.left) });
            case 'left-center':
                return Object.assign({}, common, { alignItems: 'flex-end', flexDirection: 'column', justifyContent: 'center', height: vSideTop ? this.px(anchor.top + anchor.bottom) : this.px(anchor.height + (field.height - anchor.bottom) * 2), left: '0', top: vSideTop ? '0' : this.px(anchor.top - (field.height - anchor.bottom)), width: this.px(anchor.left) });
            case 'left-top':
                return Object.assign({}, common, { alignItems: 'flex-end', flexDirection: 'column', justifyContent: 'flex-start', height: this.px(field.height - anchor.top), left: '0', right: this.px(field.width - anchor.left), top: this.px(anchor.top), width: this.px(anchor.left) });
            case 'left-bottom':
                return Object.assign({}, common, { alignItems: 'flex-end', flexDirection: 'column', justifyContent: 'flex-end', height: this.px(anchor.bottom), left: '0', top: '0', width: this.px(anchor.left) });
            default:
                throw new Error("Position " + position + " in not correct!");
        }
    };
    KitPinPositionDirective.prototype.getRect = function (el) {
        return this.getEl(el).getBoundingClientRect();
    };
    KitPinPositionDirective.prototype.getEl = function (el) {
        return el['nativeEl'] ? el['nativeEl'] : el;
    };
    KitPinPositionDirective.prototype.getField = function () {
        return {
            height: window.innerHeight,
            width: window.innerWidth,
        };
    };
    KitPinPositionDirective.prototype.px = function (value) {
        return Math.round(value) + "px";
    };
    return KitPinPositionDirective;
}());
KitPinPositionDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitPinPosition]',
                providers: [
                    KitStyleService,
                ],
            },] },
];
KitPinPositionDirective.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: NgZone, },
    { type: KitStyleService, },
    { type: KitPlatformService, },
    { type: KitEventManagerService, },
]; };
KitPinPositionDirective.propDecorators = {
    "kitPinPosition": [{ type: Input },],
    "anchor": [{ type: Input },],
    "position": [{ type: Input },],
};
var KitPositionModule = /** @class */ (function () {
    function KitPositionModule() {
    }
    return KitPositionModule;
}());
KitPositionModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitPinPositionDirective,
                ],
                exports: [
                    KitPinPositionDirective,
                ],
            },] },
];
var KitRefDirective = /** @class */ (function () {
    function KitRefDirective(_template) {
        this._template = _template;
    }
    Object.defineProperty(KitRefDirective.prototype, "template", {
        get: function () {
            return this._template;
        },
        enumerable: true,
        configurable: true
    });
    return KitRefDirective;
}());
KitRefDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitRef]',
                exportAs: 'ref',
            },] },
];
KitRefDirective.ctorParameters = function () { return [
    { type: TemplateRef, },
]; };
var KitRefModule = /** @class */ (function () {
    function KitRefModule() {
    }
    return KitRefModule;
}());
KitRefModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitRefDirective,
                ],
                exports: [
                    KitRefDirective,
                ],
            },] },
];
var KitRepeatDirective = /** @class */ (function () {
    function KitRepeatDirective(vcr, template) {
        this.vcr = vcr;
        this.template = template;
    }
    KitRepeatDirective.prototype.ngOnChanges = function () {
        if (this.kitRepeat) {
            this.vcr.clear();
            for (var index = 0; index < this.kitRepeat; index++) {
                this.vcr.createEmbeddedView(this.template, { index: index });
            }
        }
    };
    return KitRepeatDirective;
}());
KitRepeatDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitRepeat]',
            },] },
];
KitRepeatDirective.ctorParameters = function () { return [
    { type: ViewContainerRef, },
    { type: TemplateRef, },
]; };
KitRepeatDirective.propDecorators = {
    "kitRepeat": [{ type: Input },],
};
var KitRepeatModule = /** @class */ (function () {
    function KitRepeatModule() {
    }
    return KitRepeatModule;
}());
KitRepeatModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    KitRepeatDirective,
                ],
                exports: [
                    KitRepeatDirective,
                ],
            },] },
];
var KitScrollService = /** @class */ (function () {
    function KitScrollService(platform, elRef, hammerProvider) {
        this.platform = platform;
        this.elRef = elRef;
        this.hammerProvider = hammerProvider;
        this._state = new BehaviorSubject({
            nativeScrollbarWidth: 0,
            dragging: false,
            vBar: {
                active: false,
                size: 0,
                position: 0,
            },
            hBar: {
                active: false,
                size: 0,
                position: 0,
            },
        });
        if (!this.hammerProvider.hammer) {
            throw new Error('KitScrollService requires Hammer.JS');
        }
        this._state.next(Object.assign({}, this.state, { nativeScrollbarWidth: this.platform.getScrollbarWidth() }));
    }
    Object.defineProperty(KitScrollService.prototype, "state", {
        get: function () {
            return this._state.value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitScrollService.prototype, "stateChanges", {
        get: function () {
            return this._state.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    KitScrollService.prototype.ngOnDestroy = function () {
        this.mutationObserver.disconnect();
    };
    KitScrollService.prototype.registerRefs = function (refs) {
        this.refs = refs;
        this.initVListeners();
        this.initHListeners();
        this.initMutationObserver();
    };
    KitScrollService.prototype.update = function () {
        this.updateVBar();
        this.updateHBar();
    };
    KitScrollService.prototype.updateVBar = function () {
        var state = this.calcBar(this.refs.vWrapper.scrollHeight - this.state.nativeScrollbarWidth, this.elRef.nativeElement.offsetHeight, this.refs.vBarWrapper.offsetHeight, this.refs.vWrapper.scrollTop);
        this._state.next(Object.assign({}, this.state, { vBar: state }));
    };
    KitScrollService.prototype.updateHBar = function () {
        var state = this.calcBar(this.refs.hWrapper.scrollWidth, this.elRef.nativeElement.offsetWidth, this.refs.hBarWrapper.offsetWidth, this.refs.hWrapper.scrollLeft);
        this._state.next(Object.assign({}, this.state, { hBar: state }));
    };
    KitScrollService.prototype.calcBar = function (contentSize, hostSize, barWrapperSize, scrollPosition) {
        if (contentSize > hostSize) {
            var size = Math.round(Math.max((hostSize / contentSize) * barWrapperSize, 30));
            return {
                active: true,
                size: size,
                position: Math.round((barWrapperSize - size) * (scrollPosition / (contentSize - hostSize))),
            };
        }
        else {
            return {
                active: false,
                size: 0,
                position: 0,
            };
        }
    };
    KitScrollService.prototype.initVListeners = function () {
        var _this = this;
        var vBarHammerConfig = new HammerGestureConfig();
        vBarHammerConfig.overrides = {
            pan: {
                direction: KitHammerTypes.DIRECTION_VERTICAL,
                threshold: 1,
            },
        };
        var vBarHammer = vBarHammerConfig.buildHammer(this.refs.vBar);
        var scrollStart = null;
        vBarHammer.on('pan', function (event) {
            if (scrollStart === null) {
                scrollStart = _this.refs.vWrapper.scrollTop;
                _this._state.next(Object.assign({}, _this.state, { dragging: true }));
            }
            var contentHeight = _this.refs.hWrapper.scrollHeight;
            var hostHeight = _this.elRef.nativeElement.offsetHeight;
            var coef = contentHeight / hostHeight;
            if (scrollStart !== null) {
                _this.refs.vWrapper.scrollTop = Math.round(scrollStart + event.deltaY * coef);
            }
            if (event.isFinal) {
                scrollStart = null;
                _this._state.next(Object.assign({}, _this.state, { dragging: false }));
            }
        });
        var vBarWrapperHammer = vBarHammerConfig.buildHammer(this.refs.vBarWrapper);
        vBarWrapperHammer.on('tap', function (event) {
            if (event.target === _this.refs.vBarWrapper) {
                var pos = _this.hammerProvider.calcRelatedPosition(_this.refs.vBarWrapper, event.center);
                _this.refs.vWrapper.scrollTop += pos.y > _this.state.vBar.position ? 200 : -200;
            }
        });
    };
    KitScrollService.prototype.initHListeners = function () {
        var _this = this;
        var hBarHammerConfig = new HammerGestureConfig();
        hBarHammerConfig.overrides = {
            pan: {
                direction: KitHammerTypes.DIRECTION_HORIZONTAL,
                threshold: 1,
            },
        };
        var hBarHammer = hBarHammerConfig.buildHammer(this.refs.hBar);
        var scrollStart = null;
        hBarHammer.on('pan', function (event) {
            if (scrollStart === null) {
                scrollStart = _this.refs.hWrapper.scrollLeft;
                _this._state.next(Object.assign({}, _this.state, { dragging: true }));
            }
            var contentWidth = _this.refs.hWrapper.scrollWidth;
            var hostWidth = _this.elRef.nativeElement.offsetWidth;
            var coef = contentWidth / hostWidth;
            if (scrollStart !== null) {
                _this.refs.hWrapper.scrollLeft = Math.round(scrollStart + event.deltaX * coef);
            }
            if (event.isFinal) {
                scrollStart = null;
                _this._state.next(Object.assign({}, _this.state, { dragging: false }));
            }
        });
        var hBarWrapperHammer = hBarHammerConfig.buildHammer(this.refs.hBarWrapper);
        hBarWrapperHammer.on('tap', function (event) {
            if (event.target === _this.refs.hBarWrapper) {
                var pos = _this.hammerProvider.calcRelatedPosition(_this.refs.hBarWrapper, event.center);
                _this.refs.hWrapper.scrollLeft += pos.x > _this.state.hBar.position ? 200 : -200;
            }
        });
    };
    KitScrollService.prototype.initMutationObserver = function () {
        var _this = this;
        this.mutationObserver = new MutationObserver(function (mutations) {
            if (mutations.length > 0) {
                _this.update();
            }
        });
        this.mutationObserver.observe(this.refs.hWrapper, {
            attributes: true,
            childList: true,
            characterData: true,
            subtree: true,
        });
    };
    return KitScrollService;
}());
KitScrollService.decorators = [
    { type: Injectable },
];
KitScrollService.ctorParameters = function () { return [
    { type: KitPlatformService, },
    { type: ElementRef, },
    { type: KitHammerProvider, },
]; };
var KitSlideHostService = /** @class */ (function () {
    function KitSlideHostService(zone) {
        this.zone = zone;
        this.activateFirst = true;
        this._active = new BehaviorSubject(null);
        this._direction = new BehaviorSubject('next');
        this.firstRegistration = false;
        this.ids = new Set();
        this.lastId = 0;
    }
    Object.defineProperty(KitSlideHostService.prototype, "active", {
        get: function () {
            return this._active.value;
        },
        set: function (id) {
            var _this = this;
            this._direction.next(this._active.value === null
                ? 'initial'
                : id !== null && this.getIndex(id) > this.getIndex(this._active.value)
                    ? 'next'
                    : 'prev');
            this.zone.onStable.pipe(take(1)).subscribe(function () {
                _this._active.next(id);
            });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitSlideHostService.prototype, "activeInitial", {
        set: function (id) {
            var _this = this;
            this._direction.next('initial');
            this.zone.onStable.pipe(take(1)).subscribe(function () {
                _this._active.next(id);
            });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitSlideHostService.prototype, "activeChanges", {
        get: function () {
            return this._active.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KitSlideHostService.prototype, "directionChanges", {
        get: function () {
            return this._direction.asObservable();
        },
        enumerable: true,
        configurable: true
    });
    KitSlideHostService.prototype.addId = function (id) {
        if (!this.firstRegistration) {
            this.firstRegistration = true;
            if (this.activateFirst) {
                this.active = id;
            }
        }
        this.ids.add(id);
    };
    KitSlideHostService.prototype.deleteId = function (id) {
        this.ids.delete(id);
    };
    KitSlideHostService.prototype.genId = function () {
        this.lastId++;
        return this.lastId;
    };
    KitSlideHostService.prototype.next = function (cycle) {
        if (cycle === void 0) { cycle = false; }
        var ids = Array.from(this.ids);
        var currentIndex = this.getCurrentIndex();
        if (currentIndex < ids.length - 1) {
            this.active = ids[currentIndex + 1];
        }
        else if (cycle) {
            this.active = ids[0];
        }
    };
    KitSlideHostService.prototype.prev = function (cycle) {
        if (cycle === void 0) { cycle = false; }
        var ids = Array.from(this.ids);
        var currentIndex = this.getCurrentIndex();
        if (currentIndex > 0) {
            this.active = ids[currentIndex - 1];
        }
        else if (cycle) {
            this.active = ids[ids.length - 1];
        }
    };
    KitSlideHostService.prototype.getCurrentIndex = function () {
        return this.getIndex(this._active.value);
    };
    KitSlideHostService.prototype.getIndex = function (value) {
        var ids = Array.from(this.ids);
        return ids.findIndex(function (i) { return i === value; });
    };
    return KitSlideHostService;
}());
KitSlideHostService.decorators = [
    { type: Injectable },
];
KitSlideHostService.ctorParameters = function () { return [
    { type: NgZone, },
]; };
var KitSlideDirective = /** @class */ (function () {
    function KitSlideDirective(vcr, template, host, cdr, zone) {
        this.vcr = vcr;
        this.template = template;
        this.host = host;
        this.cdr = cdr;
        this.zone = zone;
        this.kitSlide = null;
        this.destroy = new Subject();
        this.displayed = false;
    }
    KitSlideDirective.prototype.ngOnChanges = function (changes) {
        if (changes['kitSlide'] && changes['kitSlide'].currentValue !== null) {
            this.host.deleteId(changes['kitSlide'].previousValue);
            this.host.addId(changes['kitSlide'].currentValue);
        }
    };
    KitSlideDirective.prototype.ngOnDestroy = function () {
        this.host.deleteId(this.kitSlide);
        this.destroy.next();
    };
    KitSlideDirective.prototype.ngOnInit = function () {
        var _this = this;
        if (this.kitSlide === null) {
            this.kitSlide = this.host.genId();
            this.host.addId(this.kitSlide);
        }
        this.host.activeChanges
            .pipe(takeUntil(this.destroy))
            .subscribe(function (id) {
            if (id === _this.kitSlide) {
                if (!_this.displayed) {
                    _this.zone.run(function () {
                        _this.vcr.createEmbeddedView(_this.template);
                        _this.displayed = true;
                        _this.cdr.detectChanges();
                    });
                }
            }
            else {
                if (_this.displayed) {
                    _this.zone.run(function () {
                        _this.vcr.clear();
                        _this.displayed = false;
                        _this.cdr.detectChanges();
                    });
                }
            }
        });
    };
    return KitSlideDirective;
}());
KitSlideDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kitSlide]',
            },] },
];
KitSlideDirective.ctorParameters = function () { return [
    { type: ViewContainerRef, },
    { type: TemplateRef, },
    { type: KitSlideHostService, },
    { type: ChangeDetectorRef, },
    { type: NgZone, },
]; };
KitSlideDirective.propDecorators = {
    "kitSlide": [{ type: Input },],
};
var KitSlideModule = /** @class */ (function () {
    function KitSlideModule() {
    }
    return KitSlideModule;
}());
KitSlideModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                exports: [
                    KitSlideDirective,
                ],
                declarations: [
                    KitSlideDirective,
                ],
            },] },
];
var KitStyleModule = /** @class */ (function () {
    function KitStyleModule() {
    }
    return KitStyleModule;
}());
KitStyleModule.decorators = [
    { type: NgModule, args: [{},] },
];
function isMergeableObject(value) {
    return isNonNullObject(value) && isNotSpecial(value);
}
function isNonNullObject(value) {
    return !!value && typeof value === 'object';
}
function isNotSpecial(value) {
    var stringValue = Object.prototype.toString.call(value);
    return stringValue !== '[object RegExp]'
        && stringValue !== '[object Date]';
}
function isObject(x) {
    return x != null && typeof x === 'object';
}
function emptyTarget(val) {
    return Array.isArray(val) ? [] : {};
}
function cloneIfNecessary(value, optionsArgument) {
    var clone = optionsArgument && optionsArgument.clone === true;
    return (clone && isMergeableObject(value)) ? mergeDeep(emptyTarget(value), value, optionsArgument) : value;
}
function defaultArrayMerge(target, source, optionsArgument) {
    var destination = target.slice();
    source.forEach(function (e, i) {
        if (typeof destination[i] === 'undefined') {
            destination[i] = cloneIfNecessary(e, optionsArgument);
        }
        else if (isMergeableObject(e)) {
            destination[i] = mergeDeep(target[i], e, optionsArgument);
        }
        else if (target.indexOf(e) === -1) {
            destination.push(cloneIfNecessary(e, optionsArgument));
        }
    });
    return destination;
}
function mergeObject(target, source, optionsArgument) {
    var destination = {};
    if (isMergeableObject(target)) {
        Object.keys(target).forEach(function (key) {
            destination[key] = cloneIfNecessary(target[key], optionsArgument);
        });
    }
    Object.keys(source).forEach(function (key) {
        if (!isMergeableObject(source[key]) || !target[key]) {
            destination[key] = cloneIfNecessary(source[key], optionsArgument);
        }
        else {
            destination[key] = mergeDeep(target[key], source[key], optionsArgument);
        }
    });
    return destination;
}
function mergeDeep(target, source, optionsArgument) {
    var sourceIsArray = Array.isArray(source);
    var targetIsArray = Array.isArray(target);
    var options = optionsArgument || { arrayMerge: defaultArrayMerge };
    var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
    if (!sourceAndTargetTypesMatch) {
        return cloneIfNecessary(source, optionsArgument);
    }
    else if (sourceIsArray) {
        var arrayMerge = options.arrayMerge || defaultArrayMerge;
        return arrayMerge(target, source, optionsArgument);
    }
    else {
        return mergeObject(target, source, optionsArgument);
    }
}
function mergeDeepAll(array, optionsArgument) {
    if (!Array.isArray(array) || array.length < 2) {
        throw new Error('first argument should be an array with at least two elements');
    }
    return array.reduce(function (prev, next) {
        return mergeDeep(prev, next, optionsArgument);
    });
}

export { KitAnchorDirective, KitAnchorModule, KIT_CHECK_VALUE_ACCESSOR, KitCheckDirective, KitCheckModule, KitClassDirective, KitClassModule, KitClassService, KitCollapseDirective, KitCollapseModule, KitCollapseHostService, KitCollapseItemService, KitDatePickerService, KitDatePickerModule, KitEventManagerService, keyArrowUp, keyArrowDown, keyArrowRight, keyArrowLeft, keyPageUp, keyPageDown, keyHome, keyEnd, keyEnter, keySpace, keyTab, keyEscape, keyBackspace, keyDelete, keyShift, keyCtrl, keyAlt, KitFocusListenerService, KitFocusManagerModule, KitFocusManagerService, KitFocusManagerRegistryService, KitFocusDirective, KitFocusTrapDirective, KitFormFieldModule, KitFormFieldService, KitFormErrorDirective, KitNgControlDirective, KitFormTouchModule, KitFormTouchDirective, KitHammerProvider, KitHammerTypes, KitIconComponent, KitIconsModule, KitIconsRegistryService, KitInputDateDirective, KitInputDateModule, KitIntersectionModule, KitIntersectionService, KitIntersectionDirective, KitLoadingService, KitLoadingProgress, kitLoadingGlobal, KitLoadingState, KitMqModule, KitMqService, kitMqBreakpoints, KitMqDirective, KitModalModule, KitModalService, KitModalRef, KitModalOptions, KitModalComponent, KitMomentProvider, KitOutsideClickDirective, KitOutsideClickModule, KitOutsideClickService, KitOverlayModule, KitOverlayDirective, KitOverlayService, KitOverlayComponentRef, KitOverlayToggleDirective, positionPairs, KitPlatformService, KitPositionModule, KitPinPositionDirective, KitRefDirective, KitRefModule, KitRepeatDirective, KitRepeatModule, KitScrollService, KitSlideDirective, KitSlideModule, KitSlideHostService, KitStyleService, KitStyleModule, KitValueAccessorDirective, KitValueAccessorModule, KitModelInterceptor, isArray, isDefined, isMergeableObject, isNonNullObject, isNotSpecial, isObject, isString, isUndefined, mergeDeep, mergeDeepAll, uuid, KitModalBackdropComponent as ɵb, KitOverlayHostWrapperComponent as ɵc, KitOverlayHostComponent as ɵd, KitDefaultModelInterceptor as ɵa };
//# sourceMappingURL=ngx-kit-core.js.map
