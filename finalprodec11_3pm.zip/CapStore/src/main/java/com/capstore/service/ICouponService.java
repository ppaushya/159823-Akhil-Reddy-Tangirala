package com.capstore.service;

import com.capstore.model.Coupons;

public interface ICouponService {

	Boolean applyingCoupon(Coupons coupons);

}
