package org.cap.service;

import org.cap.model.LoginPojo;

public interface ILoginService {

	boolean isValidLogin(LoginPojo loginPojo);
	
}
