package org.cap.service;

import org.cap.model.LoginPojo;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements ILoginService {

	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
		// TODO Auto-generated method stub
		
		if(loginPojo.getUsername().equals("tom") && loginPojo.getPassword().equals("tom123"))
			return true;
		return false;
	}

	

}
