package org.cap.config;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
public class JavaConfig {

	
	@Bean
	public String sayHello() {
		return "Hello World";
	}
	
	
	@Bean()
	public Employee getEmployee() {
//		return new Employee(1001,"Tom",20000);
		
		Employee employee=new Employee();
		employee.setEmployeeName("akhil");
		employee.setSalary(123);
		return employee;
	
	}
	
	@Bean(name="address2")
	public Address getAddress() {
		return new Address("North avenue","chennai");
	}
	
	@Bean(name="address1")
	public Address getAddress1() {
		return new Address("south avenue","hyd");
	}
	
}
