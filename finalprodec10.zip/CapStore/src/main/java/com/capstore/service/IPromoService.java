package com.capstore.service;

import com.capstore.model.Promos;

public interface IPromoService {

	public void addPromo(Promos promo);

}
