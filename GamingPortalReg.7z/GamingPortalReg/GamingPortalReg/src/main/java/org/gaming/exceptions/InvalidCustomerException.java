package org.gaming.exceptions;

public class InvalidCustomerException extends Exception {
        
	public InvalidCustomerException(String str)
	{
		super(str);
	}
}
