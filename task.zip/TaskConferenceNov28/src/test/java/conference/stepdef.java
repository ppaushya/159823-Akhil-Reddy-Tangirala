package conference;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

private WebElement webelement;
	
	private WebDriver webdriver;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\aktangir\\Downloads\\chromedriver.exe" );
		webdriver=new ChromeDriver();
	}
		 
	
	
	@Given("^Registration form page$")
	public void registration_form_page() throws Throwable {
	  
		 webdriver.get("file:///C:/Users/aktangir/Downloads/mam%20codes/Conferencebooking/Conferencebooking/ConferenceRegistartion.html#");

	}

	@When("^All the details are valid and filled$")
	public void all_the_details_are_valid_and_filled() throws Throwable {
	    
		
		webdriver.findElement(By.name("txtFN")).sendKeys("Akhil");
//		webdriver.findElement(By.name("txtLN")).sendKeys("");
		webdriver.findElement(By.name("Email")).sendKeys("akhil@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9723076359");
		
		
		Select dropdown = new Select(webdriver.findElement(By.name("size")));
		dropdown.selectByVisibleText("5");
		webdriver.findElement(By.name("Address")).sendKeys("SMR Fountainhead");
		webdriver.findElement(By.name("Address2")).sendKeys("Metro water works road");
		Select dropdown1 = new Select(webdriver.findElement(By.name("city")));
		dropdown1.selectByVisibleText("Hyderabad");

		Select dropdown2 = new Select(webdriver.findElement(By.name("state")));
		dropdown2.selectByVisibleText("Telangana");
		
		 WebElement radio1 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));							
	 		
	        //Radio Button1 is selected		
	        radio1.click();	
	        
	   	 WebElement radio2 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));							
	 		
	        //Radio Button1 is selected		
	        radio2.click();	   
	       
	}
	


	@Then("^Click Next Button,navigate to next page$")
	public void click_Next_Button_navigate_to_next_page() throws Throwable {
	    
		 WebElement click = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));							
	 		
	        //Radio Button1 is selected		
	        click.click();	
	       
	        Alert alert = webdriver.switchTo().alert();
	      
	        String test=alert.getText();
	        
	        if(test.compareTo("Personal details are validated")==0)
	     alert.accept();
	        
	        
	  webdriver.navigate().to("file:///C:/Users/aktangir/Downloads/mam%20codes/Conferencebooking/Conferencebooking/PaymentDetails.html");

		
	}
	
	@Then("^fill details of payment page$")
	public void fill_details_of_payment_page() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Akhil Reddy");
		webdriver.findElement(By.name("debit")).sendKeys("9485343429344323");
		webdriver.findElement(By.name("cvv")).sendKeys("786");
		webdriver.findElement(By.name("month")).sendKeys("October");
		webdriver.findElement(By.name("year")).sendKeys("2023");
		
		 WebElement makepayment = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));							
makepayment.click();
		
	}
	

	
	
}
