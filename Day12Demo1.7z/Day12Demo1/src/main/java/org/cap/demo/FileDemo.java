package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File file=new File("D:\\Users\\aktangir\\Desktop\\myf.txt");

if(file.isFile()) {
		if(file.exists())
		{
			System.out.println("Readable:"+file.canRead());
		}else
		{
			System.out.println("sorry no file");
		}
		
	}
else if(file.isDirectory())
{
	String[] names=file.list();
}
else
{
	System.out.println("sorrye");
	try {
		file.createNewFile();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
int ch;
try(FileReader reader=new FileReader(file)) {
	char[] ch1=new char[20];

	  int j=0;
	do {
	 ch=reader.read();
	 ch1[j]=(char) ch;
	j++;
	
	}while(ch!=-1);
	
	
	int i;
	for(i=j-2;i>=0;i--)
	 {
		 System.out.print(ch1[i]);
	 }
	
	
//	char[] ch1=new char[5];
//	int i=0;
//	do {
//	 ch=reader.read();
//	 
//		 ch1[i]=(char) ch;
//	 i++;
//	 
//	 
//
//	}while(ch!=-1 && i<5);
//	
//	for(i=4;i>=0;i--)
//	 {
//		 System.out.print(ch1[i]);
//	 }
	
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


}
}