package org.cap.demo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class WriteCharacterDemo {
public static void main(String[] args)
{
	File file=new File("D:\\Users\\aktangir\\Desktop\\sample.txt");
	int ch;
	String str="Na ishtam";
	try(FileWriter writer=new FileWriter(file)) {
		
		writer.write(str);
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


	}

}
