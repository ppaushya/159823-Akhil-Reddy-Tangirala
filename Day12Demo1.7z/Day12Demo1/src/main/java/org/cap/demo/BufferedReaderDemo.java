package org.cap.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class BufferedReaderDemo {

	public static void main(String[] args)
	{
		FileReader in;
		try {
			in=new FileReader("D:\\Users\\aktangir\\Desktop\\sample.txt");
			BufferedReader reader=new BufferedReader(in);
String line="sfsd";
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
	
}
