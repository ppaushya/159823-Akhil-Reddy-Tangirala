package org.cap.object.demo;

import java.io.Serializable;
import java.util.Scanner;

public class UserInteraction implements Serializable {
Scanner scr=new Scanner(System.in);
	public Product getDetails()
	{
		Product p=new Product();
		System.out.println("enter the product id");
		int pid=scr.nextInt();
		p.setProductId(pid);
		
		System.out.println("enter the product name");
		String pname=scr.next();
		p.setProductName(pname);
		
		System.out.println("enter the product quantity");
		int q=scr.nextInt();
		p.setQuantity(q);
		
		System.out.println("enter the price");
		double price=scr.nextDouble();
		p.setPrice(price);
		
		return p;
		
		
	}
	
	
	
}
