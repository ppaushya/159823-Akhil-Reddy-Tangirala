package org.cap.object.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class MainClass implements Serializable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner(System.in);
		String ch;
		
		File file=new File("D:\\Users\\aktangir\\Desktop\\sample.txt");
		do
		{
			UserInteraction ui=new UserInteraction();
			try(FileOutputStream out=new FileOutputStream(file);
				ObjectOutputStream out2=new ObjectOutputStream(out)	){
				
				Product p1=ui.getDetails();
				
				out2.writeObject(p1);
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
			



System.out.println("do u want to continue[y/n]");	

ch=scr.next();
			
			
		}while(ch.charAt(0)=='y');

try(FileInputStream in=new FileInputStream(file); ObjectInputStream in2=new ObjectInputStream(in)){
	
	System.out.println(in2.readObject());
	
	
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		
		
	}

}
