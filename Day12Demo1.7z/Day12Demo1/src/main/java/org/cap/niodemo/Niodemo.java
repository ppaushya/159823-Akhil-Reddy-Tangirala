package org.cap.niodemo;

import java.io.File;

public class Niodemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File file=new File("D:\\Users\\aktangir\\Desktop\\task2.txt");



		
		
	}

}
