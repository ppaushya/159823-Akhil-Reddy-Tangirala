package day10demos;

import java.time.LocalDate;

public class Employee {

	private int empid;
	
	private String firstname;
	
	private String lastname;
	
	private double salary;
	
	private LocalDate empdoj;

	@Override
	public String toString() {
		return "employee [empid=" + empid + ", firstname=" + firstname + ", lastname=" + lastname + ", salary=" + salary
				+ ", empdoj=" + empdoj + "]";
	}

	public Employee() {
		super();
	}

	public Employee(int empid, String firstname, String lastname, double salary, LocalDate empdoj) {
		super();
		this.empid = empid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
		this.empdoj = empdoj;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public LocalDate getEmpdoj() {
		return empdoj;
	}

	public void setEmpdoj(LocalDate empdoj) {
		this.empdoj = empdoj;
	}
	
	
	
	
}
