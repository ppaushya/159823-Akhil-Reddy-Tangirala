package day10demos;

import java.util.List;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	
	public List<Employee>  getAllEmployees();
	public void updateEmployee(int employeeid);
	public void findEmployees(int employeeid);
	
	
}
