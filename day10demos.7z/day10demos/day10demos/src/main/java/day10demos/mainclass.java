package day10demos;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sender<String, String> send= new Sender<>();
		
		send.setMessage("hello morning");
		send.setMedium("hello medium");

				System.out.println(send.getMedium());
				System.out.println(send.getMessage());
		
		Sender send1= new Sender<>();
		
		send1.setMedium(1);
		send1.setMessage(2);
		
		System.out.println(send1.getMedium()+" "+send1.getMessage());
		
		
		Calculate<Integer,Integer> cal=new Calculate<>();
		
		cal.setNum1(1);
		cal.setNum2(2);
		
		System.out.println(cal.getNum1()+cal.getNum2());
	}

}
