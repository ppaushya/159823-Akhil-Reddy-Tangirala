import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
 import { ProductListComponent } from './products/product-list.component';

// import { SportsComponent } from './sports/sports.component';
import { AppComponent1 } from './app1.component';
import { ConvertToSpacesPipe } from './shared/convert-to-spaces.pipe';
import { StarComponent } from './shared/star.component';
import { ProductService } from './products/product.service';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './products/product-detail.component';
import {RouterModule} from '@angular/router';
import { WelcomeComponent } from './home/welcome.component';


@NgModule({
  declarations: [
    ProductListComponent,
    ConvertToSpacesPipe,
    StarComponent,
    ProductDetailComponent,
    WelcomeComponent,
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([{path: 'products', component: ProductListComponent},
  {path: 'products/:id',component: ProductDetailComponent}, {path: 'welcome',component: WelcomeComponent},
  {path: '',redirectTo: 'welcome',pathMatch: 'full'},
  {path: '**',redirectTo: 'welcome', pathMatch: 'full'}
  
  ]) 
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
