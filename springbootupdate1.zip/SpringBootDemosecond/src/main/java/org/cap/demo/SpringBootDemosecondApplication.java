package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemosecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemosecondApplication.class, args);
	}
}
