validation(){
	
	var username=document.getElementById("username");
	var password=document.getElementById("password");
	
	if(username!=null)
		{
		document.getElementById("para").innerHTML=""
		}
	
	
}



