import static org.junit.Assert.*;

import org.gaming.Dao.ICustomerDao;
import org.gaming.exceptions.InvalidCustomerException;
import org.gaming.model.Registration;
import org.gaming.services.CustomerServicesImpl;
import org.gaming.services.ICustomerServices;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import static org.junit.Assert.*;


public class addRegistrationAccount {

	@Mock
	private ICustomerDao customerDao;
	
	private ICustomerServices customerservice;
	
	

	
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);
		customerservice = new CustomerServicesImpl(customerDao);
	}
	
	
	
	@Test
	public void when_createaccount_with_invalidformat() throws InvalidCustomerException {
		//fail("Not yet implemented");
		
	
		Registration reg = new Registration();
		
		reg.setCustomerName("nikhi");
		reg.setMobileNumber("7989499127");
		reg.setRegistrationFee(1000);
		reg.setAge(10);
		reg.setActualRegFeePaid(1000);
		
		
		Mockito.when(customerDao.doCustomerRegistration(reg)).thenReturn(true);
		
		
		
		customerservice.doCustomerRegistration(reg);
		
		
		Mockito.verify(customerDao).doCustomerRegistration(reg);
		
		
		
	}

}
