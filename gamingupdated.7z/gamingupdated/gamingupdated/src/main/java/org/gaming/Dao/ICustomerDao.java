package org.gaming.Dao;

import org.gaming.model.Registration;

public interface ICustomerDao {

	public boolean doCustomerRegistration(Registration registration);

}
