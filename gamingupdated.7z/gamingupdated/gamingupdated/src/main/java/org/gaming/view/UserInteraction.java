package org.gaming.view;

import java.util.Scanner;

import org.gaming.model.Registration;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	
	public Registration getregistrationdetails()
	{
		Registration newRegistration=new Registration();
		
		System.out.println("enter the registration details");
		
		//create reg id using sequence
		
		System.out.println("enter the customer name");
		
		String name=scanner.next();
		
		newRegistration.setCustomerName(name);
		
		System.out.println("enter the mobile number");
		
		String mobileNo = scanner.next();
		
		newRegistration.setMobileNumber(mobileNo);
		
		System.out.println("enter the registration fees");
		
		double regFees=scanner.nextDouble();
		
		newRegistration.setRegistrationFee(regFees);
	    
		System.out.println("enter the age of the customer");
		
		int age=scanner.nextInt();
		
		newRegistration.setAge(age);
		
		//calculate actual reg fee paid 
		
		
		double actualRegFeePaid=calculatefees(regFees,age);
		
		newRegistration.setActualRegFeePaid(actualRegFeePaid);
		
		
		return newRegistration;
	}
	
	public void printAcknolwedge(Registration reg)
	{
	     System.out.println("Reg Id :"+reg.getRegistrationId());
	     System.out.println("congrats " + reg.getCustomerName() + "u have succesfully created an account");
	}
	
	public double calculatefees(double regfees,int age)
	{
		if(age>=0 && age<18)
		{
			return regfees;
		}
		else if(age>=18 && age<25)
		{
			return 1.1 * regfees;
		}
		else if(age>=25 && age<50)
		{
			return 1.2 * regfees;
		}
		else 
		{
			return 1.3 * regfees;
		}
		
	}
}
