package org.capgemini;

public class Employee<T>{

	private T address;

	public T getAddress() {
		return address;
	}

	public void setAddress(T address) {
		this.address = address;
	}
	
	
	
}
