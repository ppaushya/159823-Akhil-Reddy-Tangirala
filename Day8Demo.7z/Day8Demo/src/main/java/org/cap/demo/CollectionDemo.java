package org.cap.demo;

import java.util.ArrayList;
import java.util.Collection;

import java.util.List;
public class CollectionDemo {

	public static void main(String[] args) {

//		ArrayList<Integer> lst=new ArrayList<>();
		ArrayList lst=new ArrayList<>();
		
		List lst1=new ArrayList<>();
		
		Collection lst3=new ArrayList<>();
		
		
		Iterable lst4=new ArrayList<>();
		lst.add(3);
		
		lst.add("tom");
		
		lst.add(new Object());
		
		System.out.println(lst);
		System.out.println(lst.get(1));
		
		lst.add("tom");
		System.out.println(lst);
lst.add(null);
System.out.println(lst);

	}

}
