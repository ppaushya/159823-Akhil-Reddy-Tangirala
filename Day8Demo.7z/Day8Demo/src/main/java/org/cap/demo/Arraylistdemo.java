package org.cap.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;
import java.util.Vector;

public class Arraylistdemo {
 
	public static void main(String[] args) {

//		ArrayList<String> arr=new ArrayList<>();
		Vector<String> arr=new Vector<>();
		arr.add("Tom");
		arr.add("jom");
		arr.add("rom");
		arr.add("vom");
		arr.add("som");
		
		int index1=arr.indexOf("jom");
		System.out.println("index is" +index1);
		
		int index2=arr.lastIndexOf("jom");
		System.out.println("index is" +index2);
		
		
		ArrayList<String> ar=new ArrayList<>();
		ar.add("pod");
		ar.add("qod");
		ar.add("rod");

		arr.addAll(ar);
		
		int size=arr.size();
		System.out.println("The size is "+size);
		
		boolean b=arr.contains("rod");
		System.out.println("The boolean is "+b);
		
		ar.clear();
		
		
		boolean empty=ar.isEmpty();
		System.out.println("The boolean is "+empty);
		
		ar.add("asd");
		
		System.out.println(arr.get(3));
		
		Object obj=ar.toArray();
		
		boolean a=arr.containsAll(ar);
		System.out.println("The boolean is "+a);
		
		arr.ensureCapacity(20);
		
		Vector<String> ref=(Vector<String>) arr.clone();
		System.out.println(ref); 
		
		Vector<String> vector = new Vector<String>();

	      // populate the vector
	      vector.add("R");
	      vector.add("B");
	      vector.add("R");

	      System.out.println("Initial values are :"+vector);

	      // replace 'R' with 'Replace All'
	      Collections.replaceAll(vector, "R", "Replace All");

	      System.out.println("Value after replace :"+ vector);
	      
		boolean q=arr.equals(ar);
		System.out.println("The boolean is "+q);
		
		// create an empty array list 
	    ArrayList<String> color_list = new ArrayList<String>();

	    // use add() method to add values in the list
	    color_list.add("White");
	    color_list.add("Black");
		color_list.add("Red");
	   
	   // create an empty array sample with an initial capacity 
		ArrayList<String> sample = new ArrayList<String>();
		
	   // use add() method to add values in the list 
	    sample.add("Green"); 
		sample.add("Red"); 
		sample.add("White");
			
	    System.out.println("First List :"+ color_list);
		System.out.println("Second List :"+ sample);
		
		sample.retainAll(color_list);
		
		System.out.println("After applying the method, First List :"+ color_list);
		System.out.println("After applying the method, Second List :"+ sample);
		
		
		 // Creating an empty Vector 
        Vector<String> vec_tor = new Vector<String>(); 
  
        // Use add() method to add elements in the Vector 
        vec_tor.add("Geeks"); 
        vec_tor.add("for"); 
        vec_tor.add("Geeks"); 
        vec_tor.add("10"); 
        vec_tor.add("20"); 
  
        // Output the Vector 
        System.out.println("Vector: " + vec_tor); 
  
        // Creating an empty Vector 
        Vector<String> colvec_tor = new Vector<String>(); 
  
        // Use add() method to add elements in the Vector 
        colvec_tor.add("Geeks"); 
        colvec_tor.add("for"); 
        colvec_tor.add("Geeks"); 
  
        // Remove the head using remove() 
        boolean changed = vec_tor.removeAll(colvec_tor); 
  
        // Print the result 
        if (changed) 
            System.out.println("Collection removed"); 
        else
            System.out.println("Collection not removed"); 

int index=arr.indexOf("qod");
System.out.println(index);

arr.add("rod");

arr.removeAll(ar);

List<String> names = new ArrayList<>();
names.add("Rams");
names.add("Posa");
names.add("Chinni");
	
// Getting Spliterator
Spliterator<String> namesSpliterator = names.spliterator();
namesSpliterator.forEachRemaining(System.out::println);


//Creating an empty Vector 
Vector<Integer> vec_tor1 = new Vector<Integer>(); 

// Adding the elements using add() 
vec_tor1.add(5); 
vec_tor1.add(1); 
vec_tor1.add(50); 
vec_tor1.add(10); 
vec_tor1.add(20); 
vec_tor1.add(6); 
vec_tor1.add(20); 
vec_tor1.add(18); 
vec_tor1.add(9); 
vec_tor1.add(30); 

System.out.println("The Vector is: " + vec_tor1); 

// Creating the sublist vector 
List<Integer> sub_list = new ArrayList<Integer>(); 

// Limiting the values till 5 
sub_list = vec_tor1.subList(2, 5); 

// Displaying the list data 
System.out.println("The resultant values "
                   + "within the sub list: " + sub_list); 


ArrayList<Integer> myArray = new ArrayList<Integer>(50);

	// Only add four elements to the ArrayList.
       myArray.add(98);
       myArray.add(12);
       myArray.add(122);
		myArray.add(43);

   // Trim the ArrayList down to size.
       myArray.trimToSize();
		
   // Print all the elements available in list
   for (Integer number : myArray) {
     System.out.println("Number = " + number);
		
     // Creating an empty LinkedList 
     LinkedList<String> list = new LinkedList<String>(); 

     // Use add() method to add elements in the list 
     list.add("Geeks"); 
     list.add("for"); 
     list.add("Geeks"); 
     list.add("10"); 
     list.add("20"); 

     // Displaying the linkedlist 
     System.out.println("LinkedList:" + list); 
       
     // Setting the ListIterator at a specified position 
     ListIterator list_Iter = list.listIterator(2); 

     // Iterating through the created list from the position 
     System.out.println("The list is as follows:"); 
     while(list_Iter.hasNext()){ 
        System.out.println(list_Iter.next()); 
     
     
ar.add(1, "hi");
		
		for(String str:arr)
		{
			System.out.print(str+",");
		}                                                                                                             
		
		System.out.println();
		
//		Iterator<String> it=arr.iterator();
//		while(it.hasNext())
//		{
//			
//			System.out.print(it.next()+",");
//		}
		
		
		
		ListIterator<String> lstit=arr.listIterator();
		while(lstit.hasNext())
		{
			System.out.println(lstit.next());
		}
		
//		Enumeration<String> enumu=arr.elements();
//		while(enumu.hasMoreElements())
//		{
//			System.out.print(enumu.nextElement()+" -> ");
//		}
		
		System.out.println();
		while(lstit.hasPrevious())
		{
			System.out.println(lstit.previous());
		}
	}

}}}
