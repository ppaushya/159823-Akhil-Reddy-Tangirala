import java.util.Scanner;
public class Personinher {

	public Personinher()
	{
		
	}
	
	public void show()
	{
		System.out.println("person class-> show method");
	}
	public Personinher(int personId, String firstname, String lastname) {
		
		this.personId = personId;
		this.firstname = firstname;
		this.lastname = lastname;
	}


	int personId;
	String firstname;
	String lastname;
	
	public void getPerson()
	{
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter person id:");
		personId=scr.nextInt();
	System.out.println("Enter firstname");	
	firstname=scr.next();

	
	}
	
	public void showPerson()
	{
		System.out.println("personid"+personId+"firstname"+firstname);

	
	}
	
	

}
