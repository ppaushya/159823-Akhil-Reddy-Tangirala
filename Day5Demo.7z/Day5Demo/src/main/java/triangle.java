
public class triangle {

}
