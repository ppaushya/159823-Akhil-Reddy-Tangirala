
public class ugstudents implements student{

	public void Display_Grade()
	{
		System.out.println("ugstudents display grade");
	}
	public void attendance() 
	{
		System.out.println("ugstudents attendance");

	}
}
