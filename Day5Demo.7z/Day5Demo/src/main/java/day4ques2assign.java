interface day4ques2assign
{
static final float pi=3.142f;
float compute(float x,float y);
}


