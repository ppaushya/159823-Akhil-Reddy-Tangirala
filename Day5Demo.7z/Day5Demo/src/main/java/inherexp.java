
public class inherexp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
employeeinher e=new employeeinher();
e.getPerson();
e.getEmployee();
		
e.showemloyee();
//e.showPerson();
	

	
	Personinher p=new employeeinher();
	p.show();
}}
