
public interface ques3 {

	void divisions();
	void modules();
	
	
	
}
