class mainclassday5assign 
{
public static void main(String args[])
{
	rectangle_day5assign rect=new rectangle_day5assign();
	circle_day5assign cr=new circle_day5assign();

System.out.println("Area of the rectangle= "+rect.compute(10,20));

System.out.println("Area of the circle= "+cr.compute(10,0));
}
}