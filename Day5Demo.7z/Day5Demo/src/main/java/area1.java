interface area1
{
static final float pi=3.142f;
float compute(float x,float y);
}
class rectangle1 implements area
{
public float compute(float x,float y)
{return(x*y);}
}
class circle2 implements area
{
public float compute(float x,float y)
{return(pi*x*x);}
}
class s05_021
{
public static void main(String args[])
{
rectangle1 rect=new rectangle1();
circle2 cr=new circle2();

System.out.println("Area of the rectangle= "+rect.compute(10,20));

System.out.println("Area of the circle= "+cr.compute(10,0));
}
}