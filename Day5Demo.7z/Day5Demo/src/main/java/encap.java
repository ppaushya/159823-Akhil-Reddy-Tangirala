import java.util.Scanner;
public class encap {
	
	private int studentid;
	private String firstname;
	private String lastname;
	private double regFees;
	
	public encap()
	{
		
	}

	public int getStudentId()
	{
		return this.studentid;
	}
	
	public void setStudentId(int studentid)
	{
		this.studentid=studentid;
	}
	
	public String getFirstName()
	{
		return this.firstname;
	}
	
	public void setFirstname(String fname)
	{
		this.firstname=fname;
	}
	
	public String getLasttName()
	{
		return this.firstname;
	}
	
	public void setLastname(String lname)
	{
		this.lastname=lname;
	}
	
	
	
	public double getregfees()
	{
		return this.regFees;
	}
	
	public void setregfees(int studentid)
	{
		this.regFees=regFees;
	}
	
	
	

}
