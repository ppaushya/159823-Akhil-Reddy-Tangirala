
import java.util.*;

//--------------
	class Calls{
		float duration;
		String type;
		float rate(){
		if(type.equals("urgent"))
		return 6.5f;
		else if(type=="lightcall")
		return 4.5f;
		else
		return 3f;
		}
		}
	
	//---------------
	
		class Bill extends Calls{
		float amount;
		
		
		void read(){
		Scanner input=new Scanner(System.in);
		System.out.print("Mention Call Type whether urgent or lightning or ordinary: ");
		type=input.next();
		System.out.print("Enter Call duration:");
		duration=input.nextFloat();
		}
		
		
		void calculate(){
		if(duration<=1.5){
		amount=rate()*duration+1.75f;
		}
		else if(duration<=30){
		amount=rate()*duration+2.5f;
		}
		else if(duration<=50){
		amount=rate()*duration+4.5f;
		}
		else{
		amount=rate()*duration+5f;
		}
		}
		
		
		
		void print(){
		System.out.println(" Call Type : "+type);
		System.out.println(" Duration : "+duration);
		System.out.println(" Charge: "+amount);
		}
		}
		
		
	//--------------------	
		
		class trunkcall{
		public static void main(String arg[]){
		Bill tel=new Bill();
		tel.read();
		tel.calculate();
		tel.print();
		}
		}


