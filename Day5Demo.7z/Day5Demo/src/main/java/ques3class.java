
public class ques3class {

	void divisions()
	{
		System.out.println("hi");
	}
	
	
	void modules()
	{
		System.out.println("hello");

	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
	}

}
