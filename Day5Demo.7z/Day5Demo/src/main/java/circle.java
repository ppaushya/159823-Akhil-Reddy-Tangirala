public class circle implements shape {


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void draw() {
		shape.show();
		
		System.out.println("draw method of circle");
	}

	@Override
	public void info() {
		showpoints();
		System.out.println("info method of circle");
		
	}

} 