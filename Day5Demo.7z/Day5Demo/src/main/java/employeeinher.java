import java.util.Scanner;

public class employeeinher extends Personinher {
	double salary;
	boolean isPermanent;
	
	public employeeinher()
	{
		
	}
	
	@Override
	public void show()
	{
		System.out.println("employee class-> show method");
	}
	
	public employeeinher(double salary, boolean isPermanent) {
		super();
		this.salary = salary;
		this.isPermanent = isPermanent;
	}

	public void getEmployee()
	{
		Scanner scr=new Scanner(System.in);
		System.out.println("enter salary");
		salary=scr.nextDouble();
		
	}
	
	public void showemloyee()
	{
		System.out.println(salary);
	}
	
}
