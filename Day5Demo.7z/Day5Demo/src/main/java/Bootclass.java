
public class Bootclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap e=new encap();
		e.setFirstname("Akhil");
		System.out.println(e.getFirstName());
	}

}
