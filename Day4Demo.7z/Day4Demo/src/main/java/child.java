
public class child extends parent {

	int num=121;
	
	int childnum=1212;
	public child()
	{
		System.out.println("child constructot");
	}
	
	public void show3()
	{
	System.out.println(num);
	

	}
	
	
}
