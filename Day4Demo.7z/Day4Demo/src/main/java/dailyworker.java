
public class dailyworker extends worker {

	
	public void compay(int hours)
	{int h=hours;
		int paydays=hours/24;
		System.out.println(paydays*10);
	}

}
