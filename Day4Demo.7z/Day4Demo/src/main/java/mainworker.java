
public class mainworker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		salariedworker s=new salariedworker();
		dailyworker d=new dailyworker();
s.compay(67);
		d.compay(98);
	}

}
