
enum customertype
{
	SILVER(0,100),GOLD(1,123),DIAMOND(2,343);
	int minreward;
	int maxreward;

	
	
	private customertype(int minreward,int maxreward)
	{
		this.minreward=minreward;
		this.maxreward=maxreward;

	}
	
	public int getminreward()
	{
		return this.minreward;
	}
	
	public int getmaxreward()
	{
		return this.maxreward;
	}
}


public class enumdemo2 {

	
	int customerid=1001;
	String customername="akhil";
	customertype custom= customertype.DIAMOND;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 enumdemo2 e=new enumdemo2();
 System.out.println(e.customerid+","+e.customername+","+e.custom+","+e.custom.getminreward());
 
 
	}

}
