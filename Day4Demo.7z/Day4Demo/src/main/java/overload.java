
public class overload {


	public overload()
	{
		System.out.println("default");
		
	}
	
	public overload(float p)
	{
		System.out.println(p);
	}
	
	public overload(float p,float q)
	{
		System.out.println(p+q);

	}
	
	public overload(float p,float q,float r)
	{
		System.out.println(p*q*r/100);

	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		overload o=new overload();
		overload o1=new overload(2);
		overload o2=new overload(3,2);
		overload o3=new overload(3,5,7);



	}

}
