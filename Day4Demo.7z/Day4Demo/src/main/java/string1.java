
public class string1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="dfgd";
String str1=new String("sdgfsdg");
String str3="dfgd";
String str4=new String("sdgfsdg");


System.out.println(str.hashCode());
System.out.println(str1.hashCode());
System.out.println(str3.hashCode());
System.out.println(str4.hashCode());


	}

}
