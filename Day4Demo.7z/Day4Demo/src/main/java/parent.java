
public class parent extends grandparent {



	public parent()
	{
		System.out.println("p constructot");
	}
	
	public void show()
	{
	System.out.println(num);
	}
	
}
