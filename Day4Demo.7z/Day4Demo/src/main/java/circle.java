
public class circle extends shape{
	
	final float pi=3.14f;
	float radius;

	
	public float calculateArea(float radius)
	{
		return pi*radius*radius;
	}
	public circle(float radius) {
		super();
		this.radius = radius;
	}
	public void draw()
	{
		System.out.println("circle class");
	}
	
}
