
public class stringdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sh="akh";
		String mystr=new String("akh");
		String str1="akh";
		String mystr2=new String("akh");

		System.out.println(sh==mystr);
		System.out.println(sh.equals(mystr));
		System.out.println(mystr.equals(mystr2));
		System.out.println(mystr==mystr2);

		System.out.println(sh==str1);


	}

}
