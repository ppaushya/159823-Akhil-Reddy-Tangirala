
public abstract class shape {

	
	int width;
	int height;

	public shape()
	{
		
	}
	
	public shape(int width,int height)
	{
	  System.out.println(width*height);
	}
	
	public void info()
	{
		System.out.println("shape information");
	}
	
	public void draw()
	{
		System.out.println("Circle class draw method");
	}
	

}
