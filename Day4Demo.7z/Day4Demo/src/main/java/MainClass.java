
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Weekdays myday=Weekdays.SAT;
		
		switch(myday)
		{
		case SAT:
			System.out.println("Assignment Day");
		}
		
	}

}
