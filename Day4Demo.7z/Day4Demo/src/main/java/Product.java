
public class Product {

	
//	public Product(int productid, String productname, double price, int qty) {
//		super();
//		this.productid = productid;
//		this.productname = productname;
//		this.price = price;
//		this.qty = qty;
//	}



	int productid;
//	public Product() {
//	super();
//}



	String productname;
	double price;
	int qty;
	
	public Product()
	{
		System.out.println("default Constructor");
	}
	
	public Product(int productid)
	{
		System.out.println("overloaded Constructor 1 aug");

		this.productid=productid;
	}
	
	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productname=" + productname + ", price=" + price + ", qty=" + qty
				+ "]";
	}

	public Product(int productid,int a)
	{
		System.out.println("overloaded Constructor 2 aug");

		this.productid=productid;
		this.qty=a;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product p=new Product();

Product p2=new Product(23);
Product p3=new Product(23);

System.out.println(p);
System.out.println(p2.hashCode());

System.out.println(p3.hashCode()   );

		
		
	}

}
