
public enum Weekdays {

	SUN(1),MON(2),TUE(3),WED(4),THURS(5),FRI(6),SAT(7);
	
	int value;
	
	//enum constructor
	private Weekdays(int var)
	{
		this.value=value;
	}
	
	public int getvalue()
	{
		return this.value;
	}
}
