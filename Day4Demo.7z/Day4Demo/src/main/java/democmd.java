
public class democmd {


		
		public static void main(String[] args)
		{

		for(String str:args)
		{
		System.out.println(str);
		}
		}
		
	
}
