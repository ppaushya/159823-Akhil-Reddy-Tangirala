import java.util.Scanner;
public class enumdemo {

	
	int empid;
	String firstname;
	String lastname;
	int age;
	double salary;
	
	Weekdays weekoff;
	
	public void getemployee()
	{
		empid=101;
		firstname="akhil";
		lastname="reddy";
		age=12;
		salary=23000;
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter weekday");
		int weekday=scr.nextInt();

		if(weekday==1) {
		weekoff=Weekdays.SUN;
		}
		
		if(weekday==2) {
			weekoff=Weekdays.MON;
			}
		
		if(weekday==3) {
			weekoff=Weekdays.TUE;
			}
		
		if(weekday==4) {
			weekoff=Weekdays.WED;
			}
		
		if(weekday==5) {
			weekoff=Weekdays.THURS;
			}
		
		if(weekday==6) {
			weekoff=Weekdays.FRI;
			}
		
		if(weekday==7) {
			weekoff=Weekdays.SAT;
			}
	}
	
	public void printemployee()
	{
		System.out.println("empid"+empid+"firstname"+firstname+"weekoff"+weekoff  );
	}
	public static void main(String[] args) {
		// TODO Auto-generated method1 stub
		enumdemo e=new enumdemo();
		e.getemployee();
		e.printemployee();
		
		
		
		
		
	}

}
