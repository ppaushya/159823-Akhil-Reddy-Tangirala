
public class grandparent {

	
	int num=123;
	
	public grandparent()
	{
		System.out.println("gp constructot");
	}
	
	public void show()
	{
	System.out.println(num);
	}
	
}
