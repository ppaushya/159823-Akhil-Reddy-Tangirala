
public class methodcheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String str1="akhilreddy";
		
		String str2="tangirala";
		
		int result=str1.compareTo(str2);
		
		System.out.println(result);
		
		String str3=str1.concat(str2);
		
		System.out.println(str3);
		
		System.out.println(str3.contains(str2));
		
		System.out.println(str3.endsWith(str2));


	}

}
