import java.util.Arrays;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {10,23,12,343,233,3434};
		int[] arr1= {10,23,12,343,233,3434};

		String[] as= {"s","e","a"};
		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		Arrays.sort(as);
		for(int i=0;i<as.length;i++)
		{
			System.out.println(as[i]);
		}
		
//		int[] myarr=Arrays.copyOf(arr,arr.length);
		
		int[] myarr=Arrays.copyOfRange(arr,2,arr.length);

		
		for(int i=0;i<myarr.length;i++)
		{
			System.out.println(myarr[i]);
		}
		
		System.out.println(arr);
		System.out.println(myarr);
		
		myarr[0]=100;
		
		int result=Arrays.binarySearch(arr1, 343);
		
		System.out.println(result);

	}

}
