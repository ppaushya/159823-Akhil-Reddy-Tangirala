
public class day5ques1 {

}
