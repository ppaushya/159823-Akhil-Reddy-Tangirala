
public abstract class worker {
	
	String name;
	
	int salary;
	
	public abstract void compay(int hours);
	
	
	
}
