
public class salariedworker extends worker {

	
	public void compay(int hours)
	{int h=hours;
		int paydays=hours/40;
		System.out.println(paydays*10);
	}
}
