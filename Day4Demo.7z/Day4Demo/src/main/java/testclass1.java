
public class testclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Weekdays week=new Weekdays();
		
		Weekdays[] values=Weekdays.values();
		
		for(Weekdays day:values)
		{
			System.out.println(day);
		}
		
		
		
		String str="khk";
		Weekdays yourday=Weekdays.valueOf(Weekdays.class,str);
		System.out.println(yourday);
	}

}
