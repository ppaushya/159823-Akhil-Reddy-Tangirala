import java.util.Scanner;
public class trunkcall {

	Scanner scr=new Scanner(System.in);
	
	
}
