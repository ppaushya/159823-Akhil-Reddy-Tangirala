package day6miniproject;

import java.util.Scanner;

import java.util.*;

import java.util.ArrayList;

public class Bootclass {

	public static void main(String[] args) {
		
		Customer c[]=new Customer[5];
		
		int i;
		
		Scanner s = new Scanner(System.in);
		
		ArrayList<Account> accounts = new ArrayList<>();
        
		ArrayList<Customer> customers = new ArrayList<>();
		
		ArrayList<Address> address = new ArrayList<>();
		String name;
		
		boolean z = true;
		
		for(i=0;i<5;i++)
		{
			System.out.println("enter the " + (i+1) +" name of the customer ");
			
			name= s.next();
			
			//c[i]=new Customer();
			
			//c[i].setCustomerName(name);
			
			while(z)
			{
			if(name.matches("[A-Za-z]+"))
			{
				System.out.println("valid name");
				z=false;
			}
			else
			{
				System.out.println("not a valid name enter one more time");
				name=s.next();
				//c[i].setCustomerName(name);
			}
			}
			z=true;
		}
		
		z=true;
		int cid;
		

		for(int k=0;k<5;k++)
		{
			System.out.println("enter the customer id of " + (k+1));
			cid=s.nextInt();
			//c[k].setCustomerId(cid);
			while(z)
			{
				if(Integer.toString(cid).matches("\\d{5,10}"))
				{
				    	System.out.println("valid customer id");
				    	z=false;
				}
				else
				{
					System.out.println("enter one more time as it is not valid");
					cid=s.nextInt();
					//c[k].setCustomerId(cid);
				}
			}
			
			z=true;
		}
	
		
         z=true;
		
		String tem;
		
		for(int k=0;k<5;k++)
		{
			System.out.println("enter the customer email id of " + (k+1));
			tem=s.next();
			//c[k].setEmail(tem);
			while(z)
			{
				if(tem.matches("[a-zA-z0-9]+[@]{1}(gmail){1}[.]{1}(com){1}"))
				{
				    	System.out.println("valid email id");
				    	z=false;
				}
				else
				{
					System.out.println("enter one more time as it is not valid");
					tem=s.next();
					//c[k].setEmail(tem);
					
				}
			}
			
			z=true;
		}
		
		z=true;
		
		String tez;
		
		for(int k=0;k<5;k++)
		{
			System.out.println("enter the customer mobile no of " + (k+1));
			tez=s.next();
			//c[k].setMobileno(tem);
			while(z)
			{
				if(tez.matches("[7-9]{1}[0-9]{9}"))
				{
				    	System.out.println("valid mobile number");
				    	z=false;
				}
				else
				{
					System.out.println("enter one more time as it is not valid");
					tem=s.next();
					//c[k].setMobileno(tem);
					
				}
			}
			
			z=true;
		}
		
		
		
		
		
		for(i=0;i<5;i++)
		{
			System.out.println(c[i].getCustomerName());
			for(int j=0;j<5;j++)
			{
				c[i].account[j]=new Account();
				for(int k=0;k<100;k++)
				{
					c[i].account[j].trans[k]=new Transactions();
				}
			}
		}
		
		
		boolean flag=true;
		
		int t=0,l=0,num,temp,var,cont,count=0,balance;
		
		float m;
		
		z=true;
		
		while(flag)
		{
			System.out.println("enter 1 to view/generateaccount/dotransaction for " + c[0].getCustomerName());
			System.out.println("enter 2 to view/generateaccount/dotransaction for " + c[1].getCustomerName());
			System.out.println("enter 3 to view/generateaccount/dotransaction for " + c[2].getCustomerName());
			System.out.println("enter 4 to view/generateaccount/dotransaction for " + c[3].getCustomerName());
			System.out.println("enter 5 to view/generateaccount/dotransaction for " + c[4].getCustomerName());
			
			num=s.nextInt();
		    
			
			
			System.out.println("1.create account for "+c[num-1].getCustomerName());
			System.out.println("2.do transaction for " +c[num-1].getCustomerName());
			System.out.println("3.view transaction for " +c[num-1].getCustomerName());
			
			temp=s.nextInt();
			
			
			if(temp==1)
			{
				System.out.println("1.create debit account");
				System.out.println("2.create savings account");
				System.out.println("3.create salary account");
				System.out.println("4.create fd account");
				System.out.println("5.create rd account");
				var=s.nextInt();	
				if(c[num-1].account[var-1].getBalance()>=1000)
				{
					System.out.println("account is already created with " + c[num-1].getCustomerName() + " " + c[num-1].account[var-1].getAccno() + " " + c[num-1].account[var-1].getAcctype());
				}
				else
				{
				c[num-1].account[var-1].setAccno(10000+num);
				
				if(var==1)
				{
					c[num-1].account[var-1].setAcctype("debit");
				}
				else if(var==2)
				{
					c[num-1].account[var-1].setAcctype("savings");
				}
				else if(var==3)
				{
					c[num-1].account[var-1].setAcctype("salary");
				}
				else if(var==4)
				{
					c[num-1].account[var-1].setAcctype("fd");
				}
				else if(var==5)
				{
					c[num-1].account[var-1].setAcctype("rd");
				}
				c[num-1].account[var-1].setBalance(1000);
				}
				for(int k=0;k<5;k++)
				{
					if(c[num-1].account[k].getAccno()>=100)
					{
						count++;
						
					}
					
				}
				System.out.println(c[num-1].getCustomerName() + " has total " + count + "accounts");
				count=0;
				
			}
			else if(temp==2)
			{

				System.out.println("1.transact with debit account");
				System.out.println("2.transact with savings account");
				System.out.println("3.transact with salary account");
				System.out.println("4.transact with fd account");
				System.out.println("5.transact with rd account"); 
				count=s.nextInt();
				
				c[num-1].account[count-1].trans[l].setTransid(1000+l);
				
				System.out.println("enter 1 to deposit and 2 to withdraw");
				
				t=s.nextInt();
				
				if(t==1)
				{
					System.out.println("enter amount to add");
					balance=s.nextInt();
					c[num-1].account[count-1].trans[l].setType("depositing");
					c[num-1].account[count-1].setBalance((c[num-1].account[count-1].getBalance()) + (balance));
					c[num-1].account[count-1].trans[l].setAmount(balance);
				 	m=c[num-1].account[count-1].getBalance();
					c[num-1].account[count-1].trans[l].setUpdated(m);
					l++;
				}
				else
				{

					System.out.println("enter amount to withdraw");
					balance=s.nextInt();
					c[num-1].account[count-1].trans[l].setType("withdrawing");
					c[num-1].account[count-1].setBalance((c[num-1].account[count-1].getBalance()) - (balance));
					c[num-1].account[count-1].trans[l].setAmount(balance);
				 	m=c[num-1].account[count-1].getBalance();
					c[num-1].account[count-1].trans[l].setUpdated(m);
					l++;
				}
				
			}
			else if(temp==3)
			{
				System.out.println("l is " +l);
		        
				 System.out.println("1.transact with debit account");
					System.out.println("2.transact with savings account");
					System.out.println("3.transact with salary account");
					System.out.println("4.transact with fd account");
					System.out.println("5.transact with rd account"); 
					count=s.nextInt();
				
				for(int k=0;k<l;k++)
		         {			
		        	 System.out.println("transid is " + c[num-1].account[count-1].trans[k].getTransid() );
		        	 System.out.println("transtype is " +c[num-1].account[count-1].trans[k].getType());
		        	 if(c[num-1].account[count-1].trans[k].getAmount()>0)
		        	 {
		        	 System.out.println("added balance is " +c[num-1].account[count-1].trans[k].getAmount());
		        	 }
		        	 else
		        	 {
		        		 System.out.println("subracted balance is " +c[num-1].account[count-1].trans[k].getAmount()); 
		        	 }
		        	 System.out.println("updated balance is " +c[num-1].account[count-1].trans[k].getUpdated());
		         }
		         if(l==0)
		         {
		        	 System.out.println("there are no transactions to view");
		         }
			}
			System.out.println("enter 1 to continue and 2 to exit");
			
			cont=s.nextInt();
			
			if(cont==2)
			{
				flag=false;
			}
			
			
		}
		

	}

}