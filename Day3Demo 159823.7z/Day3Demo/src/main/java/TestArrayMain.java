
public class TestArrayMain {

	public void printdata(int ... arr)
	{
		for(int value:arr)
		{
			System.out.println(value);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestArrayMain t=new TestArrayMain();
		int[] arr= {1,3,3,24,3};
		t.printdata(arr);
		
	}

}