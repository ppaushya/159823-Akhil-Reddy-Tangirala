
import java.util.Scanner;

public class StrArray {

	String[] myStr;
	
	public void acceptString(int size)
	{
		Scanner scr=new Scanner(System.in);
		myStr=new String[size];
		System.out.println("Enter" + size + "elements");
		
		for(int i=0;i<size;i++)
		{
			myStr[i]=scr.next();
		}
	}
	
	public void reverse(String[] a)
	{
		String temp=null;
		int b=a.length-1,k=0;
		
		while(k<=b)
		{
			temp=a[k];
			a[k]=a[b];
			a[b]=temp;
			k++;
			b--;
			
		}
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	
	public void sortstring(String[] a)
	{

        int n = a.length;
        for (int i = 0; i < n-1; i++)
            for (int j = 0; j < n-i-1; j++)
                if (a[j].compareTo(a[j+1])>=1)
                {
                    String temp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = temp;
                }
        System.out.println();
        
    	System.out.println("sorted order is: ");

        for(int i=0;i<n;i++)
        {
        	System.out.println(a[i]);

        }
	}
	
	public void printString()
	{
		for(int i=0;i<myStr.length;i++)
		{
			System.out.println(myStr[i]);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StrArray st=new StrArray();
		st.acceptString(5);
		System.out.println();
		st.reverse(st.myStr);
		st.sortstring(st.myStr);
	}
	
	

}
