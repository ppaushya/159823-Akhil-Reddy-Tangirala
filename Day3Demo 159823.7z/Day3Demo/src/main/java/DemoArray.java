import java.util.Scanner;
public class DemoArray {

	int[] myArr;
	
	public void getArrayElements(int size)
	{
		
		Scanner scr=new Scanner(System.in);
		
		myArr=new int[size];
		System.out.println("Enter " +size+"array elements");
		for(int i=0;i<size;i++)
		{
			myArr[i]=scr.nextInt();
		}
		
		
	}
	
	public void printelements()
	{
		for(int i=0;i<myArr.length;i++)
		{
			System.out.println(myArr[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoArray obj=new DemoArray();
		
//		System.out.println(obj.myarr);
		obj.getArrayElements(10);
		obj.printelements();
	}

}
