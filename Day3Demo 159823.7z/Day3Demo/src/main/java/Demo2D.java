import java.util.Scanner;
public class Demo2D {

	public static void main(String[] args) {

		int[][] arr=new int[3][2];
//		arr[0][0]=12;
//		arr[0][1]=12;
//		arr[1][0]=12;
//		arr[1][1]=12;
//		arr[2][0]=12;
//		arr[2][1]=12;
		Scanner sc=new Scanner(System.in);

		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
			arr[i][j]=sc.nextInt();
			
		}
		}
		
		for(int k=0;k<3;k++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println(arr[k][j]+"\t");
			}
		}

	}
	}

