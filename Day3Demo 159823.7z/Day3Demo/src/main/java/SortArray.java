import java.util.Scanner;

public class SortArray {
	
	
int[] myArr;
	
	public void getArrayElements(int size)
	{
		
		Scanner scr=new Scanner(System.in);
		
		myArr=new int[size];
		System.out.println("Enter " +size+"array elements");
		for(int i=0;i<size;i++)
		{
			myArr[i]=scr.nextInt();
		}
		
		
	}
	
	public void sorting(int[] a)
	{
		
	        int n = a.length;
	        for (int i = 0; i < n-1; i++)
	            for (int j = 0; j < n-i-1; j++)
	                if (a[j] > a[j+1])
	                {
	                    int temp = a[j];
	                    a[j] = a[j+1];
	                    a[j+1] = temp;
	                }
	        
	        
        	System.out.println("sorted order is: ");

	        for(int i=0;i<n;i++)
	        {
	        	System.out.print(a[i]);

	        }
	    }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortArray obj=new SortArray();
		obj.getArrayElements(5);
		obj.sorting(obj.myArr);

	}

}
