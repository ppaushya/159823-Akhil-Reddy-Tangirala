import java.util.Scanner;
import java.util.Scanner;
public class Task1 {
	
int[] myArr;
	
	public void getArrayElements(int size)
	{
		
		Scanner scr=new Scanner(System.in);
		
		myArr=new int[size];
		System.out.println("Enter " +size+"array elements");
		for(int i=0;i<size;i++)
		{
			myArr[i]=scr.nextInt();
		}
		
		
	}

	public int biggest(int[] a)
	{
		int max=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>max)
			{
				max=a[i];
			}
		}
		return max;
	}
	
	public int smallest(int[] a)
	{
		int min=1;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]<min)
			{
				min=a[i];
			}
		}
		return min;
	}
	
	public void evennum(int[] a)
	{
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
				sum=sum+a[i];
			}
		}
		
		System.out.println("Sum is: "+sum);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Task1 t=new Task1();
			t.getArrayElements(7);
			System.out.println("Biggest is: "+t.biggest(t.myArr));
			System.out.println("Smallest is: "+t.smallest(t.myArr));
			t.evennum(t.myArr);

	}

}
