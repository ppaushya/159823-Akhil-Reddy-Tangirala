import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;

public class setdemo {

	public static void main(String[] args)
	{
		Set<String> s=new HashSet<>();
		s.add("a");
		s.add("a");
		s.add("a");

		TreeSet<Integer> i=new TreeSet<>();
		
		i.add(234);
		i.add(213);

		i.add(22);
		i.add(231);
//		i.add(null);
		
		
		System.out.println(i);
		
	}
	
}
