import java.util.Comparator;
public class SortBySalary implements Comparator<employee> {

	@Override
	public int compare(employee o1, employee o2) {
		// TODO Auto-generated method stub
		
		if(o1.getSalary()>o2.getSalary())
			return 1;
		else if(o1.getSalary()<o2.getSalary())
			return -1;
		else 
			return 0;
	}

	
	
	
	
}
