
public class customer implements Comparable<customer> {

	private  int custid;
	private String custname;
	private String email;
	private int mobileno;
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + custid;
		result = prime * result + ((custname == null) ? 0 : custname.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + mobileno;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		customer other = (customer) obj;
		if (custid != other.custid)
			return false;
		if (custname == null) {
			if (other.custname != null)
				return false;
		} else if (!custname.equals(other.custname))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (mobileno != other.mobileno)
			return false;
		return true;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMobileno() {
		return mobileno;
	}
	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	public customer(int custid, String custname, String email, int mobileno) {
		super();
		this.custid = custid;
		this.custname = custname;
		this.email = email;
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "customer [custid=" + custid + ", custname=" + custname + ", email=" + email + ", mobileno=" + mobileno
				+ "]";
	}
	
	public customer() {
		super();
		
	}

//	public int compareTo(Object o) {
//		// TODO Auto-generated method stub
//		
//		if(this.custid>o.custid())
//		return 1;
//		else if(this.custid<o.custid())
//			return -1;
//		else
//			return 0;
//
//	
//	}
	@Override
	public int compareTo(customer o) {
		// TODO Auto-generated method stub
		

		if(this.custid>o.getCustid())
		return 1;
		else if(this.custid<o.getCustid())
			return -1;
		else
			return 0;
		
	}
	
}
