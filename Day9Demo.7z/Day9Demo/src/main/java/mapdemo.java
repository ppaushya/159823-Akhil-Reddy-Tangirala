import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class mapdemo {

	public static void main(String[] args) {
		
//		Map<Integer,String> m=new HashMap<>();
		Hashtable<Integer,String> m=new Hashtable<>();
		m.put(1, "akhil");
		m.put(1, "akahil");

		m.put(2, "qkhil");
		m.put(23, "dfse");
//		m.put(null, "qkhil");

		m.put(3, "tkhil");
		m.put(4, "bkhil");
		
		System.out.println(m);
		
		Set<Integer> set=m.keySet();
		
		Iterator<Integer> it=set.iterator();
		
		while(it.hasNext())
		{
			int key=it.next();
			System.out.println(key+"->"+m.get(key));
		}
		
		
		Collection<String> allvalues= m.values();
		
		for(String str:allvalues)
		{
			System.out.println(str);
		}
		
		Enumeration<String> en=m.elements();
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
