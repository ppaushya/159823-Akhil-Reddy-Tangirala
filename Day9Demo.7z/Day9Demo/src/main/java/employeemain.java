import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;

public class employeemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<employee> h=new TreeSet<>();
		
		ArrayList<employee> arr=new ArrayList<>();
		
		//employee emplo=new employee();
		arr.add(new employee("qkhil","reddy",123,LocalDate.now()));
		arr.add(new employee("bkhil","rfeddy",12213,LocalDate.now()));
		arr.add(new employee("fkhil","refdddy",13423,LocalDate.of(2012,2,12)));
		arr.add(new employee("dkhil","refdddy",13423,LocalDate.of(2012,2,12)));

		arr.add(new employee("efkhil","regddy",5,LocalDate.now()));
		arr.add(new employee("fsdkhil","recddy",1623,LocalDate.now()));

		
		Collections.sort(arr);

		
		Iterator<employee> it=arr.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		Comparator<employee> emp=new Comparator<employee>() {

			@Override
			public int compare(employee o1, employee o2) {
				if(o1.getSalary()>o2.getSalary())
					return 1;
				else if(o1.getSalary()<o2.getSalary())
					return -1;
				else 
					return 0;
				
			}
			
		};
		
		
		Collections.sort(arr,new SortBySalary());
		
		
		
		Collections.sort(arr,emp);
		
	}

}
