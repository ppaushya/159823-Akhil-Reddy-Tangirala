import java.time.LocalDate;

public class employee implements Comparable<employee> {

	
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Date == null) ? 0 : Date.hashCode());
		result = prime * result + ((firstname == null) ? 0 : firstname.hashCode());
		result = prime * result + ((lastname == null) ? 0 : lastname.hashCode());
		result = prime * result + salary;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		employee other = (employee) obj;
		if (Date == null) {
			if (other.Date != null)
				return false;
		} else if (!Date.equals(other.Date))
			return false;
		if (firstname == null) {
			if (other.firstname != null)
				return false;
		} else if (!firstname.equals(other.firstname))
			return false;
		if (lastname == null) {
			if (other.lastname != null)
				return false;
		} else if (!lastname.equals(other.lastname))
			return false;
		if (salary != other.salary)
			return false;
		return true;
	}
	private String firstname;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	@Override
	public String toString() {
		return "employee [firstname=" + firstname + ", lastname=" + lastname + ", salary=" + salary + ", Date=" + Date
				+ "]";
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public employee(String firstname, String lastname, int salary, LocalDate date) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
		Date = date;
	}
	public LocalDate getDate() {
		return Date;
	}
	public void setDate(LocalDate date) {
		Date = date;
	}
	private String lastname;
	private int salary;
	private LocalDate Date;

	@Override
	public int compareTo(employee o) {
		// TODO Auto-generated method stub
		
//	if(this.salary>o.getSalary())
//		return 1;
//	else if(this.salary<o.getSalary())
//		return -1;
//	else
//		return 0;
		int i=this.firstname.compareTo(o.getFirstname());
		
		return i;
	}
	public employee() {
		super();
	}
	
	
	 
	
}
