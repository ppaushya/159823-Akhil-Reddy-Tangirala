import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.Iterator;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap<customer,address> h=new TreeMap<>();
		
		h.put(new customer(12,"akhil","reddy",21), new address("kd","kphb","hyd","tel"));
		h.put(new customer(11,"ekhil","aeddy",23), new address("d","khb","hy4d","t1el"));
		h.put(new customer(1,"akhl","red7y",277), new address("kd","kphb","hyd47","tel4"));
		h.put(new customer(13,"akhil","reddy",21), new address("kd","kphb","hyd","tel"));

		
		Set<customer> set=h.keySet();
		Iterator<customer> it=set.iterator();
		
		while(it.hasNext())
		{
			customer key=it.next();
			System.out.println(key+"->"+h.get(key));
		}
		
	}

}
