import java.util.LinkedList;

public class methodpractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<String> lst=new LinkedList<>();
		
		lst.add("a");
		lst.add("b");
		lst.add("c");
		lst.add("d");
		
		System.out.println(lst);
				
		System.out.println(lst.removeFirst());
		
		System.out.println(lst);
		
		
		lst.addFirst("a");
		
		lst.removeLast();
		
		System.out.println(lst);
		
		
		lst.addLast("r");
		System.out.println(lst);
		
		
		
		
	}

}
