package org.cap.demo;

public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="hello";
		
		
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(a.charAt(j)+ " ");
			}
			
			System.out.println();
		}
	}

}
