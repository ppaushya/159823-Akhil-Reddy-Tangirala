package org.cap.demo;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=123123;
		
		switch(num)
		{
	
		case 123123:
System.out.println("one");
System.out.println("block");
break;

		case 3232:
			System.out.println("two");
			System.out.println("block");
break;
		case 13122:
			System.out.println("ten");
			System.out.println("block");

			
		default:
			System.out.println("default block");
			break;


			
		}

	}

}
