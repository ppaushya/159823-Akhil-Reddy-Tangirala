package org.cap.table;

public class StaticSync {

}
