package org.cap.multi;

import org.cap.demo1.ThreadDemo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread th=new MultiDemo( 11);
		Thread th1=new MultiDemo( 12);
		Thread th2=new MultiDemo( 13);
		Thread th3=new MultiDemo( 14);
		Thread th4=new MultiDemo( 15);
		

		Thread t1=new Thread(th);
		t1.start();
//		try {
//			t1.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Thread t=new Thread(th1);
		t.start();
//		try {
//			t.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
		Thread t2=new Thread(th2);
		t2.start();
//		try {
//			t2.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}		
		Thread t3=new Thread(th3);
		t3.start();
//		try {
//			t3.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}		
		Thread t4=new Thread(th4);
		t4.start();
//		try {
//			t4.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}		
//			
		
		
	}

}
