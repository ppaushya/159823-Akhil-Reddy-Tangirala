package org.cap.multi;

public class MultiDemo extends Thread  {

	

	
	
	public MultiDemo(int num) {
		super();
		this.num = num;
	}

	private int num;

	@Override
	public void run() {
		// TODO Auto-generated method stub
	printtable(num);

	}
	
	public synchronized void printtable(int num)
	{
		for(int i=1;i<=10;i++) {
			System.out.println(i+"x"+num+"="+i*num);
		}
	}
	
}
