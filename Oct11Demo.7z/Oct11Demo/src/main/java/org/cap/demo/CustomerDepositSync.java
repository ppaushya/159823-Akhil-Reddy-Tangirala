package org.cap.demo;

public class CustomerDepositSync {

	private int money;

	public CustomerDepositSync(int money) {
		super();
		this.money = money;
	}
	
	
	public synchronized void deposit(int money)
	{
		this.money+=money;
		notify();
		System.out.println("balance is "+this.money);
	}
	
	public synchronized void withdraw(int money)
	{
		if(this.money<money)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			this.money-=money;
			System.out.println("balance is "+this.money);

		}
	}
	
	
}
