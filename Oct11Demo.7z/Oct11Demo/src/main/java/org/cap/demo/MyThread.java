package org.cap.demo;

public class MyThread extends Thread{

	public MyThread(String string) {
		// TODO Auto-generated constructor stub
super(string);
		
	}

	public MyThread() {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public void run()
	{
		System.out.println(getName()+"thread started");
	}
	
	
	
}
