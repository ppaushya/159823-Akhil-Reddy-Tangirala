package org.cap.demo;

public class MainClassCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CustomerDepositSync c=new CustomerDepositSync(50);
		
		
		Thread t1=new Thread()
				{
			@Override
			public void run()
			{
				c.deposit(200);
			}
		};
		t1.start();
		t1.setPriority(Thread.MAX_PRIORITY);
		System.out.println(t1.getPriority());
		
		Thread t2=new Thread()
		{
	@Override
	public void run()
	{
		c.withdraw(240);
	}
};
t2.start();


Thread t3=new Thread()
{
@Override
public void run()
{
c.withdraw(150);
}
};
t3.start();

Thread t4=new Thread()
{
@Override
public void run()
{
c.deposit(200);
}
};
t4.start();

	}

}
