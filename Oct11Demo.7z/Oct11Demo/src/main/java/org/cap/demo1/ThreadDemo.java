package org.cap.demo1;

public class ThreadDemo implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+"i="+i);
		}
	}

}
