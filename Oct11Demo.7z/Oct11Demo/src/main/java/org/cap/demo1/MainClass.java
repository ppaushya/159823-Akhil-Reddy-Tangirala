package org.cap.demo1;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo th=new ThreadDemo( );
		Thread t1=new Thread(th,"capg thread");
		Thread t2=new Thread(th);
		Thread t3=new Thread(th);
		
		
		
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
t2.start();
try {
	t2.join();
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		
		t3.start();
	try {
		t3.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}

}
