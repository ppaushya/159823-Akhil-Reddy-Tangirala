import { Component, OnInit } from '@angular/core';
import { Inventory } from '../Inventory';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Inventory[] = [];

  inventory: Inventory=new Inventory();

  _listFilter: string;

  filteredProducts: Inventory[];

  constructor(private manageInventoryService: ProductServiceService) {


    this.listFilter = '';

  }

  get listFilter(): string {

    return this._listFilter;

  }



  set listFilter(value: string) {

    this._listFilter = value;

    this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;

  }

  ngOnInit() {
    // this.manageInventoryService.getProducts().subscribe(products => this.products = products);
  }

  // getProducts(): void{

  //   this.manageInventoryService.getProducts()

  //   .subscribe(products => { this.products= this.products;

  //   this.filteredProducts=this.products;});

  //   }


  dltInventory(custidd: number) {
    // this.manageInventoryService.deleteInventory(custidd);
  }

  editInventory(product:Inventory) {
    // this.manageInventoryService.editInventory(product).subscribe(flag=>{
    //   if(flag){
    //     alert("editted!");
    //   }
    // });
  }

  addInventory(product:Inventory) {
    // this.manageInventoryService.editInventory(product).subscribe(flag=>{
    //   if(flag){
    //     alert("added!");
    //   }
    // });
  }

  performFilter(filterBy: string): Inventory[] {

    filterBy = filterBy.toLocaleLowerCase();

    return this.products.filter((product: Inventory) =>

      product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);

  }


}
