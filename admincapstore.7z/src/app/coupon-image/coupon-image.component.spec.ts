import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponImageComponent } from './coupon-image.component';

describe('CouponImageComponent', () => {
  let component: CouponImageComponent;
  let fixture: ComponentFixture<CouponImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
