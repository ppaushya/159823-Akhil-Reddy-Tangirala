import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-analysis',
  templateUrl: './business-analysis.component.html',
  styleUrls: ['./business-analysis.component.css']
})
export class BusinessAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
